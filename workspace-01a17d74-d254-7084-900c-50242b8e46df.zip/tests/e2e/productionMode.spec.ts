import { expect, test } from '@playwright/test';
// Served by scripts/e2e-preview.mjs (see playwright.production.config.ts).
const PREVIEW_URL = 'http://127.0.0.1:4173';

/**
 * The regression this file exists for:
 *
 *   The deployed app at https://lead-tracker-dashboard-gamma.vercel.app used to
 *   open directly into a demo admin session because `isDemoMode` was derived
 *   from *missing* configuration (`!isSupabaseConfigured`). A build with no
 *   env vars must now refuse to run instead of inventing data.
 *
 * These specs run against a production build (`vite build`) with
 * VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY / VITE_DEMO_MODE blanked — the
 * exact situation that caused the bug.
 */

test.describe('production build with no Supabase configuration', () => {
  test.skip(!!process.env.E2E_BASE_URL, 'only meaningful against the local production build');

  test('fails closed with a configuration screen instead of demo data', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'chromium', 'desktop layout');

    await page.goto(PREVIEW_URL);

    await expect(page.getByRole('heading', { name: 'This deployment is not configured' })).toBeVisible();

    // The missing variable names are shown; the values never are.
    await expect(page.getByText('VITE_SUPABASE_URL', { exact: false }).first()).toBeVisible();
    await expect(page.getByText('VITE_SUPABASE_ANON_KEY', { exact: false }).first()).toBeVisible();

    // No login form, no demo account shortcuts, no dashboard.
    await expect(page.getByRole('heading', { name: 'Sign in' })).toHaveCount(0);
    await expect(page.getByText('Demo credentials')).toHaveCount(0);
    await expect(page.getByRole('button', { name: /demo/i })).toHaveCount(0);
    await expect(page.getByRole('heading', { name: 'Lead Tracker Dashboard' })).toHaveCount(0);
  });

  test('no session is created and no dashboard route is reachable', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'chromium', 'desktop layout');

    await page.goto(`${PREVIEW_URL}/users`);

    await expect(page.getByRole('heading', { name: 'This deployment is not configured' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Users' })).toHaveCount(0);

    const sessionKeys = await page.evaluate(() => Object.keys(window.localStorage));
    expect(sessionKeys.join(',')).not.toMatch(/session|token|profile/i);
  });

  test('the bundle contains no demo credentials', async ({ request }, testInfo) => {
    test.skip(testInfo.project.name !== 'chromium', 'desktop layout');

    const html = await (await request.get(PREVIEW_URL)).text();
    const scripts = [...html.matchAll(/src="(\/assets\/[^"]+\.js)"/g)].map((m) => m[1]);
    expect(scripts.length).toBeGreaterThan(0);

    for (const src of scripts) {
      const body = await (await request.get(`${PREVIEW_URL}${src}`)).text();
      expect(body, `${src} must not ship demo passwords`).not.toMatch(/AdminDemo123|CallerDemo123/);
      expect(body, `${src} must not ship demo accounts`).not.toMatch(/demo\.leadtracker\.app/i);
    }
  });
});
