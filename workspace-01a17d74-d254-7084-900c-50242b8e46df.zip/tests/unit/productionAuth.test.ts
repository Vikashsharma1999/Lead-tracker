import { afterEach, describe, expect, it, vi } from 'vitest';
import { describeAuthError, validateCredentials } from '@/lib/authErrors';

/**
 * These tests pin the production-cutover behaviour: a build without Supabase
 * credentials must never resolve to demo mode, and it must never hand back a
 * repository backed by sample data.
 *
 * `vi.stubEnv` writes to `import.meta.env`, and `vi.resetModules()` re-evaluates
 * `src/lib/env.ts` so each case sees a fresh environment snapshot.
 */
async function loadEnv(env: Record<string, string | undefined>) {
  vi.resetModules();
  for (const [key, value] of Object.entries(env)) {
    vi.stubEnv(key, value as string);
  }
  return import('@/lib/env');
}

afterEach(() => {
  vi.unstubAllEnvs();
  vi.resetModules();
});

describe('production configuration gate', () => {
  it('reports "missing" — not demo — when no Supabase credentials exist', async () => {
    const env = await loadEnv({ VITE_SUPABASE_URL: undefined, VITE_SUPABASE_ANON_KEY: undefined });

    expect(env.configState).toBe('missing');
    expect(env.isConfigMissing).toBe(true);
    expect(env.isSupabaseConfigured).toBe(false);
    expect(env.missingConfigVars).toEqual(['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY']);
  });

  it('treats .env.example placeholders as missing configuration', async () => {
    const env = await loadEnv({
      VITE_SUPABASE_URL: 'https://YOUR-PROJECT.supabase.co',
      VITE_SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY',
    });

    expect(env.configState).toBe('missing');
    expect(env.missingConfigVars).toHaveLength(2);
  });

  it('rejects a non-URL value and a truncated key', async () => {
    const env = await loadEnv({
      VITE_SUPABASE_URL: 'not-a-url',
      VITE_SUPABASE_ANON_KEY: 'short',
    });

    expect(env.configState).toBe('missing');
  });

  it('reports "live" with a valid project URL and key', async () => {
    const env = await loadEnv({
      VITE_SUPABASE_URL: 'https://abcdefghijklmnopqrst.supabase.co',
      VITE_SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.payload.signature',
    });

    expect(env.configState).toBe('live');
    expect(env.isSupabaseConfigured).toBe(true);
    expect(env.missingConfigVars).toEqual([]);
    expect(env.appMode).toBe('live');
  });

  it('cannot enter demo mode without an explicit opt-in flag', async () => {
    const env = await loadEnv({
      VITE_SUPABASE_URL: undefined,
      VITE_SUPABASE_ANON_KEY: undefined,
      VITE_DEMO_MODE: undefined,
    });

    expect(env.isDemoMode).toBe(false);
    expect(env.configState).not.toBe('demo');
  });

  it('refuses to construct a repository when configuration is missing', async () => {
    await loadEnv({ VITE_SUPABASE_URL: undefined, VITE_SUPABASE_ANON_KEY: undefined, VITE_DEMO_MODE: undefined });
    const { getRepository } = await import('@/data');
    const { ConfigurationError } = await import('@/lib/configError');

    expect(() => getRepository()).toThrow(ConfigurationError);
  });
});

describe('auth error copy', () => {
  it('never leaks whether an email exists', () => {
    expect(describeAuthError(new Error('Invalid login credentials'))).toMatch(/Incorrect email or password/);
    expect(describeAuthError(new Error('User not found'))).toMatch(/Incorrect email or password/);
  });

  it('explains an unactivated invite', () => {
    expect(describeAuthError(new Error('Email not confirmed'))).toMatch(/activated|invitation/i);
  });

  it('separates a network failure from a bad password', () => {
    expect(describeAuthError(new Error('Failed to fetch'))).toMatch(/Cannot reach/i);
  });

  it('flags a bad key as a deployment problem', () => {
    expect(describeAuthError(new Error('Invalid API key'))).toMatch(/VITE_SUPABASE_ANON_KEY/);
  });

  it('keeps unknown messages intact for support', () => {
    expect(describeAuthError(new Error('Something unusual happened'))).toBe('Something unusual happened');
  });
});

describe('credential validation', () => {
  it('requires a plausible email and a password', () => {
    expect(validateCredentials('', '')).toMatch(/email/i);
    expect(validateCredentials('nope', 'x')).toMatch(/valid email/i);
    expect(validateCredentials('caller@example.com', '')).toMatch(/password/i);
    expect(validateCredentials('caller@example.com', 'secret')).toBeNull();
  });
});
