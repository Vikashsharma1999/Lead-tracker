import { defineConfig, devices } from '@playwright/test';

/**
 * Functional specs run against the Vite dev server with VITE_DEMO_MODE=true
 * (synthetic data, no credentials required).
 *
 * The production-build guard rail (`productionMode.spec.ts`) lives in
 * `playwright.production.config.ts` and runs separately, so the two Vite
 * processes never compete for memory on a 2 GB runner.
 *
 * Set E2E_BASE_URL to run these specs against a real deployment instead.
 */

export default defineConfig({
  testDir: './tests/e2e',
  testIgnore: ['**/productionMode.spec.ts'],
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['list']],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://127.0.0.1:5173',
    trace: 'on-first-retry',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 7'] } },
  ],
  webServer: process.env.E2E_BASE_URL
    ? undefined
    : {
        command: 'npm run dev:host',
        url: 'http://127.0.0.1:5173',
        reuseExistingServer: true,
        timeout: 120_000,
        env: { VITE_DEMO_MODE: 'true' },
      },
});
