# Security model

## Trust boundaries

```
Browser (untrusted)          Supabase Edge Functions (trusted)      Postgres + RLS
├─ anon key only             ├─ service role key                    ├─ policies per role
├─ UI permission checks      ├─ verifies bearer token + profile     ├─ triggers guard columns
└─ offline queue (local)     └─ Google/MS OAuth secrets             └─ audit triggers
```

Nothing that matters is decided in the browser. The UI permission map exists so users are not shown
buttons they cannot use; every rule is re-checked in Postgres.

## Authentication

* Supabase Auth, email/password, PKCE flow for OAuth redirects, refresh-token rotation enabled.
* No public sign-up flow in the app: accounts are created by an admin through `admin-users`
  (`inviteUserByEmail`). A self-signed-up user would receive a `caller` profile and no leads.
* Deactivating a profile blocks sign-in (`signIn` checks `active`) and `admin-users` revokes the
  user's refresh tokens globally.
* The session is issued and persisted by `supabase-js` (its own `sb-<ref>-auth-token` storage key), so
  the PWA survives restarts. On sign-out the IndexedDB queue for that user is wiped.
  `ltd.auth.session` exists **only** in the dev-server demo fixture.
* A signed-in user with no `profiles` row is refused a session rather than given an undefined role.
* Role escalation is impossible from the client: `handle_new_user()` always inserts `caller`, ignores
  user metadata, and has no "first user becomes admin" rule
  (`supabase/migrations/20260101000400_harden_auth.sql`). The first admin is promoted by an operator in
  the SQL editor — see `docs/DEPLOYMENT.md` §0 step 4.

## No demo fallback in production

Mode selection used to be `isDemoMode = !isSupabaseConfigured`, so a deployment without env vars
silently ran on sample data with a hardcoded demo admin. It is now:

| State | Trigger | Behaviour |
| --- | --- | --- |
| `live` | `VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY` present and well-formed | real auth, real data |
| `missing` | production build without them | "This deployment is not configured" screen; nothing runs |
| `demo` | `VITE_DEMO_MODE=true` **and** `import.meta.env.DEV` | synthetic data, dev server only |

The demo repository is imported dynamically behind `import.meta.env.DEV`, so it is dead code in every
build. `npm run verify:bundle` (CI) and `npm run test:e2e:prod` both fail if demo credentials, sample
records or the demo module reach `dist/`.

## Authorisation

Three independent layers:

1. **RLS** — default-deny on ten tables. Callers can only select leads where `assigned_to = auth.uid()`.
2. **Column guards** — `guard_lead_write()` rejects any caller write to `name`, `phone`, `email`,
   `source_*`, `assigned_to`; `guard_profile_write()` rejects role/activation changes by non-admins,
   blocking self-promotion and self-demotion, and `authenticated` holds a column-level grant on
   `profiles` for `full_name` only — `role`/`active` are written by the `admin-users` Edge Function
   with the service role.
3. **Function re-checks** — `requireAdmin()` for `source-sync`, `google-oauth-*`, `admin-users`;
   `is_admin()` inside `import_leads`, `resolve_conflict`.

Security-definer functions pin `search_path = public` and never interpolate untrusted input into SQL
except through `format('%I')` for a column name that comes from the database (`resolve_conflict`).

## Secrets

| Secret | Stored where | Never |
| --- | --- | --- |
| Supabase anon key | client bundle (by design) | — |
| Supabase service role key | Edge Function env | client, repo, VITE_ var |
| Google client secret / refresh tokens | function env / `integration_credentials` (RLS: no policies) | client, logs |
| `OAUTH_STATE_SECRET` | function env | client |
| Microsoft secrets | function env | client |

`src/lib/env.ts` treats placeholder values (`YOUR_…`, `CHANGE_ME`) as "not configured" so a copied
`.env.example` can never masquerade as a live environment.

## Input validation

* Database: check constraints on lengths, phone/email shape, enum domains, status vocabulary, non-negative
  counters, `finished_at >= started_at`.
* Client: filename/type checks on upload, per-row validation with error export, sanitised search terms
  before `ilike` filters.
* Server: header allow-lists for the sheet reader; mapping keys restricted to known internal fields.

## Safe errors

Edge Functions map unexpected exceptions to a generic message and log details server-side. Auth errors
are generic ("Invalid email or password") to avoid account enumeration. The UI never renders a stack
trace or a raw Postgres error containing internal identifiers.

## XSS / injection / transport

* React escapes all rendered values; no `dangerouslySetInnerHTML`.
* CSP in `vercel.json` restricts scripts to self, connections to `*.supabase.co`, blocks framing
  (`frame-ancestors 'none'`), and disallows inline scripts.
* HSTS, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` set at the edge.
* CSV exports quote all fields and prefix a UTF-8 BOM; values starting with `= + - @` should be
  reviewed before opening in Excel (formula-injection awareness).

## Privacy

* The service worker never caches API/Supabase responses — only the app shell.
* Offline cache is per-user and cleared on sign-out; no tokens are written to IndexedDB.
* Audit log records actor, action, entity and a field-diff summary (never full note bodies in metadata
  beyond the changed columns' new values).

## Rate limiting and abuse

* Supabase applies platform rate limits; `source-sync` performs one API call per worksheet read and
  batches write-back into a single `values:batchUpdate`.
* Sync retries back off exponentially and stop after 5 attempts to avoid hammering Google.

## Open items

* Add pgTAP tests that assert each RLS policy from a caller/admin/service-role JWT.
* Add server-side request throttling per user for `source-sync` (currently only admin-gated).
* Consider column-level encryption of `integration_credentials` with `pgsodium` for defence in depth.
