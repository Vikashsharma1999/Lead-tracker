# Phase status

Updated: 2026-10-27. This document is deliberately blunt about what is done and what is not.

## Phase 4 — Production cutover (code complete, live sign-in unverified)

Goal: the deployed app must never open into demo mode again, and authentication/roles must be real.

Done and verified in-repo:

* `isDemoMode = !isSupabaseConfigured` removed. Mode is now `live` / `missing` / `demo`, where `demo`
  requires `VITE_DEMO_MODE=true` **and** the Vite dev server. A production build without credentials
  renders a "This deployment is not configured" screen; there is no fallback to sample data.
* The demo backend (seed users, passwords, sample leads) is loaded via a dev-only dynamic import and is
  absent from `dist/` — asserted by `npm run verify:bundle` and `npm run test:e2e:prod`.
* Demo quick-fill buttons and the plaintext credential list removed from the login page.
* New migration `20260101000400_harden_auth.sql`: new users are always `caller`, user metadata is
  never trusted, the "first user becomes admin" rule is gone, `authenticated` has column-level write
  access to `profiles.full_name` only, and role/activation changes are audited by trigger.
* Role/activation changes now go through the `admin-users` Edge Function (service role + server-side
  re-check); the last active admin cannot be removed or deactivated.
* Clear states: loading, invalid credentials, missing configuration, and connection/database errors are
  distinct screens/messages; a signed-in user with no profile row is refused instead of getting an
  undefined role.

**Not verified:** real sign-in against the hosted Supabase project. This environment has no Supabase
credentials or project, so `live` mode is exercised only against a stub project URL. Treat the
deployment as *not connected* until `docs/DEPLOYMENT.md` §0 step 7 passes in a browser on the real
domain.

## Phase 1 — Responsive dashboard UI (complete)

* Forest-green header with white title/subtitle and **Refresh Data** action.
* Eight KPI tiles (Total, Not Dialed, Dialed, Interested, Not Interested, Call Back, Webinar Link
  Shared, Follow-up Pending) — all values computed from records.
* Colourful Recharts status pie with per-status counts and percentages.
* Connection strip that separates **database realtime**, **Google Sheets**, **Excel/OneDrive** and the
  **offline queue**; last successful sync timestamp shown in the header.
* Full lead table (Lead ID, date, name, mobile, email, source/worksheet, caller, status, outcome, last
  call, next follow-up, notes, last updated) with search, filters, sorting, pagination, inline actions.
* Mobile card layout, drawer navigation, keyboard-accessible modals, empty/loading/error states.
* Demo mode is labelled everywhere ("Demo data" badge, honest integration copy) — dev server only.

Remaining UI polish (not blocking): column chooser, saved filter views, per-column resize.

## Phase 2 — Supabase database, auth and roles (complete)

* Migrations: schema, enums, generated columns, indexes, triggers, RLS policies, RPCs, storage bucket.
* Auth: email/password sign-in, invite-only account creation via `admin-users`, deactivation kills the
  session, session restore, sign-out clears local customer data.
* Roles: admin vs caller. Self-elevation blocked in the client, in RLS and in triggers.
* Caller isolation: visible rows are filtered by RLS; contact fields are immutable for callers; bulk
  assignment/status/deletion and audit access are admin-only.
* Realtime: `postgres_changes` on leads/activities/sources/jobs → React Query invalidation.
* Audit log: trigger-written for lead mutations, function-written for imports/sync/conflicts; read-only
  for admins.

Verification: 100 unit tests (incl. role matrix, isolation, conflicts, imports, production
config gate) + 13 desktop/mobile e2e specs + 3 production-build guard specs.

## Phase 3 — Excel and CSV import/export (complete)

* Multi-file `.xlsx` / `.xls` / `.csv`, worksheet picker, header auto-mapping with manual override.
* Row validation with per-row error list, invalid rows excluded and exportable as an error report.
* Duplicate policies (update/skip/create), idempotent re-imports keyed on source row id.
* Durable `sync_jobs` record per import with added/updated/skipped counts.
* Export filtered records or selected rows to `.xlsx` and `.csv` (RFC 4180 quoting + BOM).

## Phase 4 — Google Sheets integration (code complete, credentials required)

Implemented: OAuth start (PKCE, signed state, admin check), callback (token exchange, identity check,
live API verification before "connected", token storage in a service-role-only table), `source-sync`
(read → map → upsert → job record), `retry_failed` with exponential backoff, `write_back` batch update,
refresh-token rotation handling, per-source sync interval field (min 15 s).

Not verifiable here: real Google API calls (no credentials). The UI shows "Not configured" and every
sync action returns an honest failure until OAuth is completed.

Remaining: create the scheduler (pg_cron/external) for interval sync; build the "connect sheet" admin
dialog for picking a spreadsheet id/worksheet (currently set via `data_sources.configuration` using the
guided setup + `google-oauth-start`).

## Phase 5 — OneDrive / SharePoint Excel sync (not started)

Only the UI setup guide exists. Required next:

1. Microsoft Entra app with delegated `Files.Read`, `Files.ReadWrite`, `offline_access`.
2. `ms-oauth-start` / `ms-oauth-callback` functions (mirror the Google ones).
3. `source-sync` branch using Graph `GET /drives/{id}/items/{itemId}/workbook/worksheets/{name}/usedRange`.
4. Delta queries (`/delta`) for incremental reads, and `PATCH` cells for write-back.

Local Excel files are **never** auto-synced; the README explains the upload/re-import and local-agent
options.

## Phase 6 — Offline support and conflict resolution (mostly complete)

Done: manifest + icons, service worker with app-shell precache and `NetworkOnly` for API/Supabase,
IndexedDB queue (per-user, cleared on sign-out), offline indicator with pending count, queued lead
updates and call activities, ordered replay with backoff and attempt cap, explicit "saved on device
only" messaging, conflict recording on stale version, admin conflict resolution panel (keep local /
keep server / dismiss) backed by the `resolve_conflict` RPC.

Remaining: offline read cache for the lead list (currently the last fetched page stays in memory only);
background sync (`Background Sync API`) for browsers that support it; conflict handling for call
activities created offline that duplicate an online one.

## Phase 7 — Security, integration verification, deployment (in progress)

Done: RLS on every table, column guards, least-privilege scopes, secrets only in server env, safe error
messages, audit logging, CSP/HSTS headers in `vercel.json`, CI workflow running typecheck + unit tests
+ build, backup/recovery runbook.

Outstanding before "done":

* Live smoke test of Google Sheets read/write in a real project (needs credentials).
* Load test with ~50k leads (indexes are in place; pagination is server-side).
* Automated RLS test suite using `pgTAP` against a local Supabase instance.
* Monitoring/alerting on failed sync jobs and 401/403 spikes.
