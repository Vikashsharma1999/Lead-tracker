# Production cutover — demo admin mode removed

**Date:** 2026-10-27
**Target deployment:** https://lead-tracker-dashboard-gamma.vercel.app
**Status:** code complete and verified in-repo; **live sign-in against the hosted Supabase project is
still unverified** (this environment has no Supabase project or credentials). The app is **not**
"connected" until the checklist in `docs/DEPLOYMENT.md` §0 step 7 passes in a browser on that domain.

---

## 1. Why the deployed app opened in demo admin mode

Measured against the live deployment, not assumed:

```bash
curl -s https://lead-tracker-dashboard-gamma.vercel.app/assets/index-Rf6GPrUj.js \
  | grep -oE '(admin@demo\.leadtracker\.app|CallerDemo123)'  # → 2 hits each
curl -s https://lead-tracker-dashboard-gamma.vercel.app/assets/index-Rf6GPrUj.js \
  | grep -oE 'https://[a-z0-9]{20}\.supabase\.co'           # → nothing
```

Two independent causes:

1. **No Supabase credentials in the Vercel build.** The deployed bundle contains no project URL, so
   `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` were missing (or still placeholders) when Vercel last
   built. Vite inlines env vars at build time, so they also need a redeploy to take effect.
2. **A demo fallback in the app itself.** `src/lib/env.ts` computed
   `isDemoMode = !isSupabaseConfigured`, and `src/data/index.ts` then constructed `DemoRepository`.
   "Not configured" was treated as "run on sample data", which is why the app looked healthy while
   being completely disconnected — and why the demo admin login existed in the shipped bundle.

Secondary auth weaknesses found in the same audit (all fixed):

| # | Issue | Impact |
| - | ----- | ------ |
| A | `handle_new_user()` promoted the **first profile ever created** to `admin` | On an empty production project, whoever signs up first becomes admin |
| B | The same trigger honoured `raw_user_meta_data ->> 'role'` when `created_by_admin` was set | Both fields are client-controlled at `signUp()` → self-assign admin |
| C | `authenticated` held table-level `UPDATE` on `profiles` (incl. `role`, `active`) | Only the trigger stood between a user and their own role |
| D | `getProfile()` returned `null` on any auth error | A network/DB failure looked like "logged out" |
| E | Sign-up enabled in `supabase/config.toml` | Unnecessary public account creation |

---

## 2. What changed in the code

| File | Change |
| ---- | ------ |
| `src/lib/env.ts` | Rewritten mode logic: `configState = 'live' \| 'demo' \| 'missing'`. `demo` requires `VITE_DEMO_MODE=true` **and** `import.meta.env.DEV`. URL/key are shape-validated; placeholder values count as missing. |
| `src/lib/configError.ts` *(new)* | `ConfigurationError` + `assertConfigured()` guard. |
| `src/data/index.ts` | Throws instead of falling back to `DemoRepository`. The demo backend is registered only by the dev bootstrap. |
| `src/main.tsx` | Loads the demo repository through `await import()` inside `if (import.meta.env.DEV && isDemoMode)` → dead code in production builds. |
| `src/App.tsx` | Renders `ConfigErrorScreen` when configuration is missing; renders `ConnectionErrorScreen` for database/connection failures instead of redirecting to a login form. |
| `src/components/ConfigErrorScreen.tsx` *(new)* | "This deployment is not configured" screen (variable names only, never values) + reusable connection-error screen. |
| `src/hooks/useAuth.tsx` | Never crashes on missing config; distinguishes session-restore failure from "no session"; adds `retry()`; no repository call before the config gate. |
| `src/pages/Login.tsx` | Demo quick-fill buttons and the plaintext credential list removed. Real email/password form with validation, loading state, and mapped errors. |
| `src/lib/authErrors.ts` *(new)* | Maps Supabase messages to actionable copy (bad credentials, unconfirmed invite, rate limit, network, invalid key, RLS/database error). |
| `src/data/supabaseRepository.ts` | `signIn`/`getProfile` refuse a session when there is no profile row or the account is inactive; `updateProfile` routes role/activation through the `admin-users` Edge Function. |
| `supabase/migrations/20260101000400_harden_auth.sql` *(new)* | New users are always `caller`; metadata never trusted; first-user-admin removed; `guard_profile_write` extended to INSERT/`active`/email; column-level grants (`authenticated` may write `full_name` only); audit trigger for role/activation changes. |
| `supabase/functions/admin-users/index.ts` | Role no longer passed via user metadata; refuses to remove/deactivate the last active admin. |
| `supabase/config.toml` | `enable_signup = false`; documented production Site URL / redirect URLs. |
| `playwright.config.ts`, `playwright.production.config.ts` *(new)*, `tests/e2e/productionMode.spec.ts` *(new)*, `scripts/e2e-preview.mjs` *(new)* | Regression specs that build the app the way Vercel does (no env vars) and assert it fails closed. |
| `scripts/verify-prod-bundle.mjs` *(new)*, `npm run verify:bundle` | Build guard: fails if demo credentials, sample records or the demo module appear in `dist/`. |
| `tests/unit/productionAuth.test.ts` *(new)* | 12 tests pinning the config gate and error copy. |
| `README.md`, `docs/DEPLOYMENT.md`, `docs/SECURITY.md`, `docs/PHASE_STATUS.md` | Rewritten for the real-auth world; the old "the first user becomes admin" instruction is deleted. |

UI, layout, navigation and features are unchanged — this was a security/plumbing change, not a redesign.

---

## 3. Verification performed here (reproducible)

```bash
npm run typecheck                 # clean
npm test                          # 100 passed (was 88; +12 production-gate tests)
npm run build                     # vite build, ~9 s
npm run verify:bundle             # ✓ no demo artefacts in dist; ✓ config screen present
npm run test:e2e                  # 13 passed, 1 skipped (chromium)
npm run test:e2e:prod             # 3 passed — production build fails closed
```

Direct evidence that the reported bug is gone:

```
$ grep -rl "admin@demo.leadtracker.app\|AdminDemo123\|CallerDemo123" dist/     → no files
$ ls dist/assets | grep -i demo                                              → no demo chunk
$ grep -o "This deployment is not configured" dist/assets/index-*.js         → found
```

And with real-looking credentials in the build (`live` state), the app renders the ordinary sign-in
form — no demo credentials, no config screen, no page errors.

## 4. What you must do (cannot be done from here)

1. **Apply migrations**, including the new `20260101000400_harden_auth.sql` (`supabase db push`).
2. **Disable sign-ups**: Supabase → Authentication → Sign In / Providers → "Allow new users to sign up" off.
3. **Auth URLs**: Site URL `https://lead-tracker-dashboard-gamma.vercel.app`; add
   `https://lead-tracker-dashboard-gamma.vercel.app/**` (and `http://localhost:5173/**` for dev) to the
   redirect allow-list.
4. **Bootstrap the first admin**: create the user in the Auth dashboard (auto-confirm), then
   `update public.profiles set role='admin' where lower(email)=lower('you@company.com');`
5. **Vercel env vars** (Production + Preview): `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`; delete or
   set `VITE_DEMO_MODE=false`; **redeploy without build cache**. Never add the service-role key.
6. **Edge Functions**: `supabase secrets set --env-file supabase/.env.production && npm run fn:deploy`
   (needs `SUPABASE_SERVICE_ROLE_KEY`, `APP_INVITE_REDIRECT_URL`, Google OAuth values).

Then run the checklist in `docs/DEPLOYMENT.md` §0 step 7 — sign-in, sign-out, role isolation, RLS
rejection of a hand-crafted role update, empty-state on an empty database, and the env-var-removed test
that proves the demo fallback is gone.

---

## 5. Known limits of this change

* **Live authentication has not been tested** against the hosted project — no credentials here. Every
  live-mode statement above is about behaviour with a stub project URL (bundle contents, routing, UI
  states), not about a successful login.
* The SQL migration was validated by inspection only: this sandbox has no Postgres/`psql`, so it has not
  been executed. Run `supabase db push` against a staging/branch database first, and keep the
  `docs/DEPLOYMENT.md` §5 "no admin" recovery line handy.
* The Edge Function changes were similarly not executed (no Deno runtime here). `admin-users` should be
  smoke-tested right after `fn:deploy` by inviting one caller.
* If your Vercel project is configured to not build `main` automatically, remember the redeploy step —
  env vars alone change nothing in an already-built bundle.
