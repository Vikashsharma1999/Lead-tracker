# Deployment, backup and recovery

This is the operator runbook. It covers the **production cutover** (demo mode → real Supabase Auth),
the Vercel and Supabase configuration, backups and recovery.

---

## 0. Production cutover — do these in order

The app fails closed: with no Supabase credentials it renders a "This deployment is not configured"
screen and never falls back to sample data. Demo mode only exists on the local dev server
(`VITE_DEMO_MODE=true` + `npm run dev`), and its code is tree-shaken out of every production build
(verified by `npm run verify:bundle`).

| # | Step | Where |
| - | ---- | ----- |
| 1 | Apply migrations `20260101000000` → `20260101000400` | Supabase SQL editor **or** `supabase db push` |
| 2 | Disable self-service sign-up | Authentication → Sign In / Providers |
| 3 | Set Site URL + redirect allow-list to the Vercel domain | Authentication → URL Configuration |
| 4 | Create the first user, then promote it to `admin` with one SQL statement | Auth dashboard + SQL editor |
| 5 | Set `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` in Vercel, **redeploy** | Vercel → Settings → Environment Variables |
| 6 | Deploy the Edge Functions + their secrets | `supabase secrets set` / `npm run fn:deploy` |
| 7 | Verify sign-in, roles, RLS, empty state | Browser |

### 1. Migrations

```bash
npm i -g supabase
supabase login
supabase link --project-ref <PROJECT_REF>
supabase db push          # applies every file in supabase/migrations in order
```

| File | Purpose |
| ---- | ------- |
| `20260101000000_init_schema.sql` | tables, enums, indexes, audit/version triggers, `citext` email uniqueness |
| `20260101000100_functions.sql` | `is_admin()`, guard triggers, RPCs (`log_call`, `dashboard_summary`, `report_summary`, `import_leads`, `resolve_conflict`, `schedule_job_retry`) |
| `20260101000200_rls.sql` | row-level security for every table; `anon` has no access to `profiles` |
| `20260101000300_seed_statuses.sql` | status vocabulary (no customer data) |
| `20260101000400_harden_auth.sql` | **new** — new users are always `caller`, no metadata-trust, no first-user-admin, column-level privileges on `profiles`, audit trigger for role/activation changes |

If you have an existing project that already ran the first four files, only
`20260101000400_harden_auth.sql` is new. Apply it before inviting anyone.

### 2. Disable sign-ups (required)

Authentication → **Sign In / Providers** → Email: turn **"Allow new users to sign up" off**.
Admin invitations still work with sign-ups disabled — `inviteUserByEmail` runs with the service role.

Why it matters: with sign-ups open, anyone holding the public anon key (which ships in the browser by
design) could create an account. After `20260101000400` such an account is always a `caller` with no
lead access, but there is no reason to accept the noise.

### 3. Auth URL configuration (required for emails/links)

Authentication → **URL Configuration**:

```
Site URL
  https://lead-tracker-dashboard-gamma.vercel.app

Redirect URLs (one per line)
  https://lead-tracker-dashboard-gamma.vercel.app/**
  https://*-<your-team>.vercel.app/**            # optional: preview deployments
  http://localhost:5173/**                       # local development only
```

Use the **`/**` wildcard form**. Without it, invite links and password-recovery links redirect to the
wrong origin and the user lands on a dead page.

### 4. Bootstrap the first admin (deliberate, one time)

There is no "first user becomes admin" rule any more — that rule is a privilege-escalation bug on an
empty project.

1. Supabase → **Authentication → Users → Add user**, with **Auto Confirm User** enabled.
2. Run once in the SQL editor (replace the email):

```sql
update public.profiles
   set role = 'admin'
 where lower(email) = lower('you@yourcompany.com');

select id, email, role, active from public.profiles order by created_at;
```

Every later user is created from the app: **Users → Invite user** (admin only). The invite email
carries a one-time link; the role is written server-side by the `admin-users` Edge Function, never by
the browser and never from user metadata.

### 5. Vercel configuration

Project → **Settings → Environment Variables** (Production **and** Preview):

| Name | Value | Notes |
| ---- | ----- | ----- |
| `VITE_SUPABASE_URL` | `https://<ref>.supabase.co` | Project Settings → API → Project URL |
| `VITE_SUPABASE_ANON_KEY` | public anon / publishable key | Project Settings → API. Safe to expose; RLS protects the data |
| `VITE_DEMO_MODE` | *(delete it, or `false`)* | Ignored by production builds anyway |
| `VITE_APP_NAME` | optional | shown in the UI |
| `VITE_SUPPORT_EMAIL` | optional | shown on the login page |

**Never** add `SUPABASE_SERVICE_ROLE_KEY` (or any `VITE_`-prefixed secret) to Vercel's frontend
environment. The service role is used only inside Edge Functions.

Vite inlines environment variables at **build time**. After changing them you must trigger a new
deployment (Deployments → ⋯ → Redeploy, with "use existing build cache" **off**).
`https://YOUR-…`, `CHANGE_ME`, `abc123` and `example.com/YOUR` are treated as *not configured* on
purpose, so a half-edited value produces the configuration screen rather than a confusing network
error.

### 6. Edge Function secrets

```bash
cp supabase/.env.example supabase/.env.production   # then fill it in; never commit it
supabase secrets set --env-file supabase/.env.production
npm run fn:deploy
```

Required (server-side only, no `VITE_` prefix):

```
SUPABASE_URL=https://<ref>.supabase.co
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...          # service role: functions only
OAUTH_STATE_SECRET=...                 # openssl rand -hex 32
GOOGLE_OAUTH_CLIENT_ID=...
GOOGLE_OAUTH_CLIENT_SECRET=...
GOOGLE_OAUTH_REDIRECT_URI=https://<ref>.supabase.co/functions/v1/google-oauth-callback
APP_REDIRECT_URL=https://lead-tracker-dashboard-gamma.vercel.app/sources
APP_INVITE_REDIRECT_URL=https://lead-tracker-dashboard-gamma.vercel.app/login
```

`admin-users` uses `APP_INVITE_REDIRECT_URL` for invitation emails: it must be an allowed redirect URL
from step 3.

### 7. Verification checklist

Frontend (`https://lead-tracker-dashboard-gamma.vercel.app`):

- [ ] Fresh browser / private window → app shows **Sign in**, never a dashboard.
- [ ] `localStorage` and `IndexedDB` contain no session before signing in.
- [ ] Wrong password → "Incorrect email or password", no session created.
- [ ] Sign in as the bootstrapped admin → dashboard loads **real** data; empty project → empty
      states ("No leads yet"), not sample rows.
- [ ] Sign out → returns to the login screen; reload stays signed out.
- [ ] Users screen: invite a caller; the invite email arrives and points at your domain.
- [ ] Sign in as that caller → no Users/Settings/Audit/Import entries, and no lead access.
- [ ] Caller tries a privileged RPC from the console (e.g. `import_leads`) → rejected by the database.
- [ ] Caller cannot update `profiles.role` even with a hand-crafted `supabase.from(...)` call
      (`42501 permission denied for column role`).
- [ ] Unset the Vercel env var and redeploy → the "not configured" screen appears (proves the demo
      fallback is gone). Set it back afterwards.

Logs: Vercel → Functions/Runtime logs for the frontend, Supabase → Logs → API/Postgres for RLS denials,
Supabase → Edge Functions → Logs for `admin-users`/`source-sync`.

### 8. Realtime and the sync scheduler

Database → Replication → confirm `leads`, `call_activities`, `data_sources`, `sync_jobs` are in the
`supabase_realtime` publication (Realtime respects RLS).

Edge Functions are request-driven. For 15–60 s freshness, schedule `source-sync` with pg_cron:

```sql
select cron.schedule(
  'lead-sync-every-minute',
  '* * * * *',
  $$
  select net.http_post(
    url := 'https://<ref>.supabase.co/functions/v1/source-sync',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name = 'service_role_key'),
      'apikey', (select decrypted_secret from vault.decrypted_secrets where name = 'service_role_key')
    ),
    body := jsonb_build_object('action', 'sync_now')
  );
  $$
);
```

Store the key in Supabase Vault rather than pasting it into the cron definition.

---

## 1. Local development

```bash
npm run setup                      # installs deps (exec bits do not survive every clone/snapshot)
npm run dev                        # http://localhost:5173 — needs .env.local with the VITE_ vars
npm run dev:host                   # same, bound to 0.0.0.0 (containers/codespaces)
```

To work offline with synthetic data, `.env.local`:

```
VITE_DEMO_MODE=true
```

That flag is honoured **only** by the dev server. `npm run build` and any deployed environment ignore
it, and `npm run verify:bundle` fails the build if demo data ever sneaks into `dist/`.

```bash
npm run typecheck && npm test              # unit tests (vitest)
npm run test:e2e                           # Playwright, chromium (demo mode against the dev server)
npm run verify:bundle                      # build + assert no demo artefacts in dist/
```

## 2. Vercel (frontend) — mechanics

1. Import the repo; the Vite preset is detected. `vercel.json` sets the build command, SPA rewrites and
   security headers.
2. Install command: `npm ci --legacy-peer-deps` (peer-dependency resolution needs it).
3. Build command: `npm run build` (`tsc -b && vite build`).
4. Output: `dist/`.
5. `sw.js` is served with `no-cache`; the manifest at `/manifest.webmanifest` makes it installable.

### Alternative hosts

* Netlify / Cloudflare Pages: same build, add the SPA rewrite to `/index.html`, copy the security
  headers from `vercel.json`.
* Self-hosted Nginx: serve `dist/`, `try_files $uri /index.html`, same headers, HTTPS only.

## 3. CI (GitHub Actions)

`.github/workflows/ci.yml` runs on every push/PR: `npm ci --legacy-peer-deps` → `npm run typecheck` →
`npm test` → `npm run build` → `node scripts/verify-prod-bundle.mjs --no-build` (demo-artefact guard) →
Playwright e2e job.

Deployment is left to Vercel's Git integration; adding `vercel deploy --prod` to Actions is a
one-liner if you prefer Actions-driven releases.

## 4. Backups

Supabase (Pro plan and above) provides daily automatic backups with PITR options. Additionally:

```bash
pg_dump "postgresql://postgres:<password>@db.<ref>.supabase.co:5432/postgres" \
  --no-owner --format=custom --file "backup-$(date +%F).dump"

# Restore into a scratch project to verify the backup
pg_restore --clean --no-owner --dbname "postgresql://.../postgres" backup-2026-10-23.dump
```

Also export the `lead-imports` storage bucket if you rely on uploaded files.

## 5. Recovery runbook

| Scenario | Action |
| --- | --- |
| Bad migration | `supabase migration repair --status reverted <version>`, deploy a corrective migration; PITR only if data was lost |
| Accidentally locked out (no admin) | SQL editor: `update public.profiles set role='admin', active=true where lower(email)=lower('you@company.com');` |
| User lost access | Users screen → reactivate, or re-invite; `active=false` rows keep their lead history |
| Accidental bulk delete | Restore `leads` from the latest backup into a scratch schema and re-insert by `id`; `audit_logs` shows who/when |
| Compromised service-role key | Rotate in Supabase → update function secrets + cron → redeploy functions |
| Compromised Google token | Revoke access in the Google account, delete the `integration_credentials` row, reconnect |
| Frontend regression | Vercel → Deployments → Promote a previous build (instant rollback) |
| Sync stuck/failing | Data Sources → Retry failed; inspect `sync_jobs.error_message`; check OAuth expiry |
| App shows "not configured" | The Vercel env vars are missing/placeholder, or the deployment was not rebuilt after adding them |

## 6. Playwright on minimal containers

If Chromium fails to launch with `libnspr4.so: cannot open shared object file`, install the browser
dependencies:

```bash
npx playwright install --with-deps chromium   # needs root
# or, without root, extract the .deb files locally and point LD_LIBRARY_PATH at them
apt-get download libnspr4 libnss3 libatk1.0-0t64 libatk-bridge2.0-0t64 libcups2t64 libdrm2 \
  libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 \
  libasound2t64 libatspi2.0-0t64
for f in *.deb; do dpkg-deb -x "$f" ./root; done
LD_LIBRARY_PATH=$PWD/root/usr/lib/x86_64-linux-gnu npx playwright test
```
