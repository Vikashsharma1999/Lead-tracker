/**
 * Turns Supabase's raw auth/database messages into copy a caller can act on.
 *
 * The raw message is kept when nothing matches, so a genuine support question
 * still carries information. Nothing here reveals whether an email exists, so
 * it cannot be used to enumerate accounts beyond what Supabase already does.
 */

const NOUN = 'sign in';

export function describeAuthError(error: unknown): string {
  const raw = error instanceof Error ? error.message : typeof error === 'string' ? error : '';
  const message = raw.trim();

  if (!message) return `Could not ${NOUN}. Please try again.`;
  const m = message.toLowerCase();

  if (m.includes('invalid login credentials') || m.includes('invalid_credentials')) {
    return 'Incorrect email or password. Check your details and try again.';
  }
  if (m.includes('email not confirmed') || m.includes('email_not_confirmed')) {
    return 'This account has not been activated yet. Open the invitation email from your administrator, or ask them to resend it.';
  }
  if (m.includes('user not found')) {
    return 'Incorrect email or password. Check your details and try again.';
  }
  if (m.includes('invalid api key') || m.includes('no api key') || m.includes('jwt')) {
    return 'This deployment is using an invalid Supabase key. Update VITE_SUPABASE_ANON_KEY in Vercel and redeploy.';
  }
  if (m.includes('failed to fetch') || m.includes('networkerror') || m.includes('load failed') || m.includes('network request failed')) {
    return 'Cannot reach the authentication server. Check your connection, then try again. If it persists, the Supabase project may be paused.';
  }
  if (m.includes('too many') || m.includes('rate limit') || m.includes('429')) {
    return 'Too many attempts. Wait a minute, then try again.';
  }
  if (m.includes('database error') || m.includes('permission denied') || m.includes('row-level security')) {
    return `The database rejected this request (${message}). This is a server-side permission problem — contact your administrator.`;
  }
  if (m.includes('password should be') || m.includes('weak password')) {
    return 'That password does not meet the project password policy.';
  }
  return message;
}

/** Very small client-side check; the server remains the source of truth. */
export function validateCredentials(email: string, password: string): string | null {
  if (!email.trim()) return 'Enter your email address.';
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) return 'Enter a valid email address.';
  if (!password) return 'Enter your password.';
  return null;
}
