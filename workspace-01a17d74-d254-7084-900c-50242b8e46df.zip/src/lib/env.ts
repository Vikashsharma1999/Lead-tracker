/**
 * Environment access + runtime mode detection.
 *
 * There are exactly three runtime states, and the app **fails closed**:
 *
 *  - `live`    : a real Supabase project is configured. All data comes from
 *                Postgres through RLS-protected queries, auth is real, and
 *                integrations are performed by server-side Edge Functions.
 *  - `demo`    : only possible on the local dev server (`vite dev`) when
 *                VITE_DEMO_MODE=true. Uses a local sample-data repository in
 *                IndexedDB. A production build can never enter this state.
 *  - `missing` : no credentials in a production build. The app renders an
 *                explicit "not configured" screen. It never silently falls back
 *                to sample data, demo users, or a default session.
 *
 * The previous behaviour — `isDemoMode = !isSupabaseConfigured` — is what made
 * the deployed app open straight into a demo admin session whenever the Vercel
 * environment variables were absent. That fallback is deliberately gone.
 *
 * Integrations (Google Sheets, Microsoft Graph) additionally require their own
 * server-side credentials. `integrationsConfigured` only reflects the public
 * signal the server exposes; it is never inferred from the client bundle.
 */

const raw = import.meta.env;

/** Vite sets `DEV` for `vite dev`/`vite serve`; it is `false` in any build. */
const isDevServer = Boolean(raw.DEV);

function clean(value: string | undefined): string {
  const v = (value ?? '').trim();
  if (!v) return '';
  // Treat the obvious placeholders from .env.example as "not configured".
  // Without this, a copied-but-unedited .env would look configured and the app
  // would fail with a confusing network error instead of a clear message.
  if (/YOUR[-_]|CHANGE[-_]ME|abc123|example\.com\/YOUR/i.test(v)) return '';
  return v;
}

function isHttpUrl(value: string): boolean {
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

/**
 * Supabase accepts both legacy JWT anon keys (`eyJ…`) and the newer publishable
 * keys (`sb_publishable_…`). Both are long, whitespace-free strings; anything
 * shorter is almost certainly a truncated paste or a placeholder.
 */
function looksLikePublicKey(value: string): boolean {
  return value.length >= 20 && !/\s/.test(value);
}

export const supabaseUrl = clean(raw.VITE_SUPABASE_URL as string | undefined);
export const supabaseAnonKey = clean(raw.VITE_SUPABASE_ANON_KEY as string | undefined);
export const appName = (raw.VITE_APP_NAME as string | undefined)?.trim() || 'Lead Tracker Dashboard';
export const supportEmail = (raw.VITE_SUPPORT_EMAIL as string | undefined)?.trim() || '';

/** Explicit opt-in flag. Ignored outside the dev server — see below. */
export const demoRequested = String(raw.VITE_DEMO_MODE ?? '').trim().toLowerCase() === 'true';

/**
 * Sample data is a development affordance only. Requiring `import.meta.env.DEV`
 * means a `vite build` (what Vercel ships) can never contain a reachable demo
 * repository, even if VITE_DEMO_MODE leaks into the production environment.
 */
export const isDemoMode = demoRequested && isDevServer;

const urlValid = supabaseUrl !== '' && isHttpUrl(supabaseUrl);
const keyValid = supabaseAnonKey !== '' && looksLikePublicKey(supabaseAnonKey);

/** Names only — never values — safe to render in the UI and in logs. */
export const missingConfigVars: string[] = [];
if (!urlValid) missingConfigVars.push('VITE_SUPABASE_URL');
if (!keyValid) missingConfigVars.push('VITE_SUPABASE_ANON_KEY');

export type ConfigState = 'live' | 'demo' | 'missing';

export const configState: ConfigState = isDemoMode
  ? 'demo'
  : urlValid && keyValid
    ? 'live'
    : 'missing';

export const isSupabaseConfigured = configState === 'live';
export const isConfigMissing = configState === 'missing';

/** Kept for components that only need a two-way display hint. */
export const appMode: 'live' | 'demo' = configState === 'demo' ? 'demo' : 'live';

/** Public description of the integration state shown in the UI. */
export interface IntegrationAvailability {
  googleSheets: 'server_unconfigured' | 'ready';
  microsoftGraph: 'server_unconfigured' | 'ready';
}

/**
 * The client deliberately does not try to guess whether server credentials
 * exist. It asks the server (`data_sources` / health endpoint) at runtime.
 * These defaults keep the "not configured" copy honest until then.
 */
export const initialIntegrationAvailability: IntegrationAvailability = {
  googleSheets: 'server_unconfigured',
  microsoftGraph: 'server_unconfigured',
};
