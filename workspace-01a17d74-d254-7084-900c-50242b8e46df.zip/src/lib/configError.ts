import { isConfigMissing, missingConfigVars } from './env';

/**
 * Thrown when production code asks for a repository but no Supabase project is
 * configured. Failing loudly is intentional: the alternative (falling back to
 * sample data) is how a deployment ends up looking "connected" when it is not.
 */
export class ConfigurationError extends Error {
  readonly missing: string[];

  constructor(missing: string[] = missingConfigVars) {
    super(
      missing.length
        ? `Supabase is not configured. Missing: ${missing.join(', ')}.`
        : 'Supabase is not configured.',
    );
    this.name = 'ConfigurationError';
    this.missing = missing;
  }
}

export function isConfigurationError(error: unknown): error is ConfigurationError {
  return error instanceof ConfigurationError;
}

/** Guard used by data access + auth so nothing can run unconfigured. */
export function assertConfigured(): void {
  if (isConfigMissing) throw new ConfigurationError();
}
