import { AlertTriangle, Database, RefreshCw, ShieldAlert } from 'lucide-react';
import { missingConfigVars } from '@/lib/env';

/**
 * Shown when a production build has no Supabase credentials.
 *
 * This screen replaces the old silent fallback into demo mode. It intentionally
 * shows **variable names only** — never values — so it is safe to screenshot.
 */
export function ConfigErrorScreen() {
  return (
    <div className="flex min-h-full items-center justify-center bg-canvas px-4 py-12">
      <div className="w-full max-w-2xl">
        <div className="card overflow-hidden">
          <div className="flex items-start gap-3 border-b border-[var(--color-hairline)] bg-amber-50 px-6 py-5">
            <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-700">
              <ShieldAlert className="h-5 w-5" aria-hidden />
            </span>
            <div>
              <h1 className="text-base font-bold text-navy-900">This deployment is not configured</h1>
              <p className="mt-1 text-sm text-navy-600">
                No database connection is available, so the app cannot sign anyone in. It is{' '}
                <strong>not</strong> running on sample data — nothing is shown, stored, or synced.
              </p>
            </div>
          </div>

          <div className="px-6 py-5">
            <p className="text-xs font-semibold tracking-wide text-navy-500 uppercase">
              Missing environment variables
            </p>
            <ul className="mt-2 space-y-1.5">
              {(missingConfigVars.length ? missingConfigVars : ['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY']).map(
                (name) => (
                  <li
                    key={name}
                    className="flex items-center gap-2 rounded-lg bg-navy-50 px-3 py-2 font-mono text-xs text-navy-800"
                  >
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-600" aria-hidden />
                    {name}
                  </li>
                ),
              )}
            </ul>

            <h2 className="mt-6 text-sm font-semibold text-navy-900">How to fix it</h2>
            <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-sm text-navy-600">
              <li>
                In Vercel, open <span className="font-medium">Project → Settings → Environment Variables</span>.
              </li>
              <li>
                Add both variables for the <span className="font-medium">Production</span> (and Preview)
                environments, taken from Supabase → <span className="font-medium">Project Settings → API</span>.
              </li>
              <li>
                Make sure <span className="font-mono text-xs">VITE_DEMO_MODE</span> is unset or{' '}
                <span className="font-mono text-xs">false</span>.
              </li>
              <li>
                Redeploy — Vite bakes environment variables in at build time, so an existing deployment
                will not pick them up without a new build.
              </li>
            </ol>

            <p className="mt-4 flex items-start gap-2 rounded-xl border border-[var(--color-hairline)] bg-white px-3 py-2.5 text-xs text-navy-500">
              <Database className="mt-0.5 h-4 w-4 shrink-0 text-navy-400" aria-hidden />
              <span>
                Only the public anon/publishable key belongs here. The Supabase{' '}
                <strong>service-role key must never be set as a VITE_ variable</strong> or exposed to the
                browser; it is used exclusively inside server-side Edge Functions.
              </span>
            </p>
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-[var(--color-hairline)] bg-navy-50/60 px-6 py-4">
            <button type="button" className="btn-secondary" onClick={() => window.location.reload()}>
              <RefreshCw className="h-4 w-4" aria-hidden />
              Re-check configuration
            </button>
          </div>
        </div>

        <p className="mt-4 text-center text-[11px] text-navy-500">
          Deployment details and the Supabase Auth URL settings are documented in{' '}
          <span className="font-mono">docs/DEPLOYMENT.md</span>.
        </p>
      </div>
    </div>
  );
}

/**
 * Shown when the app is configured but the database/auth service cannot be
 * reached (network failure, project paused, bad key, RLS/role misconfiguration).
 * Distinguishing this from "not configured" stops people from chasing the wrong
 * problem.
 */
export function ConnectionErrorScreen({
  title = 'Cannot reach the database',
  message,
  onRetry,
}: {
  title?: string;
  message?: string | null;
  onRetry?: () => void;
}) {
  return (
    <div className="flex min-h-full items-center justify-center bg-canvas px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="card p-6">
          <div className="flex items-start gap-3">
            <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
              <AlertTriangle className="h-5 w-5" aria-hidden />
            </span>
            <div className="min-w-0">
              <h1 className="text-base font-bold text-navy-900">{title}</h1>
              <p className="mt-1 text-sm text-navy-600">
                {message ||
                  'The app is connected to Supabase but the request failed. This is usually a paused project, an invalid key, a network block, or a database permission error.'}
              </p>
              <p className="mt-3 text-[11px] text-navy-500">
                Nothing has been changed or saved. If it persists, send this message to your administrator.
              </p>
            </div>
          </div>
          {onRetry && (
            <div className="mt-5 flex justify-end">
              <button type="button" className="btn-secondary" onClick={onRetry}>
                <RefreshCw className="h-4 w-4" aria-hidden />
                Try again
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
