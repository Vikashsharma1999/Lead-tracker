import { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { can, type Permission } from '@/lib/permissions';
import { subscribeToRealtime } from '@/data';
import { AppShell } from '@/components/AppShell';
import { Spinner } from '@/components/Spinner';
import { EmptyState } from '@/components/EmptyState';
import { ConfigErrorScreen, ConnectionErrorScreen } from '@/components/ConfigErrorScreen';
import { configState } from '@/lib/env';
import { LoginPage } from '@/pages/Login';
import { DashboardPage } from '@/pages/Dashboard';
import { LeadsPage } from '@/pages/Leads';
import { ImportPage } from '@/pages/Import';
import { ReportsPage } from '@/pages/Reports';
import { SyncCenterPage } from '@/pages/SyncCenter';
import { UsersPage } from '@/pages/Users';
import { AuditLogPage } from '@/pages/AuditLog';
import { SettingsPage } from '@/pages/Settings';
import { NotFoundPage } from '@/pages/NotFound';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: true,
      staleTime: 15_000,
    },
    mutations: { retry: 0 },
  },
});

function FullPageLoader() {
  return (
    <div className="flex min-h-full items-center justify-center bg-canvas">
      <div className="flex flex-col items-center gap-3 text-navy-500">
        <Spinner className="h-7 w-7 text-forest-600" />
        <p className="text-sm font-medium">Loading workspace…</p>
      </div>
    </div>
  );
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { profile, loading, error, retry } = useAuth();
  const location = useLocation();
  if (loading) return <FullPageLoader />;
  // A database/connection failure is not a missing session: say so instead of
  // bouncing the user to a login form that would also fail.
  if (error && !profile) return <ConnectionErrorScreen message={error} onRetry={retry} />;
  if (!profile) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  return <>{children}</>;
}

function RequirePermission({ permission, children }: { permission: Permission; children: React.ReactNode }) {
  const { profile } = useAuth();
  if (!can(profile?.role, permission)) {
    return (
      <div className="card">
        <EmptyState
          title="You do not have access to this page"
          description="This area is restricted by your role. Ask an administrator if you believe you should have access."
        />
      </div>
    );
  }
  return <>{children}</>;
}

/**
 * Database realtime → React Query invalidation.
 * Only subscribes for authenticated users; RLS still filters the payload.
 */
function RealtimeBridge() {
  const { profile } = useAuth();
  const qc = useQueryClient();

  useEffect(() => {
    if (!profile) return;
    return subscribeToRealtime((table) => {
      void qc.invalidateQueries({ queryKey: ['leads'] });
      void qc.invalidateQueries({ queryKey: ['summary'] });
      void qc.invalidateQueries({ queryKey: ['report'] });
      if (table === 'data_sources' || table === 'sync_jobs') {
        void qc.invalidateQueries({ queryKey: ['sources'] });
        void qc.invalidateQueries({ queryKey: ['sync-jobs'] });
      }
    });
  }, [profile, qc]);

  return null;
}

export function App() {
  // Fail closed. A production build without Supabase credentials renders an
  // explicit configuration screen — never sample data and never a default
  // admin session.
  if (configState === 'missing') return <ConfigErrorScreen />;

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <RealtimeBridge />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/"
            element={
              <RequireAuth>
                <AppShell />
              </RequireAuth>
            }
          >
            <Route index element={<DashboardPage />} />
            <Route path="leads" element={<LeadsPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route
              path="import"
              element={
                <RequirePermission permission="leads.import">
                  <ImportPage />
                </RequirePermission>
              }
            />
            <Route
              path="sources"
              element={
                <RequirePermission permission="sources.manage">
                  <SyncCenterPage />
                </RequirePermission>
              }
            />
            <Route
              path="users"
              element={
                <RequirePermission permission="users.manage">
                  <UsersPage />
                </RequirePermission>
              }
            />
            <Route
              path="audit"
              element={
                <RequirePermission permission="audit.view">
                  <AuditLogPage />
                </RequirePermission>
              }
            />
            <Route
              path="settings"
              element={
                <RequirePermission permission="settings.manage">
                  <SettingsPage />
                </RequirePermission>
              }
            />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
