import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Profile } from '@/types/domain';
import { getRepository } from '@/data';
import { appMode, isConfigMissing } from '@/lib/env';
import { isConfigurationError } from '@/lib/configError';
import { clearUserOfflineData } from '@/lib/offline/db';

interface AuthContextValue {
  /** The signed-in user's profile, or null when there is no session. */
  profile: Profile | null;
  /** True while the initial session/profile lookup is in flight. */
  loading: boolean;
  /**
   * A blocking problem with session restore or the database (not a bad
   * password). Rendering this distinctly is what turns "blank screen" into an
   * actionable message.
   */
  error: string | null;
  mode: 'live' | 'demo';
  signIn: (email: string, password: string) => Promise<Profile>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  /** Re-run the session lookup after a transient failure. */
  retry: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function describe(err: unknown): string {
  if (isConfigurationError(err)) {
    return 'Supabase is not configured for this deployment. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY and redeploy.';
  }
  if (err instanceof Error) return err.message;
  return 'Could not load your session.';
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    // A missing configuration must not crash the tree: the app shell renders a
    // dedicated "not configured" screen instead of demo data.
    if (isConfigMissing) {
      setProfile(null);
      setError('Supabase is not configured for this deployment.');
      setLoading(false);
      return;
    }

    let unsubscribe: (() => void) | undefined;
    try {
      const repository = getRepository();

      repository
        .getProfile()
        .then((p) => {
          if (!cancelled) setProfile(p);
        })
        .catch((err: unknown) => {
          if (!cancelled) setError(describe(err));
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });

      unsubscribe = repository.onAuthChange((p) => {
        if (cancelled) return;
        setProfile(p);
        setLoading(false);
      });
    } catch (err) {
      if (!cancelled) {
        setError(describe(err));
        setLoading(false);
      }
    }

    return () => {
      cancelled = true;
      unsubscribe?.();
    };
  }, [attempt]);

  const signIn = useCallback(async (email: string, password: string) => {
    setError(null);
    const p = await getRepository().signIn(email, password);
    setProfile(p);
    return p;
  }, []);

  const signOut = useCallback(async () => {
    // Never leave one user's queued customer data on a shared device.
    if (profile) {
      try {
        await clearUserOfflineData(profile.id);
      } catch {
        /* IndexedDB unavailable — nothing cached to clear */
      }
    }
    await getRepository().signOut();
    setProfile(null);
    setError(null);
  }, [profile]);

  const refreshProfile = useCallback(async () => {
    const p = await getRepository().getProfile();
    setProfile(p);
  }, []);

  const retry = useCallback(() => setAttempt((n) => n + 1), []);

  const value = useMemo<AuthContextValue>(
    () => ({ profile, loading, error, mode: appMode, signIn, signOut, refreshProfile, retry }),
    [profile, loading, error, signIn, signOut, refreshProfile, retry],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
