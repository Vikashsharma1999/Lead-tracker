import { useState, type FormEvent } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { AlertCircle, ArrowRight, Eye, EyeOff, Loader2, Lock, Mail, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { DemoBadge } from '@/components/DemoBadge';
import { appName, supportEmail } from '@/lib/env';
import { describeAuthError, validateCredentials } from '@/lib/authErrors';

export function LoginPage() {
  const { profile, loading, signIn, error: sessionError } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (!loading && profile) {
    const from = (location.state as { from?: string } | null)?.from ?? '/';
    return <Navigate to={from} replace />;
  }

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);

    const invalid = validateCredentials(email, password);
    if (invalid) {
      setError(invalid);
      return;
    }

    setSubmitting(true);
    try {
      await signIn(email, password);
      const from = (location.state as { from?: string } | null)?.from ?? '/';
      navigate(from, { replace: true });
    } catch (err) {
      setError(describeAuthError(err));
    } finally {
      setSubmitting(false);
    }
  };

  // Session-restore problems (paused project, bad key, rejected RLS read) are
  // reported here too, so the first screen a user sees is never a silent form.
  const shownError = error ?? sessionError;

  return (
    <div className="grid min-h-full lg:grid-cols-[1.05fr_1fr]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-forest-900 p-10 text-white lg:flex">
        <div
          className="pointer-events-none absolute -top-32 -left-24 h-96 w-96 rounded-full bg-forest-600/30 blur-3xl"
          aria-hidden
        />
        <div
          className="pointer-events-none absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-forest-500/20 blur-3xl"
          aria-hidden
        />
        <div className="relative">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/20 ring-inset">
              <ShieldCheck className="h-5 w-5" aria-hidden />
            </span>
            <span className="text-sm font-bold tracking-wide">{appName}</span>
          </div>

          <h1 className="mt-16 max-w-md text-3xl leading-tight font-bold text-balance">
            Every call, every follow-up, one live source of truth.
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-forest-100/80">
            Track lead status across your call team, keep spreadsheet imports consistent, and see
            exactly what happened on each lead — without double counting.
          </p>

          <ul className="mt-8 space-y-3 text-sm text-forest-100/90">
            {[
              'Role-based access: admins manage, callers work their queue',
              'Row Level Security on every lead record',
              'Realtime dashboard for the whole team',
              'Offline-tolerant call logging on mobile',
            ].map((item) => (
              <li key={item} className="flex items-start gap-2.5">
                <span className="mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-forest-500/40 ring-1 ring-forest-400/40 ring-inset">
                  <span className="h-1.5 w-1.5 rounded-full bg-forest-100" />
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-[11px] text-forest-200/60">
          Secure server-side integrations · No credentials in the browser bundle
        </p>
      </section>

      <section className="flex items-center justify-center bg-canvas px-4 py-10 sm:px-8">
        <div className="w-full max-w-md">
          <div className="mb-6 flex items-center justify-between lg:hidden">
            <span className="text-base font-bold text-forest-800">{appName}</span>
            <DemoBadge />
          </div>

          <div className="card p-6 sm:p-8">
            <h2 className="text-xl font-bold text-navy-900">Sign in</h2>
            <p className="mt-1 text-sm text-navy-500">
              Use your work account. Access is limited by your role.
            </p>

            <form onSubmit={handleSubmit} className="mt-5 space-y-4" noValidate>
              <label className="block">
                <span className="label">Email address</span>
                <div className="relative">
                  <Mail className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
                  <input
                    type="email"
                    autoComplete="username"
                    required
                    className="input pl-9"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                  />
                </div>
              </label>

              <label className="block">
                <span className="label">Password</span>
                <div className="relative">
                  <Lock className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    required
                    className="input pr-10 pl-9"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute top-1/2 right-2 -translate-y-1/2 rounded p-1.5 text-slate-400 hover:bg-slate-50"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </label>

              {shownError && (
                <div
                  role="alert"
                  className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs text-red-800"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
                  <span>{shownError}</span>
                </div>
              )}

              <button
                type="submit"
                className="btn-primary w-full py-2.5"
                disabled={submitting || loading}
              >
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
                {submitting ? 'Signing in…' : 'Sign in'}
                {!submitting && <ArrowRight className="h-4 w-4" aria-hidden />}
              </button>
            </form>

            <p className="mt-5 text-[11px] leading-relaxed text-navy-500">
              There is no self-service sign-up. Accounts are created by an administrator, who assigns
              your role — you cannot choose or change it yourself. Sessions are issued by Supabase Auth
              and every database row is protected by row-level security.
            </p>
            {supportEmail && (
              <p className="mt-2 text-[11px] text-navy-500">
                Need access? Contact{' '}
                <a className="font-medium text-forest-700 underline" href={`mailto:${supportEmail}`}>
                  {supportEmail}
                </a>
                .
              </p>
            )}
          </div>

        </div>
      </section>
    </div>
  );
}
