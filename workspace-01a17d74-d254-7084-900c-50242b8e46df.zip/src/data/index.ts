import type { Repository } from './repository';
import { SupabaseRepository } from './supabaseRepository';
import { getSupabase } from '@/lib/supabase';
import { isDemoMode, isSupabaseConfigured } from '@/lib/env';
import { assertConfigured, ConfigurationError } from '@/lib/configError';

let instance: Repository | null = null;

/**
 * The sample-data repository is registered only by the dev-server bootstrap in
 * `main.tsx`, through a dynamic `import()` sitting behind `import.meta.env.DEV`.
 * As a result no demo module — and none of its seeded emails or passwords —
 * is emitted into a production build at all.
 */
let demoFactory: (() => Repository) | null = null;

export function registerDemoRepository(factory: () => Repository): void {
  demoFactory = factory;
  instance = null;
}

export function getRepository(): Repository {
  if (!instance) {
    if (isDemoMode) {
      if (!demoFactory) {
        throw new ConfigurationError(['VITE_DEMO_MODE (dev-server bootstrap not loaded)']);
      }
      instance = demoFactory();
    } else {
      // Production: fail closed. No sample data, no default session.
      assertConfigured();
      instance = new SupabaseRepository();
    }
  }
  return instance;
}

export function setRepository(repo: Repository): void {
  instance = repo;
}

/**
 * Subscribe to database realtime changes.
 *
 * - live mode: Supabase Realtime `postgres_changes` on leads / call_activities /
 *   data_sources / sync_jobs. RLS still applies: callers only receive rows they
 *   are allowed to read.
 * - demo mode: a local event bus that fires on the same tab and on other tabs.
 *
 * Note: this is *database* realtime. It says nothing about Google Sheets or
 * Excel sync, which are separate pipelines shown on the Data Sources page.
 */
export function subscribeToRealtime(onChange: (table: string) => void): () => void {
  if (isDemoMode) {
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<{ table?: string }>).detail;
      onChange(detail?.table ?? 'leads');
    };
    window.addEventListener('ltd:realtime', handler);
    const storageHandler = (event: StorageEvent) => {
      if (event.key === 'ltd.demo.dataset.v1') onChange('leads');
    };
    window.addEventListener('storage', storageHandler);
    return () => {
      window.removeEventListener('ltd:realtime', handler);
      window.removeEventListener('storage', storageHandler);
    };
  }

  if (!isSupabaseConfigured) {
    // Unconfigured production build: nothing to subscribe to.
    return () => {};
  }

  const sb = getSupabase();
  const channel = sb
    .channel('db-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, () => onChange('leads'))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'call_activities' }, () =>
      onChange('call_activities'),
    )
    .on('postgres_changes', { event: '*', schema: 'public', table: 'data_sources' }, () =>
      onChange('data_sources'),
    )
    .on('postgres_changes', { event: '*', schema: 'public', table: 'sync_jobs' }, () =>
      onChange('sync_jobs'),
    )
    .subscribe();
  return () => {
    void sb.removeChannel(channel);
  };
}
