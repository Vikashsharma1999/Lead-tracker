import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App';
import { AuthProvider } from './hooks/useAuth';
import { ToastProvider } from './hooks/useToasts';
import { ErrorBoundary } from './components/ErrorBoundary';
import { registerDemoRepository } from './data';
import { isDemoMode } from './lib/env';
import { registerPWA } from './lib/pwa';
import './styles/index.css';

/**
 * Bootstrap.
 *
 * The sample-data repository is loaded with a dynamic import that only runs on
 * the Vite dev server (`import.meta.env.DEV`) when VITE_DEMO_MODE=true. In a
 * production build `import.meta.env.DEV` is replaced by `false`, so the demo
 * module is dead code and is removed from the bundle entirely — the deployed
 * app physically cannot fall back to demo data or demo logins.
 */
async function bootstrap(): Promise<void> {
  if (import.meta.env.DEV && isDemoMode) {
    const { DemoRepository } = await import('./data/demo/demoRepository');
    registerDemoRepository(() => new DemoRepository());
  }

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <ErrorBoundary>
        <ToastProvider>
          <AuthProvider>
            <App />
          </AuthProvider>
        </ToastProvider>
      </ErrorBoundary>
    </StrictMode>,
  );

  registerPWA();
}

void bootstrap();
