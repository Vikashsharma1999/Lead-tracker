# Lead Tracker Dashboard

A production-shaped, full-stack lead tracking CRM for call teams. Built with React + TypeScript + Vite,
Tailwind CSS, Supabase (Postgres, Auth, Realtime, Edge Functions), Recharts, SheetJS and a
service-worker-based PWA with an offline write queue.

> **Status: Phases 1–3 complete and working; Phases 4–6 are implemented server-side and require your
> own Google/Microsoft credentials to go live. Phase 7 (testing/deployment) is in progress — see
> [docs/PHASE_STATUS.md](docs/PHASE_STATUS.md).**
>
> With no Supabase project configured the app runs in **Demo mode**: a clearly labelled local dataset
> with synthetic records. Demo mode never reports an integration as connected.

![Dashboard](docs/screenshot-dashboard.png)

---

## 1. What is actually implemented

| Area | Status | Notes |
| --- | --- | --- |
| Responsive dashboard UI (KPI tiles, status pie, sync strip, lead table, mobile cards) | ✅ Phase 1 | Screenshots in `docs/` |
| Supabase schema, migrations, RLS, triggers, RPCs | ✅ Phase 2 | `supabase/migrations/*` |
| Auth (email/password + optional invite), roles, admin-only user management | ✅ Phase 2 | RLS + `guard_*` triggers; `admin-users` function |
| Server-enforced column permissions for callers | ✅ Phase 2 | `guard_lead_write()` trigger |
| Realtime invalidation across clients | ✅ Phase 2 | `subscribeToRealtime()` (RLS-filtered) |
| Excel/CSV import: multi-file, sheet picker, auto column mapping, preview, validation, duplicate policy, error report | ✅ Phase 3 | `/import` |
| Excel + CSV export of filtered records | ✅ Phase 3 | SheetJS 0.20.3 (official CDN build) |
| Google Sheets OAuth (PKCE + signed state), read/sync, write-back, retry/backoff, job log | 🟡 Phase 4 — code complete, needs credentials | `supabase/functions/*` |
| OneDrive/SharePoint workbook sync (Microsoft Graph) | 🔴 Phase 5 — not implemented | Setup guide only |
| Offline queue (IndexedDB), PWA install, conflict detection, admin conflict UI | 🟡 Phase 6 — partially complete | Queue + conflicts UI done; see phase doc |
| Auth & roles | ✅ Supabase Auth + DB roles (live sign-in not yet verified on the hosted project) | `npm run test:e2e:prod`, `docs/DEPLOYMENT.md` §0 |
| Unit + e2e test suites | ✅ 100 unit + 13 e2e + 3 production-guard specs passing | `npm test`, `npm run test:e2e`, `npm run test:e2e:prod` |
| Deployment config (Vercel, security headers, CI) | 🟡 Phase 7 | `vercel.json`, `.github/workflows/ci.yml` |

Everything in the table is real code in this repository — no mock endpoints, no fake "connected"
state, and no hardcoded dashboard numbers (KPIs are aggregated from records, in SQL in live mode).

---

## 2. Quick start

### Production / real data

```bash
cp .env.example .env.local       # then set VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY
npm install --legacy-peer-deps   # see "Why --legacy-peer-deps" below
npm run dev                      # http://localhost:5173
```

The app **fails closed**: without those two variables it renders a "This deployment is not
configured" screen. It never falls back to sample data, demo logins or a default admin session.
Real email/password sign-in via Supabase Auth is the only way in.

Follow **`docs/DEPLOYMENT.md` §0** for the full cutover: migrations, disabling sign-ups, Auth URL
configuration, bootstrapping the first admin, Vercel env vars and the verification checklist.

### Local sample data (development only)

```bash
echo "VITE_DEMO_MODE=true" >> .env.local
npm run dev
```

Sample data works **only** on the dev server. The demo backend is loaded through a dynamic
`import()` behind `import.meta.env.DEV`, so it is removed entirely from production builds — `npm run
verify:bundle` builds the app and fails if any demo credential, sample record or demo module appears
in `dist/`.

The synthetic accounts below exist only in that dev fixture (`src/data/demo/seed.ts`), never in a
deployment, and cannot authenticate against Supabase:

| Role | Email | Password |
| --- | --- | --- |
| Admin | `admin@demo.leadtracker.app` | `AdminDemo123!` |
| Caller | `rahul.caller@example.com` | `CallerDemo123!` |
| Caller | `sana.caller@example.com` | `CallerDemo123!` |

Demo data lives in `localStorage` (`ltd.demo.dataset.v1`); reset it from **Settings → Reset demo
dataset**. It is synthetic (invented names/phones).

**Why `--legacy-peer-deps`?** The current `vite-plugin-pwa` release declares peer ranges that npm 10
resolves aggressively; the flat install works fine, npm just needs permission to skip the strict peer
check. `npm install` alone also works when using npm 11+ or pnpm.

### Verified package versions
React 19.3.1 · Vite 7.3.7 · TypeScript 5.9.3 · Tailwind CSS 4.3.3 · @supabase/supabase-js 2.118.0 ·
Recharts 3.10.1 · SheetJS 0.20.3 (cdn.sheetjs.com) · TanStack Query 5.104.5 · Zod 4.6.7 ·
Vitest 3.2.7 · Playwright 1.64.1 · jsdom 26.1.0

> Vite 8 / TypeScript 7 / Vitest 5 exist but were rejected here: they require Node ≥ 22.12 (or fail to
> build under the 2 GB sandbox memory limit). Vite 7 + TS 5.9 is the current stable pairing that runs
> on Node 20 LTS as well as Node 22+.

---

## 3. Environment configuration

Copy `.env.example` → `.env.local` and fill in real values. **Only `VITE_`-prefixed values reach the
browser.** Everything else is for Edge Functions / server code.

```bash
cp .env.example .env.local
```

| Variable | Where used | Purpose |
| --- | --- | --- |
| `VITE_SUPABASE_URL` | Client | Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` | Client | Anon (publishable) key — safe with RLS |
| `VITE_APP_NAME`, `VITE_SUPPORT_EMAIL` | Client | Display only |
| `VITE_DEMO_MODE` | Client (dev server only) | `true` uses local sample data; ignored by production builds |
| `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` | Edge Functions | **Server only**; service role bypasses RLS |
| `OAUTH_STATE_SECRET` | Edge Functions | HMAC key for OAuth `state` (32+ random bytes) |
| `GOOGLE_OAUTH_CLIENT_ID/SECRET/REDIRECT_URI`, `GOOGLE_OAUTH_SCOPES` | Edge Functions | Google Sheets integration |
| `MS_OAUTH_*` | Edge Functions | Microsoft Graph (Phase 5) |
| `SYNC_MIN_INTERVAL_SECONDS`, `SYNC_MAX_ATTEMPTS` | Edge Functions | Sync scheduling |

**Never** put secrets in `VITE_*` variables: Vite inlines them into the public bundle. The repository
contains no secrets; `.env.example` holds placeholders only.

Local Edge Function secrets (not committed):

```bash
cp .env.example supabase/.env.local   # then edit, remove the VITE_ entries
```

---

## 4. Database setup (Supabase)

### 4a. Hosted project

1. Create a project at [supabase.com](https://supabase.com) (Postgres 15+).
2. `npm i -g supabase` then `supabase login` and `supabase link --project-ref <ref>`.
3. Push the migrations:
   ```bash
   supabase db push
   ```
   This creates every table, index, trigger, RLS policy and RPC described in
   [docs/SCHEMA.md](docs/SCHEMA.md), and seeds the ten configurable lead statuses.
4. Enable **Realtime** for `leads`, `call_activities`, `data_sources`, `sync_jobs` (the migration adds
   them to the `supabase_realtime` publication).
5. Create the first user (Auth → Users → *Add user*). The first profile in the table automatically
   becomes **admin**; every later account defaults to **caller**. Only an existing admin can grant
   admin (enforced by a trigger, not by the UI).
6. Put the project URL + anon key in `.env.local`, restart `npm run dev`, and sign in.

### 4b. Local stack (Docker required)

```bash
supabase start          # Postgres + Auth + Storage + Studio on :54321/:54322/:54323
supabase db reset       # applies migrations + supabase/seed.sql (synthetic data)
npm run fn:serve        # serves the Edge Functions on :54321/functions/v1
npm run dev
```

`supabase/seed.sql` inserts only synthetic rows and never marks an external source as connected.

### Database objects

Tables: `profiles`, `leads`, `call_activities`, `lead_assignments`, `data_sources`, `sync_jobs`,
`lead_conflicts`, `audit_logs`, `lead_statuses`, `integration_credentials`.
Key guarantees:

* `leads.phone_normalized` (generated column) is the duplicate key, with `normalize_phone()` shared by
  client and server.
* `unique (source_id, source_sheet_name, source_record_id)` makes re-imports idempotent.
* `leads.version` is bumped on every update and used for optimistic concurrency.
* Triggers: assignment history, audit log, updated_at, role-escalation guard, caller column guard.
* RPCs: `dashboard_summary`, `report_summary`, `import_leads`, `log_call`, `resolve_conflict`,
  `schedule_job_retry`.

---

## 5. Roles and permissions

| Capability | Admin | Caller |
| --- | --- | --- |
| View leads | all | only `assigned_to = auth.uid()` |
| Edit contact fields (name/phone/email) | ✅ | ❌ (trigger rejects) |
| Reassign leads / bulk assign | ✅ | ❌ |
| Bulk status change, delete leads | ✅ | ❌ |
| Log calls, notes, status, follow-up date | ✅ | ✅ for own leads |
| Import/export | ✅ import + export | export own leads |
| Data sources, sync, conflicts | ✅ | ❌ |
| Users, roles, audit log, settings | ✅ | ❌ |

Enforcement layers (all three, not just the first):

1. Client permission map (`src/lib/permissions.ts`) for UX.
2. Row Level Security (`supabase/migrations/20260101000200_rls.sql`).
3. Trigger-based column/role guards (`guard_lead_write`, `guard_profile_write`) and
   `SECURITY DEFINER` RPCs that re-check `is_admin()`.

---

## 6. Google Sheets integration (Phase 4)

Server-side only; the browser never sees a client secret or refresh token.

1. In Google Cloud Console create an OAuth client (**Web application**), enable **Google Sheets API** and
   **Google Drive API**.
2. Add the callback URL as an authorized redirect URI:
   `https://<project-ref>.functions.supabase.co/google-oauth-callback`.
3. Set the function secrets and deploy:
   ```bash
   supabase secrets set \
     GOOGLE_OAUTH_CLIENT_ID=... GOOGLE_OAUTH_CLIENT_SECRET=... \
     GOOGLE_OAUTH_REDIRECT_URI=https://<ref>.functions.supabase.co/google-oauth-callback \
     OAUTH_STATE_SECRET=$(openssl rand -hex 32) \
     APP_REDIRECT_URL=https://your-app.vercel.app/sources
   npm run fn:deploy
   ```
4. As an admin: **Data Sources → Guided setup → Google Sheets**, create a source, run
   `google-oauth-start`, complete consent, then call `source-sync` with `action: 'test_connection'`.
5. Only after that test succeeds does `connection_status` become `connected`. Sync, retry and write-back
   are all actions of `source-sync`:

   | Action | Effect |
   | --- | --- |
   | `test_connection` | Live Sheets read; sets connected/error honestly |
   | `sync_now` / `incremental` | Reads the worksheet, maps columns, upserts via `import_leads`, writes a `sync_jobs` row |
   | `retry_failed` | Re-queues failed jobs; backoff is `schedule_job_retry` (2^n s, capped 300 s, 5 attempts) |
   | `write_back` | Batch-updates the mapped status/notes cells for selected leads |

**Sync cadence:** Supabase Edge Functions are request-driven. The 15–60 s target is met by a scheduler
(pg_cron → `net.http_post` or an external scheduler) calling `source-sync` per source; configure
`sync_interval_seconds` (minimum 15) on each source. Nothing claims to be "live" without that job
running — the UI shows the last success time from `data_sources.last_success_at`.

---

## 7. Excel / CSV integration (Phase 3)

* `/import` accepts `.xlsx`, `.xls`, `.csv`, multiple files, and multiple worksheet tabs.
* Headers are auto-mapped (30+ aliases); every mapping is editable before import.
* Rows are validated (required name/phone, phone/email format) and invalid rows are excluded and
  reported; error reports export to Excel/CSV.
* Duplicate handling per import: **update** (default), **skip**, **create** (admin opt-in).
* Re-importing the same file updates rows in place via `(source, worksheet, source_row_id)`.
* Uploaded files are **not** linked for continuous sync. For that, use OneDrive/SharePoint (Phase 5) or
  the local sync agent described in [docs/SYNC_ARCHITECTURE.md](docs/SYNC_ARCHITECTURE.md).

---

## 8. Offline PWA (Phase 6)

* Installable (manifest + icons + service worker). The app shell is precached; **API and Supabase
  requests are `NetworkOnly`** — no customer data goes into the HTTP cache.
* Queued writes live in IndexedDB (`lead-tracker-offline`), scoped per user id, wiped on sign-out.
* The queue replays in order on reconnect, with exponential backoff and a hard attempt cap.
* An offline edit is labelled **"Saved on this device only"** until the server confirms it. A stale
  version produces a recorded conflict, not an overwrite; admins resolve it in
  **Data Sources → Sync conflicts**.

What offline mode does *not* do: it does not merge records automatically, does not cache credentials,
and does not claim success before the server responds.

---

## 9. Testing

```bash
npm run typecheck     # strict TS, no emit
npm test              # 88 unit tests (Vitest)
npm run test:e2e      # Playwright: desktop + mobile (auto-starts the dev server)
npm run test:e2e:prod # Production build with no env vars must fail closed (no demo mode)
npm run verify:bundle # Build + assert no demo credentials/sample data in dist/
```

Coverage highlights (`tests/unit`, `tests/e2e`):

* Login, invalid credentials, sign-out; caller vs admin navigation and URL guards.
* Excel import through the UI: file → auto column mapping → validation preview → import → searchable record.
* Caller isolation: only assigned leads, forbidden fields rejected, no bulk operations.
* KPI maths: unique-lead counting, no double counting, callbacks/overdue, bucket sums.
* Duplicate detection + all three policies; phone normalisation across formats.
* Excel/CSV: parsing `.xlsx`/`.xls`/`.csv`, header auto-mapping, row validation, export content and CSV
  escaping.
* Google Sheets mapping and write-back cell addressing (shared module used by the Edge Function).
* Offline queue: replay, conflict capture, backoff caps, queued-vs-synced reporting.
* Import idempotency, audit logging, self-demotion guard, aggregate scoping.

Playwright needs browser binaries: `npx playwright install chromium`. In minimal Linux containers you
may also need the system libraries (`libnss3`, `libnspr4`, …) — see `docs/DEPLOYMENT.md`.

---

## 10. Deployment (Vercel + Supabase)

1. Push this repository to GitHub.
2. Apply the Supabase migrations and bootstrap the first admin — `docs/DEPLOYMENT.md` §0 steps 1–4.
3. Vercel → **New Project** → import the repo (framework: Vite; `vercel.json` is included).
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as environment variables (Production +
   Preview), leave `VITE_DEMO_MODE` unset, and **redeploy** — Vite inlines env vars at build time.
   Do **not** add the service role key here.
5. In Supabase → Authentication → URL configuration, set Site URL to the Vercel domain and add
   `https://<domain>/**` to the redirect allow-list.
6. Deploy/verify with the checklist in `docs/DEPLOYMENT.md` §0 step 7. HTTPS is automatic; HSTS, CSP,
   `X-Frame-Options` and `Permissions-Policy` are set in `vercel.json`.
7. Install the PWA from the browser ("Install app") to verify the manifest and service worker.

If the deployed app shows **"This deployment is not configured"**, the env vars are missing,
still placeholders, or the deployment was not rebuilt after they were added. That screen is the
correct, fail-closed behaviour — it replaced the old automatic demo fallback.

Full runbook, including backups and rollback: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).
Security model and threat notes: [docs/SECURITY.md](docs/SECURITY.md).

---

## 11. Repository layout

```
src/
  components/     UI primitives (AppShell, KPI cards, chart, table, modals, conflict panel…)
  pages/          Dashboard, Leads, Import, Reports, SyncCenter, Users, AuditLog, Settings, Login
  data/           Repository interface + Supabase implementation + labelled demo backend
  hooks/          Auth, queries/mutations, online state, toasts, offline queue
  lib/            env, permissions, KPI maths, duplicates, excel, offline queue, PWA
  styles/         Tailwind theme tokens (forest green / navy / canvas)
supabase/
  migrations/     schema → functions → RLS → seed statuses
  functions/      google-oauth-start, google-oauth-callback, source-sync, admin-users
  seed.sql        synthetic local data
tests/
  unit/           Vitest suites
  e2e/            Playwright specs
docs/             phase status, schema, security, deployment, sync architecture
```

---

## 12. Known limitations (honest list)

* **Microsoft Graph / OneDrive / SharePoint sync is not implemented** (Phase 5). The UI shows the setup
  guide and reports "not configured".
* **Google integration is unverified against a live project** in this environment: the code paths,
  scopes, PKCE flow and write-back mapping exist and are unit-tested, but you must supply credentials
  and run `test_connection` before trusting it. The app will keep saying "Not configured" until then.
* Interval sync depends on an external scheduler; there is no in-process timer.
* Legacy `.xls` parsing is delegated to SheetJS; exotic/encrypted workbooks may be rejected.
* Realtime uses Supabase `postgres_changes`; large bulk operations may briefly deliver many events.
* Conflicts are recorded for stale versions and offline replays; there is no three-way merge UI.
* No billing/multi-tenant separation: one workspace per Supabase project.
