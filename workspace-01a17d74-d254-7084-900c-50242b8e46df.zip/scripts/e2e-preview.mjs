#!/usr/bin/env node
/**
 * Serves a *production* build of the app with the Supabase environment variables
 * explicitly blanked, for tests/e2e/productionMode.spec.ts.
 *
 * The build happens here, inside the Playwright `webServer` command, so the URL
 * Playwright polls is only reachable once `dist-e2e` actually exists
 * (Playwright launches webServers before `globalSetup`).
 */

import { execFileSync, spawn } from 'node:child_process';

const PORT = 4173;

const cleanEnv = {
  ...process.env,
  VITE_DEMO_MODE: '',
  VITE_SUPABASE_URL: '',
  VITE_SUPABASE_ANON_KEY: '',
  NODE_ENV: 'production',
};

console.log('› Building production bundle with no Supabase configuration…');
execFileSync('npx', ['vite', 'build', '--outDir', 'dist-e2e', '--logLevel', 'warn'], {
  stdio: 'inherit',
  env: cleanEnv,
});

console.log(`› Serving dist-e2e on http://127.0.0.1:${PORT}`);
const preview = spawn(
  'npx',
  ['vite', 'preview', '--outDir', 'dist-e2e', '--port', String(PORT), '--strictPort', '--host', '127.0.0.1'],
  { stdio: 'inherit' },
);

const shutdown = () => preview.kill('SIGTERM');
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
preview.on('exit', (code) => process.exit(code ?? 0));
