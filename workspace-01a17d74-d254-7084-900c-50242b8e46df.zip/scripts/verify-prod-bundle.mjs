#!/usr/bin/env node
/**
 * Production bundle guard.
 *
 * Builds the app exactly as Vercel does (`vite build`, production mode, no
 * local .env) and then scans the output for anything that must never ship:
 *
 *   - demo account emails or passwords
 *   - the sample-data repository module
 *   - any auto-login / default-session marker
 *
 * It also asserts that the "not configured" screen IS present, because that is
 * the intended behaviour of a build with no Supabase environment variables.
 *
 * Usage:
 *   node scripts/verify-prod-bundle.mjs            # build + scan
 *   node scripts/verify-prod-bundle.mjs --no-build # scan existing dist/
 *
 * Exits non-zero on any violation, so it can run in CI.
 */

import { execFileSync } from 'node:child_process';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';

const BANNED = [
  { label: 'demo admin email', pattern: /admin@demo\.leadtracker\.app/i },
  { label: 'demo caller email', pattern: /[a-z]+\.caller@example\.com/i },
  { label: 'demo admin password', pattern: /AdminDemo123/ },
  { label: 'demo caller password', pattern: /CallerDemo123/ },
  { label: 'demo credentials block', pattern: /Demo credentials/ },
  { label: 'demo repository selector', pattern: /DemoRepository/ },
];

const distDir = join(process.cwd(), 'dist');

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...walk(full));
    else out.push(full);
  }
  return out;
}

if (!process.argv.includes('--no-build')) {
  console.log('› Building production bundle (vite build)…');
  execFileSync('npx', ['vite', 'build', '--logLevel', 'warn'], { stdio: 'inherit' });
}

const textExtensions = new Set(['.js', '.mjs', '.css', '.html', '.json', '.webmanifest', '.map']);
const files = walk(distDir).filter((f) => textExtensions.has(extname(f)));

const violations = [];
let sawConfigScreen = false;

for (const file of files) {
  const content = readFileSync(file, 'utf8');
  if (content.includes('This deployment is not configured')) sawConfigScreen = true;
  for (const { label, pattern } of BANNED) {
    if (pattern.test(content)) violations.push(`${label} found in ${file.replace(process.cwd(), '.')}`);
  }
}

console.log(`› Scanned ${files.length} build files in ./dist`);

if (violations.length) {
  console.error('\n✗ Production bundle contains demo/demo-login artefacts:');
  for (const v of violations) console.error(`  - ${v}`);
  console.error('\nDemo data must be dev-server only (see src/main.tsx + src/lib/env.ts).');
  process.exit(1);
}

if (!sawConfigScreen) {
  console.error('\n✗ The "not configured" screen is missing from the bundle.');
  console.error('  A production build with no env vars must render it instead of demo data.');
  process.exit(1);
}

console.log('✓ No demo credentials, sample data or demo repository in the production bundle.');
console.log('✓ Misconfiguration screen present (fails closed instead of falling back to demo).');
