import { defineConfig, devices } from '@playwright/test';

const PREVIEW_URL = 'http://127.0.0.1:4173';

/**
 * Guard rail for the production cutover.
 *
 * Builds the app exactly as Vercel does — `vite build`, no Supabase env vars —
 * and asserts it renders the "not configured" screen instead of dropping into a
 * demo admin session. This is the regression that shipped to
 * https://lead-tracker-dashboard-gamma.vercel.app.
 *
 * Run with: npm run test:e2e:prod
 */
export default defineConfig({
  testDir: './tests/e2e',
  testMatch: ['**/productionMode.spec.ts'],
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: PREVIEW_URL,
    trace: 'on-first-retry',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'node scripts/e2e-preview.mjs',
    url: PREVIEW_URL,
    reuseExistingServer: true,
    timeout: 180_000,
  },
});
