-- 20260101000400_harden_auth.sql
--
-- Production cutover, part 1: authentication and role hardening.
--
-- Background — three ways the previous schema could hand out admin:
--
--   1. `handle_new_user()` promoted *the first profile ever created* to admin.
--      On an empty production project that means whoever signs up first becomes
--      admin. Self-service sign-up must therefore be disabled (dashboard) and
--      this rule must never exist in production code.
--   2. The same trigger honoured `raw_user_meta_data ->> 'role'` when
--      `created_by_admin` was present. Both fields are client-controlled when a
--      user calls `auth.signUp({ options: { data: {...} } })`, so anyone able to
--      reach the sign-up endpoint could self-assign admin.
--   3. `authenticated` held table-level UPDATE on `public.profiles`, covering the
--      `role` and `active` columns. The trigger guard stopped role escalation, but
--      column-level grants give a second, independent barrier that survives a
--      future policy mistake.
--
-- After this migration:
--   * new auth users always get role 'caller' — never admin, never from metadata;
--   * `active` may only be changed by an administrator;
--   * authenticated users may write exactly one column of their own profile:
--     `full_name`;
--   * role / activation changes go through the `admin-users` Edge Function, which
--     re-verifies the caller from the database, uses the service role, and writes
--     an audit_logs row.
--
-- The very first admin is created deliberately, out of band, by an operator —
-- see the commented bootstrap block at the end of this file.

-- -----------------------------------------------------------------------------
-- 1. New users are always callers
-- -----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- No first-user-is-admin rule. No trust in user metadata. Ever.
  -- The admin-users Edge Function sets the intended role afterwards with the
  -- service role, which is the only path that can produce an admin profile.
  insert into public.profiles (id, full_name, email, role, active)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1)),
    new.email,
    'caller',
    true
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

-- -----------------------------------------------------------------------------
-- 2. Tighten the profile write guard
-- -----------------------------------------------------------------------------
create or replace function public.guard_profile_write()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  actor_role public.user_role;
begin
  -- Service role / SQL console: `auth.uid()` is null when the service key or a
  -- direct psql session performs the write. That is the audited admin path.
  if auth.uid() is null then
    return new;
  end if;

  select role into actor_role from public.profiles where id = auth.uid();

  if tg_op = 'INSERT' then
    if actor_role is distinct from 'admin' then
      raise exception 'Only administrators can create profiles' using errcode = '42501';
    end if;
    return new;
  end if;

  -- Role changes: admins only, and nobody may strip their own admin rights.
  if new.role is distinct from old.role then
    if actor_role is distinct from 'admin' then
      raise exception 'Only administrators can change a role' using errcode = '42501';
    end if;
    if old.id = auth.uid() then
      raise exception 'You cannot change your own role' using errcode = '42501';
    end if;
  end if;

  -- Activation changes: admins only, and never on yourself.
  if new.active is distinct from old.active then
    if actor_role is distinct from 'admin' then
      raise exception 'Only administrators can activate or deactivate an account'
        using errcode = '42501';
    end if;
    if old.id = auth.uid() then
      raise exception 'You cannot activate or deactivate your own account'
        using errcode = '42501';
    end if;
  end if;

  -- The auth-linked email is owned by Supabase Auth, not by this table.
  if new.email is distinct from old.email then
    raise exception 'Email addresses are managed by Supabase Auth' using errcode = '42501';
  end if;

  return new;
end;
$$;

-- Recreate the trigger so the guard also covers INSERT (it previously ran on
-- UPDATE only).
drop trigger if exists profiles_guard_write on public.profiles;
create trigger profiles_guard_write
  before insert or update on public.profiles
  for each row execute function public.guard_profile_write();

-- -----------------------------------------------------------------------------
-- 3. Column-level privileges: least privilege on profiles
-- -----------------------------------------------------------------------------
-- Belt and braces on top of RLS: even if a policy were loosened later, an
-- authenticated client still cannot write role/active/email columns directly.
revoke insert, update, delete on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;

-- -----------------------------------------------------------------------------
-- 4. One profile per email address (case-insensitive)
-- -----------------------------------------------------------------------------
-- Already guaranteed: public.profiles.email is `citext not null unique`, so
-- 'Admin@Example.com' and 'admin@example.com' collide by construction. No extra
-- index is needed here.

-- -----------------------------------------------------------------------------
-- 5. Keep the audit trail complete for role/activation changes
-- -----------------------------------------------------------------------------
create or replace function public.audit_profile_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.role is distinct from old.role then
    insert into public.audit_logs (user_id, user_name, action, entity_type, entity_id, metadata)
    values (auth.uid(), new.full_name, 'user.role_changed', 'profile', new.id::text,
            jsonb_build_object('from', old.role, 'to', new.role));
  end if;

  if new.active is distinct from old.active then
    insert into public.audit_logs (user_id, user_name, action, entity_type, entity_id, metadata)
    values (auth.uid(), new.full_name,
            case when new.active then 'user.reactivated' else 'user.deactivated' end,
            'profile', new.id::text, jsonb_build_object('active', new.active));
  end if;

  return new;
end;
$$;

drop trigger if exists trg_profiles_audit on public.profiles;
create trigger trg_profiles_audit
  after update on public.profiles
  for each row execute function public.audit_profile_change();

-- -----------------------------------------------------------------------------
-- 6. Bootstrap (manual, once, by an operator)
-- -----------------------------------------------------------------------------
-- This migration deliberately does NOT create an admin. To grant the first
-- admin, create the user in Supabase → Authentication → Users → "Add user"
-- (with "Auto Confirm User"), then run this once in the SQL editor:
--
--   update public.profiles
--      set role = 'admin'
--    where lower(email) = lower('you@yourcompany.com');
--
-- Verify with:
--   select id, email, role, active from public.profiles order by created_at;
--
-- From then on, admins manage everyone else from the in-app Users screen,
-- which calls the admin-users Edge Function.
