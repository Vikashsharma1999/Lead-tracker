// admin-users — privileged user provisioning.
//
// Why a server function: creating auth users needs the service-role key, which
// must never exist in the browser. This function re-verifies that the caller is
// an active admin (from the database, not the JWT claims) before using it.

import { handler, requireAdmin, adminClient, json, fail, audit, HttpError } from '../_shared/http.ts';

Deno.serve(
  handler(async (req) => {
    if (req.method !== 'POST') return fail('Use POST', 405);
    const caller = await requireAdmin(req);
    const body = await req.json().catch(() => ({}));
    const action = String(body?.action ?? 'create');

    const admin = adminClient();

    if (action === 'create') {
      const email = String(body?.email ?? '').trim().toLowerCase();
      const fullName = String(body?.full_name ?? '').trim();
      const role = body?.role === 'admin' ? 'admin' : 'caller';

      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail('A valid work email is required');
      if (!fullName) return fail('Full name is required');

      const { data: existing } = await admin
        .from('profiles')
        .select('id, role')
        .eq('email', email)
        .maybeSingle();
      if (existing) throw new HttpError(409, 'A user with this email already exists');

      // Invite the user: Supabase sends the activation email. No password ever
      // passes through this function or the dashboard.
      //
      // Only display data goes into the metadata. The role is NOT passed through
      // user metadata: `handle_new_user` always creates a 'caller' profile, and
      // the authoritative role is written below with the service role after the
      // auth user exists (see 20260101000400_harden_auth.sql).
      const { data: invited, error: inviteError } = await admin.auth.admin.inviteUserByEmail(email, {
        data: { full_name: fullName },
        redirectTo: Deno.env.get('APP_INVITE_REDIRECT_URL') ?? undefined,
      });
      if (inviteError || !invited?.user) {
        return fail(inviteError?.message ?? 'Could not invite the user', 400);
      }

      const { data: profile, error: profileError } = await admin
        .from('profiles')
        .upsert(
          { id: invited.user.id, full_name: fullName, email, role, active: true },
          { onConflict: 'id' },
        )
        .select()
        .single();
      if (profileError) return fail('User invited but the profile could not be written', 500);

      await audit(admin, caller, 'user.created', 'profile', invited.user.id, { role });
      return json({ ok: true, profile });
    }

    if (action === 'set_active') {
      const id = String(body?.user_id ?? '');
      const active = Boolean(body?.active);
      if (!id) return fail('user_id is required');
      if (id === caller.user.id && !active) return fail('You cannot deactivate your own account');

      if (!active) {
        const { count } = await admin
          .from('profiles')
          .select('id', { count: 'exact', head: true })
          .eq('role', 'admin')
          .eq('active', true)
          .neq('id', id);
        if (!count) return fail('At least one active administrator must remain');
      }

      await admin.from('profiles').update({ active }).eq('id', id);
      if (!active) {
        // Revoke refresh tokens so an already-signed-in session cannot continue.
        await admin.auth.admin.signOut(id, 'global');
      }
      await audit(admin, caller, active ? 'user.reactivated' : 'user.deactivated', 'profile', id);
      return json({ ok: true });
    }

    if (action === 'set_role') {
      const id = String(body?.user_id ?? '');
      const role = body?.role === 'admin' ? 'admin' : 'caller';
      if (!id) return fail('user_id is required');
      if (id === caller.user.id && role !== 'admin') {
        return fail('You cannot remove your own administrator role');
      }

      // Never let the workspace end up with zero active admins — that would make
      // the Users screen and all role management permanently unreachable.
      if (role !== 'admin') {
        const { count } = await admin
          .from('profiles')
          .select('id', { count: 'exact', head: true })
          .eq('role', 'admin')
          .eq('active', true)
          .neq('id', id);
        if (!count) return fail('At least one active administrator must remain');
      }

      const { error } = await admin.from('profiles').update({ role }).eq('id', id);
      if (error) return fail(error.message, 400);
      await audit(admin, caller, 'user.role_changed', 'profile', id, { role });
      return json({ ok: true });
    }

    return fail(`Unknown action: ${action}`, 400);
  }),
);
