import { expect, test } from '@playwright/test';
import * as XLSX from 'xlsx';
import { writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

/**
 * Excel import flow through the real UI: parse → map → validate → import.
 * Uses a temporary synthetic workbook; no customer data.
 */
function buildWorkbook(): string {
  const rows = [
    ['Full Name', 'Mobile Number', 'Email Address', 'Lead Status', 'Follow Up Date', 'Remarks'],
    ['E2E Alpha', '+971501110001', 'e2e.alpha@example.invalid', 'Interested', '2026-11-05', 'Wants pricing'],
    ['E2E Bravo', '+971501110002', '', 'Call Back', '', 'Call after 6pm'],
    ['', '+971501110003', '', '', '', 'Missing name (should be rejected)'],
  ];
  const sheet = XLSX.utils.aoa_to_sheet(rows);
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, 'Leads');
  const path = join(tmpdir(), 'e2e-leads-import.xlsx');
  writeFileSync(path, XLSX.write(book, { bookType: 'xlsx', type: 'buffer' }));
  return path;
}

test('imports an Excel file with column mapping and validation', async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== 'chromium', 'desktop layout');

  await page.goto('/');
  await page.getByRole('button', { name: 'Admin demo' }).click();
  await page.getByRole('button', { name: /^Sign in$/ }).click();
  await expect(page.getByRole('heading', { name: 'Lead Tracker Dashboard' })).toBeVisible();

  await page.goto('/import');
  await expect(page.getByRole('heading', { name: 'Import Spreadsheet Data' })).toBeVisible();

  await page.locator('input[type="file"]').setInputFiles(buildWorkbook());

  // Column mapping is auto-detected from the headers.
  await expect(page.getByRole('heading', { name: '3 · Map columns' })).toBeVisible();
  await expect(page.getByText('2 ready · 1 with errors · 3 total rows')).toBeVisible();

  // Preview shows the validation failure for the incomplete row.
  await expect(page.getByText('Name is required').first()).toBeVisible();

  await page.getByRole('button', { name: /Import 2 rows/i }).click();
  await expect(page.getByRole('heading', { name: 'Import finished' })).toBeVisible();
  await expect(page.getByText('Import complete')).toBeVisible();

  // The imported leads are now searchable in the dashboard table.
  await page.goto('/leads');
  await page.getByRole('searchbox', { name: 'Search leads' }).fill('E2E Alpha');
  await expect(page.locator('tbody tr').first()).toContainText('E2E Alpha');
});
