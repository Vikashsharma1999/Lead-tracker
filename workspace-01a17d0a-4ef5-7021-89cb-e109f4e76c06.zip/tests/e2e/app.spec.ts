import { expect, test, type Page } from '@playwright/test';

/**
 * End-to-end flows against the demo backend (no credentials required).
 * Set E2E_BASE_URL + VITE_SUPABASE_* to run the same specs against a live build.
 */

async function openMenuIfMobile(page: Page) {
  const menuButton = page.getByRole('button', { name: 'Open menu' });
  if (await menuButton.isVisible().catch(() => false)) {
    await menuButton.click();
  }
}

async function signIn(page: Page, role: 'admin' | 'caller') {
  await page.goto('/');
  await page.getByRole('button', { name: role === 'admin' ? 'Admin demo' : 'Caller demo' }).click();
  await page.getByRole('button', { name: /^Sign in$/ }).click();
  await expect(page.getByRole('heading', { name: 'Lead Tracker Dashboard' })).toBeVisible();
}

test.describe('login', () => {
  test('shows the sign-in form with demo credentials clearly labelled', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Sign in' })).toBeVisible();
    await expect(page.getByText(/Supabase is not configured/i)).toBeVisible();
    await expect(page.getByRole('button', { name: 'Admin demo' })).toBeVisible();
    await expect(page.getByLabel('Email address')).toBeVisible();
  });

  test('rejects a wrong password with a safe message', async ({ page }) => {
    await page.goto('/');
    await page.getByLabel('Email address').fill('admin@demo.leadtracker.app');
    await page.getByRole('textbox', { name: 'Password' }).fill('wrong-password');
    await page.getByRole('button', { name: /^Sign in$/ }).click();
    await expect(page.getByRole('alert')).toContainText(/invalid email or password/i);
  });

  test('signs an administrator in and out', async ({ page }) => {
    await signIn(page, 'admin');
    await expect(page.getByRole('heading', { name: 'Lead Tracker Dashboard' })).toBeVisible();
    // The account card (role + sign out) lives in the sidebar on desktop and in
    // the drawer on mobile.
    await openMenuIfMobile(page);
    await page.getByRole('button', { name: 'Sign out' }).click();
    await expect(page.getByRole('heading', { name: 'Sign in' })).toBeVisible();
  });
});

test.describe('dashboard', () => {
  test('renders KPI tiles that add up to the unique lead total', async ({ page }) => {
    await signIn(page, 'admin');

    const totalTile = page.getByRole('button', { name: /Total Leads/i });
    await expect(totalTile).toBeVisible();
    const total = Number((await totalTile.locator('p').nth(1).innerText()).replace(/,/g, ''));

    const statusTiles = [
      'Not Dialed',
      'Dialed',
      'Interested',
      'Not Interested',
      'Call Back',
      'Webinar Link Shared',
      'Follow-up Pending',
    ];
    let summed = 0;
    for (const label of statusTiles) {
      const tile = page.getByRole('button', { name: new RegExp(`^${label}`, 'i') });
      const value = Number((await tile.locator('p').nth(1).innerText()).replace(/,/g, ''));
      summed += value;
    }
    // The seven explicit tiles may not cover every status, but they can never
    // exceed the unique lead total.
    expect(summed).toBeLessThanOrEqual(total);
    expect(total).toBeGreaterThan(0);
  });

  test('states that integrations are not connected in demo mode', async ({ page }) => {
    await signIn(page, 'admin');
    await expect(page.getByText('Not configured').first()).toBeVisible();
    await expect(page.getByText(/Last successful sync|Last success:/i).first()).toBeVisible();
  });

  test('opens the join-call dialog and logs a call', async ({ page }) => {
    await signIn(page, 'admin');
    await page.getByRole('button', { name: /log (a )?call/i }).first().click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByLabel('Call notes').fill('E2E test call note');
    await page.getByRole('button', { name: /Save call & update lead/i }).click();
    await expect(page.getByText(/Call activity logged/i)).toBeVisible();
  });
});

test.describe('leads table', () => {
  test('searches by name and narrows the result set', async ({ page, isMobile }) => {
    test.skip(isMobile, 'desktop table layout — covered by the mobile card spec');
    await signIn(page, 'admin');
    await page.goto('/leads');
    await expect(page.locator('tbody tr').first()).toBeVisible();
    const initial = await page.locator('tbody tr').count();

    await page.getByRole('searchbox', { name: 'Search leads' }).fill('Joseph');
    await expect(page.locator('tbody tr').first()).toContainText('Joseph');
    expect(await page.locator('tbody tr').count()).toBeLessThanOrEqual(initial);
  });

  test('filters by status through the URL', async ({ page }) => {
    await signIn(page, 'admin');
    await page.goto('/leads?status=interested');
    await expect(page.getByText(/matching leads/i)).toBeVisible();
    const badges = page.locator('tbody tr span.chip');
    const count = await badges.count();
    for (let i = 0; i < Math.min(count, 3); i += 1) {
      await expect(badges.nth(i)).toContainText('Interested');
    }
  });

  test('edits a lead and reflects the change', async ({ page, isMobile }) => {
    test.skip(isMobile, 'desktop table layout — covered by the mobile card spec');
    await signIn(page, 'admin');
    await page.goto('/leads');
    await page.getByRole('button', { name: /^Edit / }).first().click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByLabel('Notes').fill('Updated from the E2E suite');
    await page.getByRole('button', { name: /Save changes/i }).click();
    await expect(page.getByText('Lead updated')).toBeVisible();
  });
});

test.describe('role-based access', () => {
  test('callers do not see admin-only navigation', async ({ page }) => {
    await signIn(page, 'caller');
    await openMenuIfMobile(page);
    await expect(page.getByRole('link', { name: 'Leads', exact: true }).first()).toBeVisible();
    await expect(page.getByRole('link', { name: 'Callers & Access' })).toHaveCount(0);
    await expect(page.getByRole('link', { name: 'Data Sources' })).toHaveCount(0);
    await expect(page.getByRole('link', { name: 'Audit History' })).toHaveCount(0);
  });

  test('callers only see their own leads', async ({ page }) => {
    await signIn(page, 'caller');
    await page.goto('/leads');
    await expect(page.getByRole('heading', { name: 'My Leads' })).toBeVisible();
    await expect(page.locator('tbody')).not.toContainText('Unassigned');
  });

  test('callers cannot reach the admin users page by URL', async ({ page }) => {
    await signIn(page, 'caller');
    await page.goto('/users');
    await expect(page.getByText(/do not have access to this page/i)).toBeVisible();
  });
});

test.describe('responsive layout', () => {
  test('mobile shows card rows instead of the wide table', async ({ page, isMobile }) => {
    test.skip(!isMobile, 'mobile project only');
    await signIn(page, 'admin');
    await page.goto('/leads');
    await expect(page.locator('table').first()).toBeHidden();
    await expect(page.getByRole('button', { name: /Log call/i }).first()).toBeVisible();
    await expect(page.getByRole('button', { name: 'Open menu' })).toBeVisible();
  });
});
