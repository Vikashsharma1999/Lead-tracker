import { describe, expect, it } from 'vitest';
import {
  can,
  canAccessLead,
  canChangeRole,
  editableFields,
  permissionsFor,
  sanitizeLeadPatch,
} from '@/lib/permissions';
import type { Lead, Profile } from '@/types/domain';

const admin: Profile = {
  id: 'admin-1',
  full_name: 'Ayesha Khan',
  email: 'admin@example.invalid',
  role: 'admin',
  active: true,
  created_at: new Date().toISOString(),
};

const caller: Profile = {
  id: 'caller-1',
  full_name: 'Rahul Menon',
  email: 'rahul@example.invalid',
  role: 'caller',
  active: true,
  created_at: new Date().toISOString(),
};

function makeLead(overrides: Partial<Lead> = {}): Lead {
  return {
    id: 'lead-1',
    source_id: 'src-1',
    source_external_id: 'sheet-1',
    source_sheet_name: 'Sheet1',
    source_record_id: 'row-2',
    name: 'Test Lead',
    phone: '+971500000001',
    email: 'test@example.invalid',
    lead_status: 'not_dialed',
    lead_outcome: 'pending',
    assigned_to: 'caller-1',
    last_call_at: null,
    next_follow_up_at: null,
    notes: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    version: 1,
    ...overrides,
  };
}

describe('role permissions', () => {
  it('grants admins the management permissions', () => {
    expect(can('admin', 'leads.view_all')).toBe(true);
    expect(can('admin', 'users.manage')).toBe(true);
    expect(can('admin', 'sources.manage')).toBe(true);
    expect(can('admin', 'conflicts.resolve')).toBe(true);
  });

  it('never grants a caller administrative rights', () => {
    const callerPermissions = permissionsFor('caller');
    expect(callerPermissions.has('leads.view_all')).toBe(false);
    expect(callerPermissions.has('users.manage')).toBe(false);
    expect(callerPermissions.has('leads.assign')).toBe(false);
    expect(callerPermissions.has('sources.manage')).toBe(false);
    expect(callerPermissions.has('audit.view')).toBe(false);
  });

  it('returns no permissions for anonymous users', () => {
    expect(permissionsFor(null).size).toBe(0);
    expect(can(undefined, 'leads.view_assigned')).toBe(false);
  });

  it('limits caller-editable fields to call-related columns', () => {
    const fields = editableFields('caller');
    expect(fields).toContain('lead_status');
    expect(fields).toContain('notes');
    expect(fields).not.toContain('assigned_to');
    expect(fields).not.toContain('phone');
    expect(fields).not.toContain('name');
  });

  it('strips forbidden fields from a caller patch', () => {
    const patch = sanitizeLeadPatch('caller', {
      lead_status: 'interested',
      notes: 'Called, keen',
      assigned_to: 'caller-2',
      phone: '+971599999999',
    });
    expect(patch).toEqual({ lead_status: 'interested', notes: 'Called, keen' });
  });

  it('keeps admin patches intact', () => {
    const patch = sanitizeLeadPatch('admin', { assigned_to: 'caller-2', name: 'New name' });
    expect(patch).toEqual({ assigned_to: 'caller-2', name: 'New name' });
  });
});

describe('lead visibility', () => {
  it('lets a caller access only their own leads', () => {
    expect(canAccessLead(caller, makeLead())).toBe(true);
    expect(canAccessLead(caller, makeLead({ assigned_to: 'caller-2' }))).toBe(false);
    expect(canAccessLead(caller, makeLead({ assigned_to: null }))).toBe(false);
  });

  it('lets an admin access any lead', () => {
    expect(canAccessLead(admin, makeLead({ assigned_to: 'caller-2' }))).toBe(true);
    expect(canAccessLead(admin, makeLead({ assigned_to: null }))).toBe(true);
  });

  it('denies everything to a signed-out visitor', () => {
    expect(canAccessLead(null, makeLead())).toBe(false);
  });
});

describe('role escalation guards', () => {
  it('blocks callers from promoting anyone', () => {
    expect(canChangeRole(caller, 'caller-1', 'admin')).toBe(false);
    expect(canChangeRole(caller, 'caller-2', 'admin')).toBe(false);
  });

  it('blocks self-elevation and self-demotion side effects', () => {
    expect(canChangeRole(caller, caller.id, 'admin')).toBe(false);
    expect(canChangeRole(admin, admin.id, 'caller')).toBe(false);
    expect(canChangeRole(admin, 'caller-2', 'admin')).toBe(true);
  });

  it('requires a signed-in actor', () => {
    expect(canChangeRole(null, 'caller-2', 'admin')).toBe(false);
  });
});
