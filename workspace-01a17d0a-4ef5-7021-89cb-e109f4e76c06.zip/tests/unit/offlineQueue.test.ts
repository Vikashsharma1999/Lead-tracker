import { beforeEach, describe, expect, it, vi } from 'vitest';
import { backoffDelayMs, flushQueue, MAX_ATTEMPTS } from '@/lib/offline/queue';
import type { Repository } from '@/data/repository';

// In-memory stand-in for IndexedDB so the queue logic is tested deterministically.
const store = new Map<string, Record<string, unknown>>();

vi.mock('@/lib/offline/db', () => ({
  enqueueWrite: vi.fn(async (input: Record<string, unknown>) => {
    const record = {
      ...input,
      id: `q-${store.size + 1}`,
      createdAt: new Date().toISOString(),
      attempts: 0,
      lastError: null,
      status: 'pending',
    };
    store.set(record.id as string, record);
    return record;
  }),
  listQueuedWrites: vi.fn(async (userId: string) =>
    [...store.values()].filter((row) => row.userId === userId) as never,
  ),
  updateQueuedWrite: vi.fn(async (id: string, patch: Record<string, unknown>) => {
    const existing = store.get(id);
    if (existing) store.set(id, { ...existing, ...patch });
  }),
  removeQueuedWrite: vi.fn(async (id: string) => {
    store.delete(id);
  }),
  clearUserOfflineData: vi.fn(async () => store.clear()),
}));

import { enqueueWrite } from '@/lib/offline/db';

function makeRepository(overrides: Partial<Repository> = {}): Repository {
  return {
    mode: 'demo',
    signIn: vi.fn(),
    signOut: vi.fn(),
    getProfile: vi.fn(),
    onAuthChange: vi.fn(() => () => undefined),
    listLeads: vi.fn(),
    listAllLeads: vi.fn(),
    getLead: vi.fn(),
    updateLead: vi.fn(async () => ({ lead: {} as never })),
    bulkAssign: vi.fn(),
    bulkSetStatus: vi.fn(),
    deleteLeads: vi.fn(),
    addCallActivity: vi.fn(async () => ({ id: 'a1' }) as never),
    listCallActivities: vi.fn(),
    listProfiles: vi.fn(),
    createProfile: vi.fn(),
    updateProfile: vi.fn(),
    listSources: vi.fn(),
    createSource: vi.fn(),
    listSyncJobs: vi.fn(),
    testSourceConnection: vi.fn(),
    requestSync: vi.fn(),
    retryFailedJobs: vi.fn(),
    toggleSourceSync: vi.fn(),
    getSummary: vi.fn(),
    getReport: vi.fn(),
    listAuditLogs: vi.fn(),
    importLeads: vi.fn(),
    listConflicts: vi.fn(),
    resolveConflict: vi.fn(),
    exportLeads: vi.fn(),
    ...overrides,
  } as Repository;
}

const options = { repository: makeRepository(), userId: 'caller-1', role: 'caller' as const };

describe('offline queue', () => {
  beforeEach(() => {
    store.clear();
    vi.clearAllMocks();
  });

  it('uses exponential backoff capped at 60 seconds', () => {
    expect(backoffDelayMs(0)).toBe(2000);
    expect(backoffDelayMs(1)).toBe(4000);
    expect(backoffDelayMs(3)).toBe(16000);
    expect(backoffDelayMs(10)).toBe(60000);
  });

  it('replays a queued lead update and removes it after server confirmation', async () => {
    const repository = makeRepository();
    await enqueueWrite({
      userId: 'caller-1',
      kind: 'lead_update',
      payload: { leadId: 'lead-1', patch: { lead_status: 'interested' }, baseVersion: 2 },
      label: 'Update lead',
      baseVersion: 2,
    });

    const result = await flushQueue({ ...options, repository });

    expect(result.synced).toBe(1);
    expect(repository.updateLead).toHaveBeenCalledWith('lead-1', { lead_status: 'interested' }, 2);
    expect(store.size).toBe(0);
  });

  it('reports conflicts instead of overwriting the server copy', async () => {
    const repository = makeRepository({
      updateLead: vi.fn(async () => ({
        lead: { id: 'lead-1' } as never,
        conflict: { field: 'lead_status', localValue: 'interested', serverValue: 'call_back', serverVersion: 4 },
      })),
    });

    await enqueueWrite({
      userId: 'caller-1',
      kind: 'lead_update',
      payload: { leadId: 'lead-1', patch: { lead_status: 'interested' }, baseVersion: 2 },
      label: 'Update lead',
      baseVersion: 2,
    });

    const result = await flushQueue({ ...options, repository });

    expect(result.conflicts).toHaveLength(1);
    expect(result.synced).toBe(0);
    // The queued write is retained for admin review, not silently dropped.
    expect(store.size).toBe(1);
    expect([...store.values()][0].status).toBe('failed');
  });

  it('keeps writes queued while offline and retries when the connection returns', async () => {
    const onlineSpy = vi.spyOn(navigator, 'onLine', 'get').mockReturnValue(false);
    await enqueueWrite({
      userId: 'caller-1',
      kind: 'lead_update',
      payload: { leadId: 'lead-1', patch: { notes: 'offline note' } },
      label: 'Offline edit',
    });

    const result = await flushQueue(options);
    expect(result.synced).toBe(0);
    expect(store.size).toBe(1);

    onlineSpy.mockReturnValue(true);
    const retry = await flushQueue(options);
    expect(retry.synced).toBe(1);
    expect(store.size).toBe(0);
    onlineSpy.mockRestore();
  });

  it('marks a permanent server rejection as failed after the first attempt', async () => {
    const repository = makeRepository({
      updateLead: vi.fn(async () => {
        throw new Error('Callers cannot change: assigned_to');
      }),
    });
    await enqueueWrite({
      userId: 'caller-1',
      kind: 'lead_update',
      payload: { leadId: 'lead-1', patch: { assigned_to: 'caller-2' } },
      label: 'Illegal edit',
    });

    const result = await flushQueue({ ...options, repository });
    expect(result.failed).toBe(1);
    expect([...store.values()][0].status).toBe('failed');
    expect([...store.values()][0].lastError).toContain('Callers cannot change');
  });

  it('never reports a queued call as synced before the server confirms it', async () => {
    const repository = makeRepository();
    await enqueueWrite({
      userId: 'caller-1',
      kind: 'call_activity',
      payload: {
        leadId: 'lead-1',
        outcome: 'positive',
        notes: 'Spoke to the lead',
        callTime: new Date().toISOString(),
        leadStatus: 'interested',
      },
      label: 'Call log',
    });

    // Still queued before flush → nothing has reached the server.
    expect(store.size).toBe(1);
    expect(repository.addCallActivity).not.toHaveBeenCalled();

    await flushQueue({ ...options, repository });
    expect(repository.addCallActivity).toHaveBeenCalledTimes(1);
    expect(store.size).toBe(0);
  });

  it('exposes a bounded retry count', () => {
    expect(MAX_ATTEMPTS).toBeGreaterThanOrEqual(3);
  });
});
