import { describe, expect, it } from 'vitest';
import {
  buildWriteBackUpdates,
  columnLetter,
  mapSheetRow,
  parseSheetValues,
  statusLabel,
} from '../../supabase/functions/_shared/sheets';

const MAPPING = {
  name: 'Full Name',
  phone: 'Mobile',
  email: 'Email',
  lead_status: 'Lead Status',
  notes: 'Notes',
  next_follow_up_at: 'Follow Up',
  source_record_id: 'Row ID',
};

const VALUES = [
  ['Full Name', 'Mobile', 'Email', 'Lead Status', 'Notes', 'Follow Up', 'Row ID'],
  ['Test Lead', '+971501234567', 'test@example.invalid', 'Interested', 'Wants a demo', '2026-11-01', 'row-2'],
  ['', '', '', '', '', '', ''],
  ['Second Lead', '0507654321', '', 'Call Back', '', '', 'row-4'],
];

describe('parseSheetValues', () => {
  it('reads headers and skips blank rows', () => {
    const { headers, rows } = parseSheetValues(VALUES);
    expect(headers[0]).toBe('Full Name');
    expect(rows).toHaveLength(2);
    expect(rows[1]['Full Name']).toBe('Second Lead');
  });

  it('handles an empty worksheet', () => {
    expect(parseSheetValues([])).toEqual({ headers: [], rows: [] });
  });
});

describe('mapSheetRow', () => {
  it('maps configured columns onto internal lead fields', () => {
    const { rows } = parseSheetValues(VALUES);
    const mapped = mapSheetRow(rows[0], MAPPING, {
      spreadsheetId: 'sheet-123',
      worksheet: 'Registrations',
      rowNumber: 2,
    });

    expect(mapped).toMatchObject({
      name: 'Test Lead',
      phone: '+971501234567',
      email: 'test@example.invalid',
      lead_status: 'interested',
      notes: 'Wants a demo',
      source_external_id: 'sheet-123',
      source_sheet_name: 'Registrations',
      source_record_id: 'row-2',
    });
    expect(mapped.next_follow_up_at).toBeTruthy();
  });

  it('normalises human status labels from the sheet', () => {
    const { rows } = parseSheetValues(VALUES);
    const mapped = mapSheetRow(rows[1], MAPPING, {
      spreadsheetId: 'sheet-123',
      worksheet: 'Registrations',
      rowNumber: 4,
    });
    expect(mapped.lead_status).toBe('call_back');
    expect(mapped.email).toBeNull();
  });

  it('falls back to not_dialed for unknown statuses instead of failing', () => {
    const mapped = mapSheetRow(
      { 'Full Name': 'X', Mobile: '+971500000000', 'Lead Status': 'Unknown thing' },
      MAPPING,
      { spreadsheetId: 's', worksheet: 'W', rowNumber: 9 },
    );
    expect(mapped.lead_status).toBe('not_dialed');
  });

  it('derives a stable fallback row id when none is mapped', () => {
    const mapped = mapSheetRow({ 'Full Name': 'X', Mobile: '1' }, {}, {
      spreadsheetId: 's',
      worksheet: 'W',
      rowNumber: 12,
    });
    expect(mapped.source_record_id).toBe('row-12');
    expect(mapped.lead_status).toBe('not_dialed');
  });

  it('treats unmapped columns as empty rather than throwing', () => {
    const mapped = mapSheetRow({}, MAPPING, { spreadsheetId: 's', worksheet: 'W', rowNumber: 2 });
    expect(mapped.name).toBe('');
    expect(mapped.phone).toBe('');
  });
});

describe('write-back addressing', () => {
  it('converts column indexes to spreadsheet letters', () => {
    expect(columnLetter(0)).toBe('A');
    expect(columnLetter(3)).toBe('D');
    expect(columnLetter(25)).toBe('Z');
    expect(columnLetter(26)).toBe('AA');
    expect(columnLetter(27)).toBe('AB');
    expect(columnLetter(-1)).toBeNull();
  });

  it('formats status labels for the sheet', () => {
    expect(statusLabel('call_back')).toBe('Call Back');
    expect(statusLabel('webinar_link_shared')).toBe('Webinar Link Shared');
  });

  it('targets the correct row and columns for each lead', () => {
    const updates = buildWriteBackUpdates(
      [{ source_record_id: 'row-5', lead_status: 'interested', notes: 'Called' }],
      VALUES[0],
      'Registrations',
      MAPPING,
    );

    expect(updates).toEqual([
      { range: "'Registrations'!D5", values: [['Interested']] },
      { range: "'Registrations'!E5", values: [['Called']] },
    ]);
  });

  it('skips rows without a numeric source identifier', () => {
    const updates = buildWriteBackUpdates(
      [
        { source_record_id: null, lead_status: 'interested', notes: null },
        { source_record_id: 'row-1', lead_status: 'interested', notes: null }, // header row
        { source_record_id: 'abc', lead_status: 'interested', notes: null },
      ],
      VALUES[0],
      'Registrations',
      MAPPING,
    );
    expect(updates).toHaveLength(0);
  });

  it('refuses to write when the status column is not mapped', () => {
    expect(() =>
      buildWriteBackUpdates(
        [{ source_record_id: 'row-2', lead_status: 'interested', notes: null }],
        ['Name'],
        'Sheet1',
        { name: 'Name' },
      ),
    ).toThrow(/status column is not mapped/i);
  });

  it('writes only status when notes are not mapped', () => {
    const updates = buildWriteBackUpdates(
      [{ source_record_id: 'row-3', lead_status: 'no_answer', notes: 'ignored' }],
      VALUES[0],
      'Registrations',
      { lead_status: 'Lead Status' },
    );
    expect(updates).toHaveLength(1);
    expect(updates[0].range).toBe("'Registrations'!D3");
  });
});
