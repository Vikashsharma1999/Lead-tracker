import { describe, expect, it } from 'vitest';
import {
  buildDuplicateIndex,
  findDuplicate,
  normalizeEmail,
  normalizeName,
  normalizePhone,
  planDuplicateHandling,
} from '@/lib/duplicates';
import type { Lead } from '@/types/domain';

function lead(id: string, phone: string, email: string | null, name = 'Test Lead'): Lead {
  const now = new Date().toISOString();
  return {
    id,
    source_id: 'src-1',
    source_external_id: null,
    source_sheet_name: 'Sheet1',
    source_record_id: `row-${id}`,
    name,
    phone,
    email,
    lead_status: 'not_dialed',
    lead_outcome: 'pending',
    assigned_to: null,
    last_call_at: null,
    next_follow_up_at: null,
    notes: null,
    created_at: now,
    updated_at: now,
    version: 1,
  };
}

describe('normalisation', () => {
  it('reduces phone formatting and country prefixes to a comparable key', () => {
    expect(normalizePhone('+971 50 123 4567')).toBe('501234567');
    expect(normalizePhone('00971501234567')).toBe('501234567');
    expect(normalizePhone('(050) 123-4567')).toBe('501234567');
    expect(normalizePhone(null)).toBe('');
  });

  it('normalises emails and names', () => {
    expect(normalizeEmail('  Test.User@Example.COM ')).toBe('test.user@example.com');
    expect(normalizeName('  Test   Lead ')).toBe('test lead');
  });
});

describe('duplicate detection', () => {
  const existing = [lead('1', '+971501234567', 'test@example.invalid', 'Test Lead')];
  const index = buildDuplicateIndex(existing);

  it('matches on phone regardless of formatting', () => {
    const match = findDuplicate(index, { phone: '0501234567', name: 'Someone Else' });
    expect(match?.key).toBe('phone');
    expect(match?.existing.id).toBe('1');
  });

  it('matches on email case-insensitively', () => {
    const match = findDuplicate(index, { email: 'TEST@example.invalid', phone: '+971599999999' });
    expect(match?.key).toBe('email');
  });

  it('returns null when nothing matches', () => {
    expect(findDuplicate(index, { phone: '+971509999999', email: 'new@example.invalid' })).toBeNull();
  });
});

describe('duplicate policies', () => {
  const index = buildDuplicateIndex([lead('1', '+971501234567', 'dup@example.invalid', 'Test Lead')]);
  const rows = [
    { name: 'Test Lead', phone: '0501234567', email: null }, // duplicate
    { name: 'Fresh Lead', phone: '+971507654321', email: 'fresh@example.invalid' },
  ];

  it('skips duplicates when policy is skip', () => {
    const decisions = planDuplicateHandling(index, rows, 'skip');
    expect(decisions[0].action).toBe('skip');
    expect(decisions[1].action).toBe('insert');
  });

  it('updates duplicates when policy is update', () => {
    const decisions = planDuplicateHandling(index, rows, 'update');
    expect(decisions[0]).toMatchObject({ action: 'update', existingId: '1' });
  });

  it('allows deliberate duplicates when policy is create', () => {
    const decisions = planDuplicateHandling(index, rows, 'create');
    expect(decisions.every((d) => d.action === 'insert')).toBe(true);
  });
});
