import { describe, expect, it } from 'vitest';
import { computeSummary, isOverdue, isSameLocalDay, kpiValue, percentage } from '@/lib/kpi';
import type { Lead, LeadStatus } from '@/types/domain';
import { LEAD_STATUSES } from '@/lib/constants';

function lead(id: string, status: LeadStatus, overrides: Partial<Lead> = {}): Lead {
  const now = new Date().toISOString();
  return {
    id,
    source_id: 'src-1',
    source_external_id: null,
    source_sheet_name: 'Sheet1',
    source_record_id: `row-${id}`,
    name: `Lead ${id}`,
    phone: '+971500000000',
    email: null,
    lead_status: status,
    lead_outcome: 'pending',
    assigned_to: 'caller-1',
    last_call_at: null,
    next_follow_up_at: null,
    notes: null,
    created_at: now,
    updated_at: now,
    version: 1,
    ...overrides,
  };
}

const REF = new Date('2026-10-23T09:00:00.000Z');

describe('computeSummary', () => {
  it('counts each lead exactly once across the exclusive status buckets', () => {
    const leads = [
      lead('1', 'not_dialed'),
      lead('2', 'not_dialed'),
      lead('3', 'interested'),
      lead('4', 'call_back'),
      lead('5', 'not_interested'),
    ];
    const summary = computeSummary(leads, 0, REF);

    expect(summary.totalLeads).toBe(5);
    const bucketTotal = Object.values(summary.byStatus).reduce((a, b) => a + b, 0);
    expect(bucketTotal).toBe(summary.totalLeads);
    expect(summary.byStatus.not_dialed).toBe(2);
    expect(summary.byStatus.interested).toBe(1);
  });

  it('does not double count duplicated rows with the same id', () => {
    const duplicated = [lead('1', 'interested'), lead('1', 'interested'), lead('2', 'dialed')];
    const summary = computeSummary(duplicated, 0, REF);
    expect(summary.totalLeads).toBe(2);
    expect(summary.byStatus.interested).toBe(1);
  });

  it('keeps call activity counts separate from unique lead counts', () => {
    const leads = [lead('1', 'interested'), lead('2', 'dialed')];
    const withManyCalls = computeSummary(leads, 42, REF);
    expect(withManyCalls.totalLeads).toBe(2);
    expect(withManyCalls.callsToday).toBe(42);
  });

  it('counts callbacks due today and overdue follow-ups', () => {
    const leads = [
      lead('1', 'call_back', { next_follow_up_at: new Date('2026-10-23T11:00:00.000Z').toISOString() }),
      lead('2', 'follow_up_pending', { next_follow_up_at: new Date('2026-10-20T11:00:00.000Z').toISOString() }),
      lead('3', 'follow_up_pending', { next_follow_up_at: new Date('2026-10-30T11:00:00.000Z').toISOString() }),
    ];
    const summary = computeSummary(leads, 0, REF);
    expect(summary.callbacksDueToday).toBe(1);
    expect(summary.overdueFollowUps).toBe(1);
  });

  it('counts unassigned leads', () => {
    const summary = computeSummary(
      [lead('1', 'not_dialed', { assigned_to: null }), lead('2', 'not_dialed')],
      0,
      REF,
    );
    expect(summary.unassigned).toBe(1);
  });

  it('returns zeroed buckets for an empty dataset', () => {
    const summary = computeSummary([], 0, REF);
    expect(summary.totalLeads).toBe(0);
    for (const status of LEAD_STATUSES) {
      expect(summary.byStatus[status.value]).toBe(0);
    }
  });

  it('maps KPI tile keys to bucket values', () => {
    const summary = computeSummary([lead('1', 'interested')], 0, REF);
    expect(kpiValue(summary, 'total')).toBe(1);
    expect(kpiValue(summary, 'interested')).toBe(1);
    expect(kpiValue(summary, 'no_answer')).toBe(0);
  });
});

describe('date helpers', () => {
  it('detects the same local day', () => {
    expect(isSameLocalDay(new Date('2026-10-23T01:00:00').toISOString(), REF)).toBe(true);
    expect(isSameLocalDay(new Date('2026-10-22T01:00:00').toISOString(), REF)).toBe(false);
    expect(isSameLocalDay(null, REF)).toBe(false);
  });

  it('treats earlier days as overdue but not later the same day', () => {
    expect(isOverdue(new Date('2026-10-22T10:00:00').toISOString(), REF)).toBe(true);
    expect(isOverdue(new Date('2026-10-23T23:30:00').toISOString(), REF)).toBe(false);
    expect(isOverdue(new Date('2026-10-25T10:00:00').toISOString(), REF)).toBe(false);
  });
});

describe('percentage', () => {
  it('rounds to one decimal and handles a zero total', () => {
    expect(percentage(1, 3)).toBe(33.3);
    expect(percentage(0, 0)).toBe(0);
  });
});
