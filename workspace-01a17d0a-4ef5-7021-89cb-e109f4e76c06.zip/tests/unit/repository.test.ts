import { beforeEach, describe, expect, it, vi } from 'vitest';

/**
 * Behavioural tests for the repository contract, exercised through the demo
 * backend. The same expectations must hold for SupabaseRepository, whose rules
 * are enforced in Postgres (see supabase/migrations/*_rls.sql).
 */

const storage = new Map<string, string>();

vi.stubGlobal('localStorage', {
  getItem: (key: string) => storage.get(key) ?? null,
  setItem: (key: string, value: string) => void storage.set(key, value),
  removeItem: (key: string) => void storage.delete(key),
  clear: () => storage.clear(),
  key: (index: number) => [...storage.keys()][index] ?? null,
  get length() {
    return storage.size;
  },
});

const { DemoRepository } = await import('@/data/demo/demoRepository');
const { DEMO_USERS } = await import('@/data/demo/seed');

// Every test starts from a clean synthetic dataset so mutations do not leak.
beforeEach(() => {
  storage.clear();
  vi.restoreAllMocks();
});

async function signInAs(role: 'admin' | 'caller'): Promise<InstanceType<typeof DemoRepository>> {
  const repo = new DemoRepository();
  const account = DEMO_USERS.find((user) => user.role === role)!;
  await repo.signIn(account.email, account.password);
  return repo;
}

describe('authentication', () => {
  it('rejects invalid credentials with a safe message', async () => {
    const repo = new DemoRepository();
    await expect(repo.signIn('nobody@example.invalid', 'wrong')).rejects.toThrow(
      /invalid email or password/i,
    );
  });

  it('signs a caller in and exposes their profile', async () => {
    const repo = await signInAs('caller');
    const profile = await repo.getProfile();
    expect(profile?.role).toBe('caller');
    expect(profile?.active).toBe(true);
  });

  it('refuses every data call once signed out', async () => {
    const repo = await signInAs('admin');
    await repo.signOut();
    await expect(repo.listLeads({}, { page: 1, pageSize: 10, sort: { field: 'created_at', direction: 'desc' } }))
      .rejects.toThrow(/not authenticated/i);
  });
});

describe('caller data isolation', () => {
  it('only returns leads assigned to the signed-in caller', async () => {
    const repo = await signInAs('caller');
    const profile = (await repo.getProfile())!;
    const page = await repo.listLeads(
      {},
      { page: 1, pageSize: 100, sort: { field: 'created_at', direction: 'desc' } },
    );

    expect(page.rows.length).toBeGreaterThan(0);
    expect(page.rows.every((lead) => lead.assigned_to === profile.id)).toBe(true);
  });

  it('cannot read a lead assigned to somebody else', async () => {
    const repo = await signInAs('caller');
    const adminRepo = await signInAs('admin');
    const others = await adminRepo.listLeads(
      { assignedTo: 'usr-caller-2' },
      { page: 1, pageSize: 1, sort: { field: 'created_at', direction: 'desc' } },
    );
    expect(others.rows[0]).toBeDefined();
    await expect(repo.getLead(others.rows[0].id)).resolves.toBeNull();
  });

  it('blocks a caller from editing contact fields', async () => {
    const repo = await signInAs('caller');
    const [lead] = (await repo.listAllLeads({}, 1))!;
    await expect(repo.updateLead(lead.id, { phone: '+971500000099' })).rejects.toThrow(
      /cannot change/i,
    );
  });

  it('allows a caller to update call fields on their own lead', async () => {
    const repo = await signInAs('caller');
    const [lead] = (await repo.listAllLeads({}, 1))!;
    const result = await repo.updateLead(lead.id, { lead_status: 'call_back', notes: 'Call tomorrow' });
    expect(result.conflict).toBeUndefined();
    expect(result.lead.lead_status).toBe('call_back');
    expect(result.lead.version).toBe(lead.version + 1);
  });

  it('blocks callers from bulk assignment and deletion', async () => {
    const repo = await signInAs('caller');
    const leadIds = (await repo.listAllLeads({}, 3)).map((lead) => lead.id);
    await expect(repo.bulkAssign(leadIds, 'usr-caller-2')).rejects.toThrow(/administrator/i);
    await expect(repo.bulkSetStatus(leadIds, 'interested')).rejects.toThrow(/administrator/i);
    await expect(repo.deleteLeads(leadIds)).rejects.toThrow(/administrator/i);
  });

  it('blocks callers from reading the audit log', async () => {
    const repo = await signInAs('caller');
    await expect(repo.listAuditLogs()).rejects.toThrow(/administrator/i);
  });
});

describe('admin capabilities', () => {
  it('sees every lead and can reassign in bulk', async () => {
    const repo = await signInAs('admin');
    const all = await repo.listAllLeads({}, 500);
    const ids = all.slice(0, 3).map((lead) => lead.id);

    const changed = await repo.bulkAssign(ids, 'usr-caller-2');
    expect(changed).toBe(3);

    for (const id of ids) {
      const lead = await repo.getLead(id);
      expect(lead?.assigned_to).toBe('usr-caller-2');
    }
  });

  it('records an audit entry for privileged actions', async () => {
    const repo = await signInAs('admin');
    const ids = (await repo.listAllLeads({}, 2)).map((lead) => lead.id);
    await repo.bulkSetStatus(ids, 'interested');

    const logs = await repo.listAuditLogs(20);
    expect(logs.some((log) => log.action === 'lead.bulk_status_changed')).toBe(true);
  });

  it('prevents an admin from removing their own admin role', async () => {
    const repo = await signInAs('admin');
    const profile = (await repo.getProfile())!;
    await expect(repo.updateProfile(profile.id, { role: 'caller' })).rejects.toThrow(
      /cannot remove your own administrator role/i,
    );
  });

  it('deactivates a caller and keeps their leads', async () => {
    const repo = await signInAs('admin');
    const updated = await repo.updateProfile('usr-caller-1', { active: false });
    expect(updated.active).toBe(false);

    const assigned = await repo.listAllLeads({ assignedTo: 'usr-caller-1' }, 10);
    expect(assigned.length).toBeGreaterThan(0);
  });
});

describe('optimistic concurrency and conflicts', () => {
  it('reports a conflict instead of overwriting a newer server version', async () => {
    const repo = await signInAs('admin');
    const [lead] = await repo.listAllLeads({}, 1);

    // Another user edits first.
    await repo.updateLead(lead.id, { lead_status: 'interested' });

    // A stale client tries to write with the old version.
    const stale = await repo.updateLead(lead.id, { lead_status: 'not_interested' }, lead.version);
    expect(stale.conflict).toBeDefined();
    expect(stale.conflict?.serverVersion).toBe(lead.version + 1);
    expect(stale.lead.lead_status).toBe('interested'); // server copy preserved
  });

  it('lets an admin resolve an open conflict by accepting the local value', async () => {
    const repo = await signInAs('admin');
    const [lead] = await repo.listAllLeads({}, 1);
    await repo.updateLead(lead.id, { notes: 'server change' });

    // Simulate the offline queue having recorded a conflict.
    const conflicts = (repo as unknown as { conflicts: unknown[] }).conflicts;
    conflicts.push({
      id: 'conflict-1',
      lead_id: lead.id,
      field: 'notes',
      local_value: 'local change',
      server_value: 'server change',
      status: 'open',
      created_at: new Date().toISOString(),
    });

    expect(await repo.listConflicts()).toHaveLength(1);
    await repo.resolveConflict('conflict-1', 'resolved_local');

    expect(await repo.listConflicts()).toHaveLength(0);
    expect((await repo.getLead(lead.id))?.notes).toBe('local change');
  });

  it('rejects conflict resolution by a caller', async () => {
    const repo = await signInAs('caller');
    await expect(repo.resolveConflict('any', 'resolved_local')).rejects.toThrow(/administrator/i);
  });
});

describe('imports', () => {
  it('adds new rows and counts them on the sync job', async () => {
    const repo = await signInAs('admin');
    const result = await repo.importLeads(
      'src-sample-local',
      [
        { name: 'Import One', phone: '+971509000001', email: 'one@example.invalid' },
        { name: 'Import Two', phone: '+971509000002', email: 'two@example.invalid' },
      ],
      'update',
    );

    expect(result).toMatchObject({ added: 2, updated: 0, skipped: 0 });

    const jobs = await repo.listSyncJobs('src-sample-local');
    expect(jobs[0].records_added).toBe(2);
    expect(jobs[0].status).toBe('success');
  });

  it('is idempotent: re-importing the same rows updates instead of duplicating', async () => {
    const repo = await signInAs('admin');
    const rows = [{ name: 'Repeat Lead', phone: '+971509111111', email: 'repeat@example.invalid' }];

    const first = await repo.importLeads('src-sample-local', rows, 'update');
    const second = await repo.importLeads('src-sample-local', rows, 'update');

    expect(first.added).toBe(1);
    expect(second).toMatchObject({ added: 0, updated: 1 });

    const matches = await repo.listAllLeads({ search: 'Repeat Lead' }, 10);
    expect(matches).toHaveLength(1);
  });

  it('skips duplicates when the policy says so', async () => {
    const repo = await signInAs('admin');
    const rows = [{ name: 'Skipped Lead', phone: '+971509222222' }];
    await repo.importLeads('src-sample-local', rows, 'update');
    const result = await repo.importLeads('src-sample-local', rows, 'skip');
    expect(result).toMatchObject({ added: 0, updated: 0, skipped: 1 });
  });

  it('reports invalid rows without failing the batch', async () => {
    const repo = await signInAs('admin');
    const result = await repo.importLeads(
      'src-sample-local',
      [
        { name: '', phone: '+971509333333' },
        { name: 'Good Row', phone: '+971509333334' },
      ],
      'update',
    );
    expect(result.added).toBe(1);
    expect(result.skipped).toBe(1);
    expect(result.errors?.[0].message).toMatch(/required/i);
  });

  it('rejects imports from callers', async () => {
    const repo = await signInAs('caller');
    await expect(repo.importLeads('src-sample-local', [{ name: 'X', phone: '+971500000000' }]))
      .rejects.toThrow(/administrator/i);
  });
});

describe('dashboard aggregates', () => {
  it('never double counts leads across KPI buckets', async () => {
    const repo = await signInAs('admin');
    const summary = await repo.getSummary();
    const bucketTotal = Object.values(summary.byStatus).reduce((a, b) => a + b, 0);
    expect(summary.totalLeads).toBeGreaterThan(0);
    expect(bucketTotal).toBe(summary.totalLeads);
  });

  it('scopes the caller summary to their own leads', async () => {
    const repo = await signInAs('caller');
    const summary = await repo.getSummary();
    const leads = await repo.listAllLeads({}, 500);
    expect(summary.totalLeads).toBe(leads.length);
  });

  it('builds a report with caller and source comparisons', async () => {
    const repo = await signInAs('admin');
    const report = await repo.getReport({});
    expect(report.callerStats.length).toBeGreaterThan(0);
    expect(report.sourceStats.length).toBeGreaterThan(0);
    expect(report.leadsPerDay).toHaveLength(14);
  });
});
