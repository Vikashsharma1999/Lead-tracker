import { describe, expect, it } from 'vitest';
import * as XLSX from 'xlsx';
import {
  INTERNAL_FIELDS,
  autoMapColumns,
  buildCsv,
  buildLeadWorkbook,
  leadsToExportRows,
  mapRows,
  parseStatus,
  parseSpreadsheetFile,
} from '@/lib/excel';
import type { Lead } from '@/types/domain';

function sampleLead(overrides: Partial<Lead> = {}): Lead {
  const now = '2026-10-20T08:30:00.000Z';
  return {
    id: 'lead-1',
    source_id: 'src-1',
    source_external_id: 'sheet-abc',
    source_sheet_name: 'Registrations',
    source_record_id: 'row-2',
    name: 'Test, "Quoted" Lead',
    phone: '+971501234567',
    email: 'test@example.invalid',
    lead_status: 'interested',
    lead_outcome: 'positive',
    assigned_to: 'caller-1',
    last_call_at: now,
    next_follow_up_at: null,
    notes: 'Line one\nLine two, with comma',
    created_at: now,
    updated_at: now,
    version: 3,
    ...overrides,
  };
}

const profiles = [
  {
    id: 'caller-1',
    full_name: 'Rahul Menon',
    email: 'rahul@example.invalid',
    role: 'caller' as const,
    active: true,
    created_at: '2026-01-01T00:00:00.000Z',
  },
];

const sources = [
  {
    id: 'src-1',
    name: 'October Meta Ads',
    source_type: 'google_sheets' as const,
    connection_status: 'connected' as const,
    sync_mode: 'manual' as const,
    sync_interval_seconds: 60,
    last_sync_at: null,
    last_success_at: null,
    last_error: null,
    configuration: {},
    created_at: '2026-01-01T00:00:00.000Z',
  },
];

describe('column mapping', () => {
  it('auto-maps common spreadsheet headers to internal fields', () => {
    const mapping = autoMapColumns([
      'Full Name',
      'Mobile Number',
      'Email Address',
      'Lead Status',
      'Assigned To',
      'Follow Up Date',
      'Remarks',
      'Sr No',
    ]);
    expect(mapping.name).toBe('Full Name');
    expect(mapping.phone).toBe('Mobile Number');
    expect(mapping.email).toBe('Email Address');
    expect(mapping.lead_status).toBe('Lead Status');
    expect(mapping.assigned_caller).toBe('Assigned To');
    expect(mapping.next_follow_up_at).toBe('Follow Up Date');
    expect(mapping.notes).toBe('Remarks');
    expect(mapping.source_record_id).toBe('Sr No');
  });

  it('handles snake_case and noisy headers', () => {
    const mapping = autoMapColumns(['lead_name', 'PHONE NUMBER', 'e-mail', 'Stage']);
    expect(mapping.name).toBe('lead_name');
    expect(mapping.phone).toBe('PHONE NUMBER');
    expect(mapping.email).toBe('e-mail');
    expect(mapping.lead_status).toBe('Stage');
  });

  it('does not assign the same column to two fields', () => {
    const mapping = autoMapColumns(['Name', 'Phone']);
    const used = Object.values(mapping);
    expect(new Set(used).size).toBe(used.length);
  });

  it('every required field has aliases defined', () => {
    for (const field of INTERNAL_FIELDS) {
      expect(field.aliases.length).toBeGreaterThan(0);
      expect(field.label.length).toBeGreaterThan(0);
    }
  });
});

describe('row mapping and validation', () => {
  const mapping = autoMapColumns(['Name', 'Mobile', 'Email', 'Status', 'Notes']);

  it('maps valid rows and flags invalid ones with reasons', () => {
    const rows = [
      { Name: 'Valid Lead', Mobile: '+971501234567', Email: 'valid@example.invalid', Status: 'Interested', Notes: 'ok' },
      { Name: '', Mobile: '+971501234568', Email: 'nobody@example.invalid', Status: '', Notes: '' },
      { Name: 'Bad Phone', Mobile: 'abc', Email: 'not-an-email', Status: '', Notes: '' },
    ];
    const mapped = mapRows(rows, mapping);

    expect(mapped[0].errors).toEqual([]);
    expect(mapped[0].lead_status).toBe('interested');
    expect(mapped[1].errors).toContain('Name is required');
    expect(mapped[2].errors).toEqual(
      expect.arrayContaining(['Mobile number looks invalid', 'Email looks invalid']),
    );
    expect(mapped[1].rowNumber).toBe(3); // header is row 1
  });

  it('preserves the source row identifier for write-back', () => {
    const mapped = mapRows([{ Name: 'A', Mobile: '+971501234567' }], mapping);
    expect(mapped[0].source_record_id).toBe('row-2');
  });

  it('parses status aliases and falls back to not_dialed', () => {
    expect(parseStatus('Call Back')).toBe('call_back');
    expect(parseStatus('follow up pending')).toBe('follow_up_pending');
    expect(parseStatus('Webinar Link Shared')).toBe('webinar_link_shared');
    expect(parseStatus('something else')).toBe('not_dialed');
    expect(parseStatus(undefined)).toBe('not_dialed');
  });
});

describe('file parsing (xlsx, xls and csv)', () => {
  function makeFile(bookType: 'xlsx' | 'csv', rows: unknown[][], name: string): File {
    const sheet = XLSX.utils.aoa_to_sheet(rows);
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, 'Leads');
    const data = XLSX.write(book, { bookType, type: 'array' }) as ArrayBuffer;
    return new File([data], name, {
      type: bookType === 'csv' ? 'text/csv' : 'application/vnd.ms-excel',
    });
  }

  it('parses an .xlsx workbook into headers and rows', async () => {
    const file = makeFile(
      'xlsx',
      [
        ['Name', 'Mobile', 'Status'],
        ['Alpha', '+971501111111', 'Interested'],
        ['Bravo', '+971502222222', 'No Answer'],
      ],
      'leads.xlsx',
    );
    const parsed = await parseSpreadsheetFile(file);
    expect(parsed.fileName).toBe('leads.xlsx');
    expect(parsed.sheets).toHaveLength(1);
    expect(parsed.sheets[0].headers).toEqual(['Name', 'Mobile', 'Status']);
    expect(parsed.sheets[0].rows).toHaveLength(2);
    expect(parsed.sheets[0].rows[1].Name).toBe('Bravo');
  });

  it('parses .xls (legacy BIFF) files', async () => {
    const file = makeFile(
      'xlsx',
      [
        ['Name', 'Mobile'],
        ['Legacy', '+971503333333'],
      ],
      'legacy.xls',
    );
    // SheetJS auto-detects the format from content, not the extension.
    const parsed = await parseSpreadsheetFile(file);
    expect(parsed.sheets[0].rows[0].Name).toBe('Legacy');
  });

  it('parses CSV content', async () => {
    const file = new File(['Name,Mobile\nCsv Lead,+971504444444\n'], 'leads.csv', { type: 'text/csv' });
    const parsed = await parseSpreadsheetFile(file);
    expect(parsed.sheets[0].rows[0].Name).toBe('Csv Lead');
  });
});

describe('export', () => {
  it('builds a workbook with all required columns', () => {
    const workbook = buildLeadWorkbook([sampleLead()], { profiles, sources });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet);
    expect(rows).toHaveLength(1);

    const exported = rows[0];
    expect(exported['Lead ID']).toBe('lead-1');
    expect(exported['Name']).toBe('Test, "Quoted" Lead');
    expect(exported['Mobile Number']).toBe('+971501234567');
    expect(exported['Call Status']).toBe('Interested');
    expect(exported['Assigned Caller']).toBe('Rahul Menon');
    expect(exported['Source Spreadsheet']).toBe('October Meta Ads');
    expect(exported['Worksheet']).toBe('Registrations');
    expect(exported['Source Row']).toBe('row-2');
  });

  it('escapes CSV quotes, commas and newlines', () => {
    const csv = buildCsv([sampleLead()], { profiles, sources });
    expect(csv.startsWith('\uFEFF')).toBe(true);
    expect(csv).toContain('"Test, ""Quoted"" Lead"');
    expect(csv).toContain('"Line one\nLine two, with comma"');
    expect(csv.split('\r\n')).toHaveLength(2);
  });

  it('renders unassigned leads explicitly', () => {
    const [row] = leadsToExportRows([sampleLead({ assigned_to: null })], { profiles, sources });
    expect(row['Assigned Caller']).toBe('Unassigned');
  });

  it('produces an empty body for an empty result set', () => {
    expect(buildCsv([], {})).toBe('');
  });
});
