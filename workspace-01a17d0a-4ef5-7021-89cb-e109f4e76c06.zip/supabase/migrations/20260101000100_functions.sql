-- =============================================================================
-- Lead Tracker Dashboard — 0002 helper functions, RPCs and aggregates
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Identity helpers (SECURITY DEFINER so RLS policies can call them cheaply)
-- -----------------------------------------------------------------------------
create or replace function public.current_role_name()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role::text from public.profiles where id = auth.uid();
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select role = 'admin' and active from public.profiles where id = auth.uid()),
    false
  );
$$;

create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select active from public.profiles where id = auth.uid()), false);
$$;

create or replace function public.owns_lead(p_lead_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.leads l
    where l.id = p_lead_id and l.assigned_to = auth.uid()
  );
$$;

grant execute on function public.current_role_name() to authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_active_user() to authenticated;
grant execute on function public.owns_lead(uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- Profile bootstrap: creating an auth user creates its profile row.
-- The FIRST user in a fresh database becomes admin; everyone else is a caller.
-- -----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  assigned_role public.user_role := 'caller';
  is_first boolean;
begin
  select not exists (select 1 from public.profiles) into is_first;

  if is_first then
    assigned_role := 'admin';
  elsif coalesce(new.raw_user_meta_data ->> 'role', 'caller') = 'admin' then
    -- Role from metadata is honoured only when an admin created the invite
    -- (see admin-users function, which stamps `created_by_admin` = true).
    if coalesce((new.raw_user_meta_data ->> 'created_by_admin')::boolean, false) then
      assigned_role := 'admin';
    end if;
  end if;

  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1)),
    new.email,
    assigned_role
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Keep profile email in sync when auth email changes.
create or replace function public.handle_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.profiles set email = new.email where id = new.id;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_changed on auth.users;
create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row execute function public.handle_user_email_change();

-- -----------------------------------------------------------------------------
-- Guard: only admins may grant admin. Nobody may escalate their own role.
-- Column-level protection for callers on the leads table.
-- -----------------------------------------------------------------------------
create or replace function public.guard_profile_write()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  actor_role public.user_role;
begin
  select role into actor_role from public.profiles where id = auth.uid();

  -- Service role (no auth.uid()) and SQL run by the dashboard bypass this.
  if auth.uid() is null then
    return new;
  end if;

  if tg_op = 'UPDATE' and new.role is distinct from old.role then
    if actor_role is distinct from 'admin' then
      raise exception 'Only administrators can change a role' using errcode = '42501';
    end if;
    if old.id = auth.uid() and new.role <> 'admin' then
      raise exception 'You cannot remove your own administrator role' using errcode = '42501';
    end if;
  end if;

  if tg_op = 'UPDATE' and old.role = 'admin' and new.role = 'caller'
     and old.id = auth.uid() then
    raise exception 'You cannot demote yourself' using errcode = '42501';
  end if;

  return new;
end;
$$;

create trigger profiles_guard_write before update on public.profiles
  for each row execute function public.guard_profile_write();

/**
 * Callers may only modify call-related columns of leads assigned to them.
 * Admins may modify anything. Any other write is rejected with 42501.
 */
create or replace function public.guard_lead_write()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  actor_role public.user_role;
  protected text[] := array['name', 'phone', 'email', 'source_id', 'source_external_id',
                            'source_sheet_name', 'source_record_id', 'assigned_to',
                            'phone_normalized', 'version'];
  field text;
begin
  select role into actor_role from public.profiles where id = auth.uid();

  if auth.uid() is null then
    return new;  -- service role / migrations / pg_cron
  end if;

  if actor_role = 'admin' then
    return new;
  end if;

  if actor_role is distinct from 'caller' then
    raise exception 'Inactive or unknown user cannot modify leads' using errcode = '42501';
  end if;

  foreach field in array protected loop
    if (to_jsonb(new) -> field) is distinct from (to_jsonb(old) -> field) then
      raise exception 'Callers cannot modify %', field using errcode = '42501';
    end if;
  end loop;

  return new;
end;
$$;

create trigger leads_guard_write before update on public.leads
  for each row execute function public.guard_lead_write();

-- -----------------------------------------------------------------------------
-- log_call: single transactional call-activity write + lead roll-forward
-- -----------------------------------------------------------------------------
create or replace function public.log_call(
  p_lead_id uuid,
  p_outcome public.lead_outcome,
  p_notes text default null,
  p_call_time timestamptz default now(),
  p_lead_status public.lead_status default null,
  p_next_follow_up_at timestamptz default null,
  p_client_reference text default null
)
returns public.call_activities
language plpgsql
security definer
set search_path = public
as $$
declare
  v_lead public.leads;
  v_activity public.call_activities;
begin
  select * into v_lead from public.leads where id = p_lead_id for update;
  if not found then
    raise exception 'Lead not found' using errcode = 'P0002';
  end if;

  if not public.is_admin() and v_lead.assigned_to is distinct from auth.uid() then
    raise exception 'You can only log calls for leads assigned to you' using errcode = '42501';
  end if;

  insert into public.call_activities (lead_id, caller_id, call_time, outcome, notes, client_reference)
  values (p_lead_id, auth.uid(), coalesce(p_call_time, now()), p_outcome, p_notes, p_client_reference)
  on conflict (caller_id, client_reference) do nothing
  returning * into v_activity;

  -- Idempotent replay: return the existing activity instead of duplicating.
  if v_activity.id is null and p_client_reference is not null then
    select * into v_activity from public.call_activities
    where caller_id = auth.uid() and client_reference = p_client_reference;
  end if;

  update public.leads
     set last_call_at = coalesce(p_call_time, now()),
         lead_outcome = p_outcome,
         lead_status = coalesce(p_lead_status, lead_status),
         next_follow_up_at = coalesce(p_next_follow_up_at, next_follow_up_at)
   where id = p_lead_id;

  return v_activity;
end;
$$;

grant execute on function public.log_call(uuid, public.lead_outcome, text, timestamptz, public.lead_status, timestamptz, text)
  to authenticated;

-- -----------------------------------------------------------------------------
-- dashboard_summary: KPI aggregates computed from records (no double counting)
-- -----------------------------------------------------------------------------
create or replace function public.dashboard_summary(p_from date default null, p_to date default null)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  result jsonb;
begin
  -- RLS still applies because the function is SECURITY DEFINER but we filter by
  -- the caller explicitly.
  with visible as (
    select l.*
    from public.leads l
    where (public.is_admin() or l.assigned_to = auth.uid())
      and (p_from is null or l.created_at >= p_from::timestamptz)
      and (p_to is null or l.created_at < (p_to + 1)::timestamptz)
  ),
  status_counts as (
    select s.value as status, count(*)::int as count
    from public.lead_statuses s
    left join visible v on v.lead_status = s.value
    group by s.value
  )
  select jsonb_build_object(
    'total_leads', (select count(*)::int from visible),
    'by_status', (select coalesce(jsonb_object_agg(status, count), '{}'::jsonb) from status_counts),
    'calls_today', (
      select count(*)::int from public.call_activities ca
      join visible v on v.id = ca.lead_id
      where ca.call_time >= date_trunc('day', now())
    ),
    'callbacks_due_today', (
      select count(*)::int from visible
      where lead_status = 'call_back'
        and next_follow_up_at >= date_trunc('day', now())
        and next_follow_up_at < date_trunc('day', now()) + interval '1 day'
    ),
    'overdue_follow_ups', (
      select count(*)::int from visible
      where lead_status in ('follow_up_pending', 'call_back')
        and next_follow_up_at is not null
        and next_follow_up_at < date_trunc('day', now())
    ),
    'unassigned', (select count(*)::int from visible where assigned_to is null)
  ) into result;

  return result;
end;
$$;

grant execute on function public.dashboard_summary(date, date) to authenticated;

-- -----------------------------------------------------------------------------
-- report_summary: caller/source comparisons, timing series, work queues
-- -----------------------------------------------------------------------------
create or replace function public.report_summary(
  p_from date default null,
  p_to date default null,
  p_caller uuid default null,
  p_source uuid default null
)
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  with visible as (
    select l.*
    from public.leads l
    where (public.is_admin() or l.assigned_to = auth.uid())
      and (p_from is null or l.created_at >= p_from::timestamptz)
      and (p_to is null or l.created_at < (p_to + 1)::timestamptz)
      and (p_caller is null or l.assigned_to = p_caller)
      and (p_source is null or l.source_id = p_source)
  ),
  callers as (
    select p.id, p.full_name,
           count(distinct v.id)::int as assigned_leads,
           count(distinct v.id) filter (where v.lead_status = 'interested')::int as interested,
           count(distinct v.id) filter (where v.lead_status = 'call_back')::int as callbacks,
           (select count(*)::int from public.call_activities ca
             where ca.caller_id = p.id
               and (p_from is null or ca.call_time >= p_from::timestamptz)
               and (p_to is null or ca.call_time < (p_to + 1)::timestamptz)) as total_calls
    from public.profiles p
    left join visible v on v.assigned_to = p.id
    where p.role = 'caller'
      and (p_caller is null or p.id = p_caller)
    group by p.id, p.full_name
  ),
  sources as (
    select s.id, s.name, s.last_success_at,
           count(v.id)::int as total,
           count(v.id) filter (where v.lead_status = 'interested')::int as interested,
           count(v.id) filter (where v.lead_status = 'not_dialed')::int as not_dialed
    from public.data_sources s
    left join visible v on v.source_id = s.id
    where p_source is null or s.id = p_source
    group by s.id, s.name, s.last_success_at
  ),
  days as (
    select generate_series(date_trunc('day', now()) - interval '13 days', date_trunc('day', now()), interval '1 day') as day
  )
  select jsonb_build_object(
    'caller_stats', (
      select coalesce(jsonb_agg(jsonb_build_object(
        'caller_id', id, 'caller_name', full_name, 'assigned_leads', assigned_leads,
        'interested', interested, 'callbacks', callbacks, 'total_calls', total_calls
      ) order by full_name), '[]'::jsonb) from callers
    ),
    'source_stats', (
      select coalesce(jsonb_agg(jsonb_build_object(
        'source_id', id, 'source_name', name, 'total', total, 'interested', interested,
        'not_dialed', not_dialed, 'last_sync_at', last_success_at
      ) order by name), '[]'::jsonb) from sources
    ),
    'leads_per_day', (
      select coalesce(jsonb_agg(jsonb_build_object(
        'date', to_char(d.day, 'MM/DD'), 'count', (
          select count(*)::int from visible v
          where v.created_at >= d.day and v.created_at < d.day + interval '1 day'
        )
      ) order by d.day), '[]'::jsonb) from days d
    ),
    'callbacks', (
      select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (
        select v.* from visible v
        where v.lead_status = 'call_back'
          and v.next_follow_up_at >= date_trunc('day', now())
          and v.next_follow_up_at < date_trunc('day', now()) + interval '1 day'
        order by v.next_follow_up_at limit 25
      ) t
    ),
    'overdue', (
      select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (
        select v.* from visible v
        where v.lead_status in ('follow_up_pending', 'call_back')
          and v.next_follow_up_at < date_trunc('day', now())
        order by v.next_follow_up_at limit 25
      ) t
    )
  );
$$;

grant execute on function public.report_summary(date, date, uuid, uuid) to authenticated;

-- -----------------------------------------------------------------------------
-- import_leads: server-side import with duplicate policy + job accounting
-- Used by the Excel upload flow (Phase 3) and callable by server functions.
-- -----------------------------------------------------------------------------
create or replace function public.import_leads(
  p_source_id uuid,
  p_rows jsonb,
  p_policy text default 'update',
  p_job_type public.sync_job_type default 'manual_refresh'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_job uuid;
  v_row jsonb;
  v_added int := 0;
  v_updated int := 0;
  v_skipped int := 0;
  v_existing_id uuid;
  v_source public.data_sources;
  v_policy text;
begin
  if not public.is_admin() then
    raise exception 'Only administrators can import leads' using errcode = '42501';
  end if;

  select * into v_source from public.data_sources where id = p_source_id;
  if not found then
    raise exception 'Data source not found' using errcode = 'P0002';
  end if;

  v_policy := coalesce(p_policy, v_source.duplicate_policy, 'update');

  insert into public.sync_jobs (source_id, job_type, status, requested_by, started_at)
  values (p_source_id, p_job_type, 'running', auth.uid(), now())
  returning id into v_job;

  for v_row in select * from jsonb_array_elements(p_rows) loop
    if coalesce(v_row ->> 'name', '') = '' or coalesce(v_row ->> 'phone', '') = '' then
      v_skipped := v_skipped + 1;
      continue;
    end if;

    -- 1) Same source row → update in place (idempotent re-import).
    select id into v_existing_id
    from public.leads
    where source_id = p_source_id
      and coalesce(source_sheet_name, '') = coalesce(v_row ->> 'source_sheet_name', '')
      and source_record_id = (v_row ->> 'source_record_id')
    limit 1;

    -- 2) Otherwise match on normalised phone or email.
    if v_existing_id is null and v_policy <> 'create' then
      select id into v_existing_id
      from public.leads
      where (
        public.normalize_phone(v_row ->> 'phone') = phone_normalized
        or (nullif(v_row ->> 'email', '') is not null and email = (v_row ->> 'email')::citext)
      )
      limit 1;
    end if;

    if v_existing_id is not null then
      if v_policy = 'skip' then
        v_skipped := v_skipped + 1;
        continue;
      end if;

      update public.leads
         set name = coalesce(nullif(v_row ->> 'name', ''), name),
             phone = coalesce(nullif(v_row ->> 'phone', ''), phone),
             email = coalesce(nullif(v_row ->> 'email', '')::citext, email),
             lead_status = coalesce((v_row ->> 'lead_status')::public.lead_status, lead_status),
             lead_outcome = coalesce((v_row ->> 'lead_outcome')::public.lead_outcome, lead_outcome),
             next_follow_up_at = coalesce((v_row ->> 'next_follow_up_at')::timestamptz, next_follow_up_at),
             notes = coalesce(nullif(v_row ->> 'notes', ''), notes),
             source_id = p_source_id,
             source_external_id = coalesce(v_row ->> 'source_external_id', source_external_id),
             source_sheet_name = coalesce(v_row ->> 'source_sheet_name', source_sheet_name),
             source_record_id = coalesce(v_row ->> 'source_record_id', source_record_id),
             source_updated_at = now()
       where id = v_existing_id;
      v_updated := v_updated + 1;
    else
      insert into public.leads (
        source_id, source_external_id, source_sheet_name, source_record_id,
        name, phone, email, lead_status, lead_outcome, next_follow_up_at, notes
      ) values (
        p_source_id,
        v_row ->> 'source_external_id',
        v_row ->> 'source_sheet_name',
        v_row ->> 'source_record_id',
        v_row ->> 'name',
        v_row ->> 'phone',
        nullif(v_row ->> 'email', '')::citext,
        coalesce((v_row ->> 'lead_status')::public.lead_status, 'not_dialed'),
        coalesce((v_row ->> 'lead_outcome')::public.lead_outcome, 'pending'),
        (v_row ->> 'next_follow_up_at')::timestamptz,
        nullif(v_row ->> 'notes', '')
      );
      v_added := v_added + 1;
    end if;
  end loop;

  update public.sync_jobs
     set status = 'success',
         records_added = v_added,
         records_updated = v_updated,
         records_skipped = v_skipped,
         attempts = attempts + 1,
         finished_at = now()
   where id = v_job;

  update public.data_sources
     set last_sync_at = now(),
         last_success_at = now(),
         last_error = null,
         -- Uploaded files cannot claim a live connection.
         connection_status = case
           when source_type in ('google_sheets', 'excel_onedrive') then connection_status
           else 'connected'
         end
   where id = p_source_id;

  insert into public.audit_logs (user_id, user_name, action, entity_type, entity_id, metadata)
  values (
    auth.uid(),
    (select full_name from public.profiles where id = auth.uid()),
    'leads.imported',
    'data_source',
    p_source_id::text,
    jsonb_build_object('added', v_added, 'updated', v_updated, 'skipped', v_skipped, 'policy', v_policy)
  );

  return jsonb_build_object(
    'job_id', v_job, 'added', v_added, 'updated', v_updated, 'skipped', v_skipped, 'policy', v_policy
  );
end;
$$;

grant execute on function public.import_leads(uuid, jsonb, text, public.sync_job_type) to authenticated;

-- -----------------------------------------------------------------------------
-- resolve_conflict: admin-only conflict resolution
-- -----------------------------------------------------------------------------
create or replace function public.resolve_conflict(
  p_conflict_id uuid,
  p_resolution text
)
returns public.lead_conflicts
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conflict public.lead_conflicts;
begin
  if not public.is_admin() then
    raise exception 'Only administrators can resolve conflicts' using errcode = '42501';
  end if;
  if p_resolution not in ('resolved_local', 'resolved_server', 'dismissed') then
    raise exception 'Invalid resolution' using errcode = '22023';
  end if;

  select * into v_conflict from public.lead_conflicts where id = p_conflict_id for update;
  if not found then
    raise exception 'Conflict not found' using errcode = 'P0002';
  end if;

  if p_resolution = 'resolved_local' then
    execute format(
      'update public.leads set %I = $1 where id = $2',
      v_conflict.field
    ) using v_conflict.local_value, v_conflict.lead_id;
  end if;

  update public.lead_conflicts
     set status = p_resolution, resolved_by = auth.uid(), resolved_at = now()
   where id = p_conflict_id
   returning * into v_conflict;

  insert into public.audit_logs (user_id, user_name, action, entity_type, entity_id, metadata)
  values (auth.uid(), (select full_name from public.profiles where id = auth.uid()),
          'conflict.' || p_resolution, 'lead', v_conflict.lead_id::text,
          jsonb_build_object('field', v_conflict.field));

  return v_conflict;
end;
$$;

grant execute on function public.resolve_conflict(uuid, text) to authenticated;

-- -----------------------------------------------------------------------------
-- Retry scheduling helper: exponential backoff metadata
-- -----------------------------------------------------------------------------
create or replace function public.schedule_job_retry(p_job_id uuid, p_error text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_attempts int;
begin
  select attempts + 1 into v_attempts from public.sync_jobs where id = p_job_id;

  update public.sync_jobs
     set attempts = v_attempts,
         error_message = left(p_error, 2000),
         status = case when v_attempts >= 5 then 'failed' else 'queued' end,
         next_attempt_at = now() + (least(power(2, v_attempts)::int, 300) || ' seconds')::interval,
         finished_at = case when v_attempts >= 5 then now() else null end
   where id = p_job_id;
end;
$$;

revoke all on function public.schedule_job_retry(uuid, text) from public;
