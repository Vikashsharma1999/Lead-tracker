-- =============================================================================
-- Lead Tracker Dashboard — 0003 Row Level Security
--
-- Principle: deny by default. A row is visible only when the signed-in user is
-- an active profile AND (is an admin OR the row belongs to them). Writes use the
-- narrowest policy that still supports the workflow; column-level rules live in
-- trigger functions (`guard_lead_write`, `guard_profile_write`).
-- =============================================================================

alter table public.profiles enable row level security;
alter table public.lead_statuses enable row level security;
alter table public.data_sources enable row level security;
alter table public.integration_credentials enable row level security;
alter table public.leads enable row level security;
alter table public.call_activities enable row level security;
alter table public.lead_assignments enable row level security;
alter table public.sync_jobs enable row level security;
alter table public.lead_conflicts enable row level security;
alter table public.audit_logs enable row level security;

-- Revoke broad grants; RLS plus explicit grants is belt-and-braces.
revoke all on public.profiles from anon;
revoke all on public.integration_credentials from anon, authenticated;

-- -----------------------------------------------------------------------------
-- profiles
-- -----------------------------------------------------------------------------
create policy "profiles: read own"
  on public.profiles for select to authenticated
  using (id = auth.uid());

-- Admins can list every profile (needed to assign leads).
create policy "profiles: admins read all"
  on public.profiles for select to authenticated
  using (public.is_admin());

-- Callers may see the names of active callers so the UI can render assignees.
create policy "profiles: directory for active users"
  on public.profiles for select to authenticated
  using (public.is_active_user() and active and role = 'caller');

create policy "profiles: update own basic fields"
  on public.profiles for update to authenticated
  using (id = auth.uid())
  with check (
    id = auth.uid()
    -- role/active changes are rejected by guard_profile_write for non-admins
  );

create policy "profiles: admins update any"
  on public.profiles for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create policy "profiles: admins insert"
  on public.profiles for insert to authenticated
  with check (public.is_admin());

-- No DELETE policy: users are deactivated, never deleted, so audit history and
-- lead assignments stay intact.

-- -----------------------------------------------------------------------------
-- lead_statuses — readable by all authenticated, writable by admins
-- -----------------------------------------------------------------------------
create policy "lead_statuses: read"
  on public.lead_statuses for select to authenticated
  using (public.is_active_user());

create policy "lead_statuses: admins write"
  on public.lead_statuses for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- -----------------------------------------------------------------------------
-- data_sources — admins manage; callers may read the names for filters
-- -----------------------------------------------------------------------------
create policy "data_sources: read for active users"
  on public.data_sources for select to authenticated
  using (public.is_active_user());

create policy "data_sources: admins write"
  on public.data_sources for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- integration_credentials: RLS enabled, zero policies → service role only.

-- -----------------------------------------------------------------------------
-- leads
-- -----------------------------------------------------------------------------
create policy "leads: admins read all"
  on public.leads for select to authenticated
  using (public.is_admin());

create policy "leads: callers read assigned"
  on public.leads for select to authenticated
  using (
    public.is_active_user()
    and assigned_to = auth.uid()
  );

create policy "leads: admins insert"
  on public.leads for insert to authenticated
  with check (public.is_admin());

create policy "leads: admins update"
  on public.leads for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create policy "leads: callers update assigned"
  on public.leads for update to authenticated
  using (public.is_active_user() and assigned_to = auth.uid())
  -- A caller cannot reassign a lead away from themselves: the WITH CHECK keeps
  -- ownership stable, and guard_lead_write blocks contact-field edits.
  with check (assigned_to = auth.uid());

create policy "leads: admins delete"
  on public.leads for delete to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------------
-- call_activities
-- -----------------------------------------------------------------------------
create policy "call_activities: admins read all"
  on public.call_activities for select to authenticated
  using (public.is_admin());

create policy "call_activities: callers read own or assigned leads"
  on public.call_activities for select to authenticated
  using (
    public.is_active_user()
    and (caller_id = auth.uid() or public.owns_lead(lead_id))
  );

create policy "call_activities: insert for assigned leads"
  on public.call_activities for insert to authenticated
  with check (
    caller_id = auth.uid()
    and (public.is_admin() or public.owns_lead(lead_id))
  );

-- Call activities are append-only for callers: no update/delete policies.
create policy "call_activities: admins manage"
  on public.call_activities for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

create policy "call_activities: admins delete"
  on public.call_activities for delete to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------------
-- lead_assignments
-- -----------------------------------------------------------------------------
create policy "lead_assignments: admins read all"
  on public.lead_assignments for select to authenticated
  using (public.is_admin());

create policy "lead_assignments: callers read own"
  on public.lead_assignments for select to authenticated
  using (public.is_active_user() and caller_id = auth.uid());

create policy "lead_assignments: admins insert"
  on public.lead_assignments for insert to authenticated
  with check (public.is_admin());

-- -----------------------------------------------------------------------------
-- sync_jobs — admins only (callers do not need sync internals)
-- -----------------------------------------------------------------------------
create policy "sync_jobs: admins read"
  on public.sync_jobs for select to authenticated
  using (public.is_admin());

create policy "sync_jobs: admins insert"
  on public.sync_jobs for insert to authenticated
  with check (public.is_admin());

create policy "sync_jobs: admins update"
  on public.sync_jobs for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- -----------------------------------------------------------------------------
-- lead_conflicts — admins resolve; affected callers may see their own
-- -----------------------------------------------------------------------------
create policy "lead_conflicts: admins read"
  on public.lead_conflicts for select to authenticated
  using (public.is_admin());

create policy "lead_conflicts: callers read own leads"
  on public.lead_conflicts for select to authenticated
  using (public.is_active_user() and public.owns_lead(lead_id));

create policy "lead_conflicts: authenticated insert"
  on public.lead_conflicts for insert to authenticated
  with check (
    public.is_active_user()
    and (public.is_admin() or public.owns_lead(lead_id))
  );

create policy "lead_conflicts: admins update"
  on public.lead_conflicts for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- -----------------------------------------------------------------------------
-- audit_logs — admins read; writes happen through SECURITY DEFINER triggers
-- -----------------------------------------------------------------------------
create policy "audit_logs: admins read"
  on public.audit_logs for select to authenticated
  using (public.is_admin());

-- No insert/update/delete policy for authenticated users: triggers and the
-- service role write audit entries, so history cannot be forged from a client.

-- -----------------------------------------------------------------------------
-- Realtime: only expose tables the dashboard subscribes to.
-- RLS is applied to realtime payloads, so callers only receive their rows.
-- -----------------------------------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array['leads', 'call_activities', 'data_sources', 'sync_jobs'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception
      when duplicate_object then null;  -- already published
    end;
  end loop;
end;
$$;

-- Realtime needs full row data for UPDATE events.
alter table public.leads replica identity full;
alter table public.data_sources replica identity full;
alter table public.sync_jobs replica identity full;

-- -----------------------------------------------------------------------------
-- Storage: private bucket for uploaded Excel files (admin write, admin read)
-- -----------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'lead-imports', 'lead-imports', false, 26214400,
  array[
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel',
    'text/csv'
  ]
)
on conflict (id) do nothing;

create policy "lead-imports: admins read"
  on storage.objects for select to authenticated
  using (bucket_id = 'lead-imports' and public.is_admin());

create policy "lead-imports: admins write"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'lead-imports' and public.is_admin());

create policy "lead-imports: admins delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'lead-imports' and public.is_admin());
