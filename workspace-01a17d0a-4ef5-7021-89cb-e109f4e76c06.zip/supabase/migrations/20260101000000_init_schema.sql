-- =============================================================================
-- Lead Tracker Dashboard — 0001 initial schema
-- Target: Supabase Postgres 15+
-- Conventions:
--   * snake_case, plural table names
--   * every table has created_at (and updated_at where mutable)
--   * internal lead ids are UUIDs; source row identity is preserved separately
-- =============================================================================

create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- -----------------------------------------------------------------------------
-- Enums
-- -----------------------------------------------------------------------------
create type public.user_role as enum ('admin', 'caller');

create type public.lead_status as enum (
  'not_dialed',
  'dialed',
  'interested',
  'not_interested',
  'call_back',
  'webinar_link_shared',
  'follow_up_pending',
  'bad_timing',
  'switched_off',
  'no_answer'
);

create type public.lead_outcome as enum ('pending', 'positive', 'neutral', 'negative', 'invalid');

create type public.source_type as enum ('google_sheets', 'excel_onedrive', 'excel_upload', 'manual');

create type public.connection_status as enum ('not_configured', 'connected', 'error', 'disconnected');

create type public.sync_mode as enum ('manual', 'interval', 'webhook');

create type public.sync_job_type as enum ('initial_import', 'incremental', 'write_back', 'manual_refresh');

create type public.sync_job_status as enum ('queued', 'running', 'success', 'partial', 'failed', 'cancelled');

-- -----------------------------------------------------------------------------
-- profiles — 1:1 with auth.users
-- -----------------------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null check (length(trim(full_name)) between 1 and 120),
  email citext not null unique,
  role public.user_role not null default 'caller',
  active boolean not null default true,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public.profiles is
  'Application user. Role is admin|caller. Only admins may change another user''s role (enforced by trigger + RLS).';

-- -----------------------------------------------------------------------------
-- lead_statuses — configurable status vocabulary (label/colour/order)
-- -----------------------------------------------------------------------------
create table public.lead_statuses (
  value public.lead_status primary key,
  label text not null,
  color text not null default '#94a3b8' check (color ~* '^#[0-9a-f]{6}$'),
  sort_order integer not null default 0,
  counts_as_dialed boolean not null default true,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- data_sources — a spreadsheet / workbook / upload origin
-- -----------------------------------------------------------------------------
create table public.data_sources (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 120),
  source_type public.source_type not null,
  connection_status public.connection_status not null default 'not_configured',
  sync_mode public.sync_mode not null default 'manual',
  sync_interval_seconds integer not null default 60 check (sync_interval_seconds between 15 and 86400),
  last_sync_at timestamptz,
  last_success_at timestamptz,
  last_error text,
  -- Non-secret configuration only. OAuth refresh tokens live in
  -- integration_credentials (service-role only).
  configuration jsonb not null default '{}'::jsonb,
  -- Column mapping: { "name": "Full Name", "phone": "Mobile", ... }
  column_mapping jsonb not null default '{}'::jsonb,
  duplicate_policy text not null default 'update'
    check (duplicate_policy in ('skip', 'update', 'create')),
  write_back_enabled boolean not null default false,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- One row per external spreadsheet/workbook (expression index, not a table
-- constraint: Postgres only allows expressions in indexes).
create unique index data_sources_external_id_unique
  on public.data_sources (source_type, (configuration ->> 'external_id'))
  where configuration ->> 'external_id' is not null;

comment on column public.data_sources.configuration is
  'Public metadata: spreadsheet_id, workbook_id, worksheet, drive, owner email. Never secrets.';

-- -----------------------------------------------------------------------------
-- integration_credentials — OAuth tokens, service-role read only
-- -----------------------------------------------------------------------------
create table public.integration_credentials (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references public.data_sources (id) on delete cascade,
  provider text not null check (provider in ('google', 'microsoft')),
  external_account_email citext,
  access_token text,
  refresh_token text,
  token_expires_at timestamptz,
  scopes text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint integration_credentials_provider_account_unique unique (provider, external_account_email)
);

comment on table public.integration_credentials is
  'Encrypted at rest by Supabase. RLS enabled with no policies: only the service role can read/write. Never exposed to the browser.';

-- -----------------------------------------------------------------------------
-- normalize_phone — canonical comparison key for duplicate detection.
-- Immutable so it can back a generated column. Must stay in sync with
-- `normalizePhone()` in src/lib/duplicates.ts.
-- -----------------------------------------------------------------------------
create or replace function public.normalize_phone(input text)
returns text
language sql
immutable
as $$
  with raw as (
    select regexp_replace(coalesce(input, ''), '[^0-9]', '', 'g') as d
  ),
  stripped_prefix as (
    select case when d like '00%' then substr(d, 3) else d end as d from raw
  )
  select regexp_replace(
           regexp_replace(
             d,
             '^(971|966|974|973|968|965|962|961|963|964|880|234|254|255|256|233|44|20|27|61|65|60|62|63|66|91|92|94|1)([0-9]{7,10})$',
             '\2'
           ),
           '^0+',
           ''
         )
  from stripped_prefix;
$$;

comment on function public.normalize_phone(text) is
  'Canonical phone key: digits only, no 00 prefix, no known country code, no trunk zeros.';

-- -----------------------------------------------------------------------------
-- leads — the single central record
-- -----------------------------------------------------------------------------
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references public.data_sources (id) on delete set null,
  -- Spreadsheet/file identity, preserved for write-back.
  source_external_id text,
  source_sheet_name text,
  source_record_id text,
  name text not null check (length(trim(name)) between 1 and 200),
  phone text not null check (phone ~ '^[+]?[0-9][0-9 ()-]{5,24}$'),
  phone_normalized text generated always as (public.normalize_phone(phone)) stored,
  email citext check (email is null or email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  lead_status public.lead_status not null default 'not_dialed',
  lead_outcome public.lead_outcome not null default 'pending',
  assigned_to uuid references public.profiles (id) on delete set null,
  last_call_at timestamptz,
  next_follow_up_at timestamptz,
  notes text check (notes is null or length(notes) <= 4000),
  -- Optimistic concurrency: incremented by trigger on every write.
  version integer not null default 1,
  -- Incremental sync bookkeeping.
  source_updated_at timestamptz,
  source_hash text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- A source row may only appear once per source/worksheet.
create unique index leads_source_record_unique
  on public.leads (source_id, source_sheet_name, source_record_id)
  where source_id is not null and source_record_id is not null;

create index leads_phone_normalized_idx on public.leads (phone_normalized);
create index leads_email_idx on public.leads (email) where email is not null;
create index leads_assigned_to_idx on public.leads (assigned_to);
create index leads_status_idx on public.leads (lead_status);
create index leads_created_at_idx on public.leads (created_at desc);
create index leads_follow_up_idx on public.leads (next_follow_up_at)
  where next_follow_up_at is not null;
create index leads_source_idx on public.leads (source_id);
-- Trigram search on name for the dashboard search box.
create extension if not exists "pg_trgm";
create index leads_name_trgm_idx on public.leads using gin (name gin_trgm_ops);

-- -----------------------------------------------------------------------------
-- call_activities — many calls per lead; never used for lead counts
-- -----------------------------------------------------------------------------
create table public.call_activities (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads (id) on delete cascade,
  caller_id uuid not null references public.profiles (id) on delete restrict,
  call_time timestamptz not null default now(),
  outcome public.lead_outcome not null default 'pending',
  notes text check (notes is null or length(notes) <= 4000),
  duration_seconds integer check (duration_seconds is null or duration_seconds >= 0),
  -- Idempotency for offline replay: client-generated key, unique per caller.
  client_reference text,
  created_at timestamptz not null default now(),
  constraint call_activities_client_reference_unique unique (caller_id, client_reference)
);

create index call_activities_lead_idx on public.call_activities (lead_id, call_time desc);
create index call_activities_caller_idx on public.call_activities (caller_id, call_time desc);

-- -----------------------------------------------------------------------------
-- lead_assignments — immutable assignment history
-- -----------------------------------------------------------------------------
create table public.lead_assignments (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads (id) on delete cascade,
  caller_id uuid references public.profiles (id) on delete set null,
  assigned_by uuid references public.profiles (id) on delete set null,
  assigned_at timestamptz not null default now()
);

create index lead_assignments_lead_idx on public.lead_assignments (lead_id, assigned_at desc);
create index lead_assignments_caller_idx on public.lead_assignments (caller_id);

-- -----------------------------------------------------------------------------
-- sync_jobs — durable job log for every import/sync/write-back
-- -----------------------------------------------------------------------------
create table public.sync_jobs (
  id uuid primary key default gen_random_uuid(),
  source_id uuid not null references public.data_sources (id) on delete cascade,
  job_type public.sync_job_type not null,
  status public.sync_job_status not null default 'queued',
  records_added integer not null default 0 check (records_added >= 0),
  records_updated integer not null default 0 check (records_updated >= 0),
  records_skipped integer not null default 0 check (records_skipped >= 0),
  attempts integer not null default 0 check (attempts >= 0),
  -- Backoff scheduling for retries.
  next_attempt_at timestamptz,
  error_message text,
  error_details jsonb,
  requested_by uuid references public.profiles (id) on delete set null,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  constraint sync_jobs_finished_after_start check (finished_at is null or finished_at >= started_at)
);

create index sync_jobs_source_idx on public.sync_jobs (source_id, started_at desc);
create index sync_jobs_status_idx on public.sync_jobs (status) where status in ('queued', 'running', 'failed');

-- -----------------------------------------------------------------------------
-- lead_conflicts — never silently overwrite; record both sides
-- -----------------------------------------------------------------------------
create table public.lead_conflicts (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads (id) on delete cascade,
  field text not null,
  local_value text,
  server_value text,
  local_source text not null default 'dashboard',
  server_source text,
  base_version integer,
  server_version integer,
  status text not null default 'open' check (status in ('open', 'resolved_local', 'resolved_server', 'dismissed')),
  resolved_by uuid references public.profiles (id) on delete set null,
  resolved_at timestamptz,
  created_at timestamptz not null default now()
);

create index lead_conflicts_open_idx on public.lead_conflicts (lead_id) where status = 'open';

-- -----------------------------------------------------------------------------
-- audit_logs — append-only
-- -----------------------------------------------------------------------------
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles (id) on delete set null,
  user_name text,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb,
  ip_address inet,
  created_at timestamptz not null default now()
);

create index audit_logs_created_idx on public.audit_logs (created_at desc);
create index audit_logs_user_idx on public.audit_logs (user_id, created_at desc);
create index audit_logs_entity_idx on public.audit_logs (entity_type, entity_id);

-- =============================================================================
-- Triggers
-- =============================================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger data_sources_set_updated_at before update on public.data_sources
  for each row execute function public.set_updated_at();
create trigger lead_statuses_set_updated_at before update on public.lead_statuses
  for each row execute function public.set_updated_at();
create trigger integration_credentials_set_updated_at before update on public.integration_credentials
  for each row execute function public.set_updated_at();

-- Optimistic concurrency counter.
create or replace function public.bump_lead_version()
returns trigger
language plpgsql
as $$
begin
  if row(new.*) is distinct from row(old.*) then
    new.version := old.version + 1;
    new.updated_at := now();
  end if;
  return new;
end;
$$;

create trigger leads_bump_version before update on public.leads
  for each row execute function public.bump_lead_version();

-- Assignment history.
create or replace function public.log_lead_assignment()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    if new.assigned_to is not null then
      insert into public.lead_assignments (lead_id, caller_id, assigned_by)
      values (new.id, new.assigned_to, auth.uid());
    end if;
  elsif new.assigned_to is distinct from old.assigned_to then
    insert into public.lead_assignments (lead_id, caller_id, assigned_by)
    values (new.id, new.assigned_to, auth.uid());
  end if;
  return new;
end;
$$;

create trigger leads_log_assignment after insert or update of assigned_to on public.leads
  for each row execute function public.log_lead_assignment();

-- Audit all lead mutations.
create or replace function public.audit_lead_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  actor_name text;
  target_id uuid;
  changed jsonb;
begin
  select full_name into actor_name from public.profiles where id = auth.uid();

  if tg_op = 'DELETE' then
    target_id := old.id;
    changed := null;
  else
    target_id := new.id;
    if tg_op = 'UPDATE' then
      select jsonb_object_agg(key, value) into changed
      from jsonb_each(to_jsonb(new))
      where key in ('name','phone','email','lead_status','lead_outcome','assigned_to',
                    'last_call_at','next_follow_up_at','notes')
        and value is distinct from (to_jsonb(old) -> key);
    end if;
  end if;

  insert into public.audit_logs (user_id, user_name, action, entity_type, entity_id, metadata)
  values (
    auth.uid(),
    actor_name,
    case tg_op when 'INSERT' then 'lead.created' when 'UPDATE' then 'lead.updated' else 'lead.deleted' end,
    'lead',
    target_id::text,
    case when changed is null then null else jsonb_build_object('changed', changed) end
  );
  return null;
end;
$$;

create trigger leads_audit after insert or update or delete on public.leads
  for each row execute function public.audit_lead_change();
