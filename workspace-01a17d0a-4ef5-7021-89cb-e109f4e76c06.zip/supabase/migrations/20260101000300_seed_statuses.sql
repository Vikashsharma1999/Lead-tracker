-- =============================================================================
-- Lead Tracker Dashboard — 0004 seed the configurable status vocabulary
-- Idempotent: safe to re-run on an existing database.
-- =============================================================================

insert into public.lead_statuses (value, label, color, sort_order, counts_as_dialed)
values
  ('not_dialed',          'Not Dialed',          '#94a3b8', 1,  false),
  ('dialed',              'Dialed',              '#3b82f6', 2,  true),
  ('interested',          'Interested',          '#22c55e', 3,  true),
  ('not_interested',      'Not Interested',      '#ef4444', 4,  true),
  ('call_back',           'Call Back',           '#f59e0b', 5,  true),
  ('webinar_link_shared', 'Webinar Link Shared', '#8b5cf6', 6,  true),
  ('follow_up_pending',   'Follow-up Pending',   '#06b6d4', 7,  true),
  ('bad_timing',          'Bad Timing',          '#a855f7', 8,  true),
  ('switched_off',        'Switched Off',        '#64748b', 9,  true),
  ('no_answer',           'No Answer',           '#f97316', 10, true)
on conflict (value) do update
  set label = excluded.label,
      color = excluded.color,
      sort_order = excluded.sort_order,
      counts_as_dialed = excluded.counts_as_dialed,
      updated_at = now();

-- A demo/manual data source makes first-run imports possible without OAuth.
insert into public.data_sources (name, source_type, connection_status, sync_mode, configuration)
select 'Manual entry', 'manual', 'connected', 'manual',
       jsonb_build_object('note', 'Records added directly in the dashboard.')
where not exists (
  select 1 from public.data_sources where source_type = 'manual'
);
