-- =============================================================================
-- Local development seed — SYNTHETIC DATA ONLY.
--
-- Creates a small, obviously fake dataset so the schema, RLS policies and
-- aggregates can be exercised locally. Do not put real customer data here.
--
-- To create the admin user locally, sign up through the app (the first user in
-- a fresh database becomes admin automatically), then optionally run this file.
-- =============================================================================

-- Sample sources (no credentials, no connected state claimed for external ones)
insert into public.data_sources (name, source_type, connection_status, sync_mode, sync_interval_seconds, configuration)
values
  ('Sample: Webinar signups', 'google_sheets', 'not_configured', 'manual',
   60, '{"worksheet": "Registrations", "demo": true}'::jsonb),
  ('Sample: Local Excel upload', 'excel_upload', 'connected', 'manual',
   0, '{"file_name": "sample-leads.xlsx", "demo": true}'::jsonb)
on conflict do nothing;

-- Sample leads, attached to whichever source is named "Sample: Local Excel upload"
do $$
declare
  v_source uuid;
  v_admin uuid;
  v_names text[] := array['Test Alpha','Test Bravo','Test Charlie','Test Delta','Test Echo'];
  v_statuses public.lead_status[] := array['not_dialed','call_back','interested','no_answer','follow_up_pending'];
  i int;
begin
  select id into v_source from public.data_sources where name = 'Sample: Local Excel upload' limit 1;
  select id into v_admin from public.profiles where role = 'admin' order by created_at limit 1;

  for i in 1..array_length(v_names, 1) loop
    insert into public.leads (
      source_id, source_sheet_name, source_record_id, name, phone, email,
      lead_status, assigned_to, next_follow_up_at, notes
    ) values (
      v_source, 'Sheet1', 'row-' || (i + 1), v_names[i],
      '+9715000000' || lpad(i::text, 2, '0'),
      'sample' || i || '@example.invalid',
      v_statuses[i],
      v_admin,
      case when v_statuses[i] in ('call_back','follow_up_pending') then now() + (i || ' days')::interval else null end,
      'Synthetic development record — safe to delete.'
    )
    on conflict do nothing;
  end loop;
end;
$$;
