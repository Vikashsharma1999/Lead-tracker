// google-oauth-start — begins the Google OAuth authorization code flow.
//
// Security notes:
//  * Requires an authenticated administrator (verified server-side).
//  * Uses the authorization-code flow with PKCE, so no client secret is needed
//    in the browser and the token exchange happens server-side.
//  * A signed, single-use `state` prevents CSRF / code injection.
//  * Least privilege: only Sheets + Drive metadata + the user's email.

import { handler, requireAdmin, json, fail, env } from '../_shared/http.ts';

const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/drive.metadata.readonly',
  'https://www.googleapis.com/auth/userinfo.email',
];

async function hmac(value: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const signature = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
  return btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function base64url(bytes: Uint8Array): string {
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

Deno.serve(
  handler(async (req) => {
    if (req.method !== 'POST') return fail('Use POST', 405);
    const caller = await requireAdmin(req);

    const body = await req.json().catch(() => ({}));
    const sourceId: string | undefined = body?.source_id;
    if (!sourceId) return fail('source_id is required');

    const statePayload = {
      sourceId,
      userId: caller.user.id,
      // 10 minute window
      exp: Date.now() + 10 * 60 * 1000,
      nonce: base64url(crypto.getRandomValues(new Uint8Array(16))),
    };
    const encodedState = base64url(new TextEncoder().encode(JSON.stringify(statePayload)));
    const signature = await hmac(encodedState, env('OAUTH_STATE_SECRET'));
    const state = `${encodedState}.${signature}`;

    // PKCE verifier is derived server-side and stored with the state signature;
    // the callback recomputes it from the same HMAC secret.
    const verifier = await hmac(`pkce:${encodedState}`, env('OAUTH_STATE_SECRET'));
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
    const challenge = base64url(new Uint8Array(digest));

    const params = new URLSearchParams({
      client_id: env('GOOGLE_OAUTH_CLIENT_ID'),
      redirect_uri: env('GOOGLE_OAUTH_REDIRECT_URI'),
      response_type: 'code',
      access_type: 'offline',
      prompt: 'consent', // guarantees a refresh token for background sync
      include_granted_scopes: 'true',
      scope: SCOPES.join(' '),
      state,
      code_challenge: challenge,
      code_challenge_method: 'S256',
    });

    return json({
      ok: true,
      authorization_url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`,
      expires_in: 600,
    });
  }),
);
