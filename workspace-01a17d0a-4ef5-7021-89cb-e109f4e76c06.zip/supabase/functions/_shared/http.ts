// Shared HTTP + auth helpers for Supabase Edge Functions (Deno runtime).
// Every function re-verifies the caller's identity and database role; the
// frontend is never trusted.

import { createClient, type SupabaseClient, type User } from 'https://esm.sh/@supabase/supabase-js@2.118.0';

export const CORS_HEADERS: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

export function preflight(): Response {
  return new Response('ok', { headers: CORS_HEADERS });
}

/** Safe error response: never leaks stack traces or secrets to the client. */
export function fail(message: string, status = 400): Response {
  return json({ ok: false, message }, status);
}

export function env(name: string): string {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Missing server configuration: ${name}`);
  return value;
}

export function adminClient(): SupabaseClient {
  return createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export interface Caller {
  user: User;
  client: SupabaseClient;
  role: 'admin' | 'caller';
  active: boolean;
  fullName: string;
}

/** Validates the bearer token and loads the caller's profile. */
export async function requireUser(req: Request): Promise<Caller> {
  const authHeader = req.headers.get('Authorization') ?? '';
  if (!authHeader.startsWith('Bearer ')) {
    throw new HttpError(401, 'Missing bearer token');
  }
  const client = createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await client.auth.getUser();
  if (error || !data.user) throw new HttpError(401, 'Invalid or expired session');

  const admin = adminClient();
  const { data: profile, error: profileError } = await admin
    .from('profiles')
    .select('role, active, full_name')
    .eq('id', data.user.id)
    .single();

  if (profileError || !profile) throw new HttpError(403, 'No profile for this account');
  if (!profile.active) throw new HttpError(403, 'Account deactivated');

  return {
    user: data.user,
    client,
    role: profile.role,
    active: profile.active,
    fullName: profile.full_name,
  };
}

export async function requireAdmin(req: Request): Promise<Caller> {
  const caller = await requireUser(req);
  if (caller.role !== 'admin') throw new HttpError(403, 'Administrator role required');
  return caller;
}

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

/** Wraps a handler with CORS, method checks and safe error mapping. */
export function handler(fn: (req: Request) => Promise<Response>): (req: Request) => Promise<Response> {
  return async (req: Request) => {
    if (req.method === 'OPTIONS') return preflight();
    try {
      return await fn(req);
    } catch (error) {
      if (error instanceof HttpError) return fail(error.message, error.status);
      console.error('[edge] unhandled error', error instanceof Error ? error.message : String(error));
      return fail(
        'The integration request failed. Check the sync job details for the recorded error.',
        500,
      );
    }
  };
}

export async function audit(
  client: SupabaseClient,
  caller: Caller | null,
  action: string,
  entityType: string,
  entityId: string | null,
  metadata?: Record<string, unknown>,
): Promise<void> {
  await client.from('audit_logs').insert({
    user_id: caller?.user.id ?? null,
    user_name: caller?.fullName ?? 'system',
    action,
    entity_type: entityType,
    entity_id: entityId,
    metadata: metadata ?? null,
  });
}
