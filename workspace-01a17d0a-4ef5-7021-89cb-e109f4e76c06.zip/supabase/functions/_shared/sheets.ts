// Pure Google Sheets mapping helpers.
//
// Kept free of Deno/runtime APIs so the exact same code can be unit-tested in
// Vitest (tests/unit/sheetsMapping.test.ts) and imported by `source-sync`.

export const VALID_STATUSES = [
  'not_dialed',
  'dialed',
  'interested',
  'not_interested',
  'call_back',
  'webinar_link_shared',
  'follow_up_pending',
  'bad_timing',
  'switched_off',
  'no_answer',
] as const;

export interface SheetValues {
  headers: string[];
  rows: Record<string, string>[];
}

/** Converts the raw `values` matrix from the Sheets API into header-keyed rows. */
export function parseSheetValues(values: unknown[][]): SheetValues {
  if (!values.length) return { headers: [], rows: [] };

  const [rawHeaders, ...body] = values;
  const headers = rawHeaders.map((header) => String(header ?? '').trim());

  const rows = body
    .filter((row) => row.some((cell) => String(cell ?? '').trim() !== ''))
    .map((row) => {
      const record: Record<string, string> = {};
      headers.forEach((header, index) => {
        record[header] = row[index] === undefined || row[index] === null ? '' : String(row[index]);
      });
      return record;
    });

  return { headers, rows };
}

export function parseDate(value: string): string | null {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

export interface MappedLeadRow {
  name: string;
  phone: string;
  email: string | null;
  lead_status: string;
  lead_outcome: string;
  notes: string | null;
  next_follow_up_at: string | null;
  source_external_id: string;
  source_sheet_name: string;
  source_record_id: string;
}

/**
 * Maps one worksheet row to internal lead fields using the stored column map.
 * Unmapped statuses fall back to `not_dialed` rather than failing the whole run.
 */
export function mapSheetRow(
  row: Record<string, string>,
  mapping: Record<string, string>,
  meta: { spreadsheetId: string; worksheet: string; rowNumber: number },
): MappedLeadRow {
  const pick = (field: string): string => {
    const header = mapping[field];
    const value = header ? row[header] : undefined;
    return (value ?? '').toString().trim();
  };

  const status = pick('lead_status')
    .toLowerCase()
    .replace(/[^a-z]+/g, '_')
    .replace(/^_|_$/g, '');

  return {
    name: pick('name'),
    phone: pick('phone'),
    email: pick('email') || null,
    lead_status: (VALID_STATUSES as readonly string[]).includes(status) ? status : 'not_dialed',
    lead_outcome: 'pending',
    notes: pick('notes') || null,
    next_follow_up_at: parseDate(pick('next_follow_up_at')),
    source_external_id: meta.spreadsheetId,
    source_sheet_name: meta.worksheet,
    source_record_id: pick('source_record_id') || `row-${meta.rowNumber}`,
  };
}

/** 0-based column index → spreadsheet column letters (0 → A, 26 → AA). */
export function columnLetter(index: number): string | null {
  if (index < 0) return null;
  let n = index;
  let letters = '';
  while (n >= 0) {
    letters = String.fromCharCode((n % 26) + 65) + letters;
    n = Math.floor(n / 26) - 1;
  }
  return letters;
}

export function statusLabel(value: string): string {
  return value
    .split('_')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

export interface WriteBackLead {
  source_record_id: string | null;
  lead_status: string;
  notes: string | null;
}

export interface ValueRange {
  range: string;
  values: string[][];
}

/**
 * Builds the batchUpdate payload that writes status (and notes) back to the
 * originating rows. Only leads with a numeric `row-N` source identifier are
 * written; anything else is skipped rather than guessed.
 */
export function buildWriteBackUpdates(
  leads: WriteBackLead[],
  headers: string[],
  worksheet: string,
  mapping: Record<string, string>,
): ValueRange[] {
  // Status falls back to a conventional header name; notes are only written
  // when the admin explicitly mapped a notes column (never overwrite silently).
  const statusIndex = headers.indexOf(mapping.lead_status ?? 'Lead Status');
  const notesIndex = mapping.notes ? headers.indexOf(mapping.notes) : -1;
  const statusColumn = columnLetter(statusIndex);
  if (!statusColumn) {
    throw new Error('The status column is not mapped for this source.');
  }
  const notesColumn = columnLetter(notesIndex);

  const updates: ValueRange[] = [];
  for (const lead of leads) {
    if (!lead.source_record_id) continue;
    const rowNumber = Number(String(lead.source_record_id).replace(/^row-/, ''));
    if (!Number.isFinite(rowNumber) || rowNumber < 2) continue;

    updates.push({
      range: `'${worksheet}'!${statusColumn}${rowNumber}`,
      values: [[statusLabel(lead.lead_status)]],
    });
    if (notesColumn) {
      updates.push({
        range: `'${worksheet}'!${notesColumn}${rowNumber}`,
        values: [[lead.notes ?? '']],
      });
    }
  }
  return updates;
}
