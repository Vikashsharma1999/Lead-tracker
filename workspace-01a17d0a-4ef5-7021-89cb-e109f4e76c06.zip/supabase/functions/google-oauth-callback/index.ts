// google-oauth-callback — exchanges the authorization code, verifies the grant
// by calling the Google API, and only then marks the source as connected.
//
// Rules enforced here:
//  * The `state` signature and expiry are validated (CSRF protection).
//  * The caller must still be an active admin of the workspace.
//  * Tokens are written to `integration_credentials`, a table with RLS enabled
//    and no policies (service role only). They never reach the browser.
//  * connection_status becomes 'connected' ONLY after a successful
//    spreadsheets.get call with the grant.

import { handler, adminClient, json, fail, env, HttpError, audit } from '../_shared/http.ts';

async function verifySignature(value: string, signature: string, secret: string): Promise<boolean> {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['verify'],
  );
  const normalized = signature.replace(/-/g, '+').replace(/_/g, '/');
  const binary = atob(normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), '='));
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return crypto.subtle.verify('HMAC', key, bytes, new TextEncoder().encode(value));
}

function decodeState(encoded: string): { sourceId: string; userId: string; exp: number } {
  const normalized = encoded.replace(/-/g, '+').replace(/_/g, '/');
  const text = atob(normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), '='));
  return JSON.parse(text);
}

Deno.serve(
  handler(async (req) => {
    const url = new URL(req.url);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state');
    const error = url.searchParams.get('error');

    const appRedirect = Deno.env.get('APP_REDIRECT_URL') ?? '/sources';

    if (error) {
      return Response.redirect(`${appRedirect}?google=denied`, 302);
    }
    if (!code || !state || !state.includes('.')) {
      return fail('Missing authorization code or state', 400);
    }

    const [encodedState, signature] = state.split('.');
    const valid = await verifySignature(encodedState, signature, env('OAUTH_STATE_SECRET'));
    if (!valid) return fail('Invalid OAuth state signature', 400);

    const parsed = decodeState(encodedState);
    if (Date.now() > parsed.exp) return fail('OAuth state expired — restart the connection', 400);

    const admin = adminClient();

    // Re-verify the initiating user is still an active admin.
    const { data: profile } = await admin
      .from('profiles')
      .select('role, active, full_name')
      .eq('id', parsed.userId)
      .single();
    if (!profile?.active || profile.role !== 'admin') {
      throw new HttpError(403, 'The initiating administrator is no longer authorised');
    }

    const { data: source } = await admin
      .from('data_sources')
      .select('id, name, configuration')
      .eq('id', parsed.sourceId)
      .single();
    if (!source) throw new HttpError(404, 'Data source not found');

    // --- Token exchange (server-side only) -----------------------------------
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: env('GOOGLE_OAUTH_CLIENT_ID'),
        client_secret: env('GOOGLE_OAUTH_CLIENT_SECRET'),
        redirect_uri: env('GOOGLE_OAUTH_REDIRECT_URI'),
        grant_type: 'authorization_code',
      }),
    });

    if (!tokenResponse.ok) {
      const detail = await tokenResponse.text();
      await admin
        .from('data_sources')
        .update({
          connection_status: 'error',
          last_error: `OAuth token exchange failed (HTTP ${tokenResponse.status})`,
        })
        .eq('id', parsed.sourceId);
      console.error('[google-oauth] token exchange failed', tokenResponse.status, detail);
      return fail('Google rejected the authorization. Restart the connection flow.', 400);
    }

    const tokens = await tokenResponse.json();

    // --- Verify the identity + the granted scope really work ----------------
    const profileResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    if (!profileResponse.ok) return fail('Could not verify the Google account', 400);
    const googleUser = await profileResponse.json();

    // A real API call proves the grant works before we ever say "connected".
    const externalId = (source.configuration ?? {})?.external_id as string | undefined;
    let verified = false;
    let lastError: string | null = null;

    if (externalId) {
      const check = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(externalId)}?fields=spreadsheetId,properties.title`,
        { headers: { Authorization: `Bearer ${tokens.access_token}` } },
      );
      verified = check.ok;
      if (!check.ok) lastError = `Spreadsheet access check failed (HTTP ${check.status})`;
    } else {
      // No spreadsheet chosen yet: list one to prove Sheets scope access.
      const check = await fetch(
        'https://www.googleapis.com/drive/v3/files?pageSize=1&fields=files(id,name)&q=mimeType%3D%27application%2Fvnd.google-apps.spreadsheet%27',
        { headers: { Authorization: `Bearer ${tokens.access_token}` } },
      );
      verified = check.ok;
      if (!check.ok) lastError = `Drive access check failed (HTTP ${check.status})`;
    }

    if (!verified) {
      await admin
        .from('data_sources')
        .update({ connection_status: 'error', last_error: lastError })
        .eq('id', parsed.sourceId);
      return fail(lastError ?? 'Google API verification failed', 400);
    }

    // --- Persist credentials (service role only table) ----------------------
    const expiresAt = new Date(Date.now() + (tokens.expires_in ?? 3600) * 1000).toISOString();
    await admin.from('integration_credentials').upsert(
      {
        source_id: parsed.sourceId,
        provider: 'google',
        external_account_email: googleUser.email,
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token ?? null,
        token_expires_at: expiresAt,
        scopes: String(tokens.scope ?? '').split(' ').filter(Boolean),
      },
      { onConflict: 'provider,external_account_email' },
    );

    await admin
      .from('data_sources')
      .update({
        connection_status: 'connected',
        last_error: null,
        configuration: {
          ...(source.configuration ?? {}),
          google_account: googleUser.email,
          connected_at: new Date().toISOString(),
        },
      })
      .eq('id', parsed.sourceId);

    await audit(admin, { user: { id: parsed.userId }, fullName: profile.full_name } as never,
      'source.oauth_connected', 'data_source', parsed.sourceId, { provider: 'google' });

    return Response.redirect(`${appRedirect}?google=connected&source=${parsed.sourceId}`, 302);
  }),
);
