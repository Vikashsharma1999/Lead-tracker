// source-sync — the single server entry point for every external sync action.
//
// Actions (POST JSON):
//   { action: 'test_connection', source_id }
//   { action: 'sync_now', source_id, job_type? }
//   { action: 'retry_failed', source_id }
//   { action: 'write_back', source_id, lead_ids }
//
// Properties:
//   * Admin-only, re-verified against the database on every call.
//   * Durable sync_jobs rows: queued → running → success/partial/failed, with
//     attempts, counts and error details.
//   * Idempotent: upserts are keyed on (source, worksheet, source_record_id),
//     so replaying a job never duplicates leads.
//   * Exponential backoff for failures (schedule_job_retry RPC).
//   * Never reports 'connected' without a live API call.

import {
  handler,
  requireAdmin,
  adminClient,
  json,
  fail,
  env,
  audit,
  HttpError,
} from '../_shared/http.ts';
import {
  buildWriteBackUpdates,
  mapSheetRow,
  parseSheetValues,
} from '../_shared/sheets.ts';

interface Source {
  id: string;
  name: string;
  source_type: 'google_sheets' | 'excel_onedrive' | 'excel_upload' | 'manual';
  connection_status: string;
  configuration: Record<string, unknown> | null;
  column_mapping: Record<string, string> | null;
  duplicate_policy: string;
  write_back_enabled: boolean;
}

interface Credential {
  access_token: string | null;
  refresh_token: string | null;
  token_expires_at: string | null;
  provider: string;
}

/** Returns a valid access token, refreshing it when close to expiry. */
async function googleAccessToken(admin: ReturnType<typeof adminClient>, sourceId: string): Promise<string> {
  const { data: credential } = await admin
    .from('integration_credentials')
    .select('access_token, refresh_token, token_expires_at')
    .eq('source_id', sourceId)
    .eq('provider', 'google')
    .maybeSingle();

  if (!credential?.access_token) {
    throw new HttpError(409, 'This source has no Google authorization. Connect it first.');
  }

  const expiresAt = credential.token_expires_at ? new Date(credential.token_expires_at).getTime() : 0;
  if (expiresAt - Date.now() > 60_000) return credential.access_token;

  if (!credential.refresh_token) {
    throw new HttpError(409, 'Google authorization expired and no refresh token is stored. Reconnect.');
  }

  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: env('GOOGLE_OAUTH_CLIENT_ID'),
      client_secret: env('GOOGLE_OAUTH_CLIENT_SECRET'),
      refresh_token: credential.refresh_token,
      grant_type: 'refresh_token',
    }),
  });

  if (!response.ok) throw new HttpError(409, 'Google refresh token was rejected. Reconnect the source.');
  const tokens = await response.json();

  await admin
    .from('integration_credentials')
    .update({
      access_token: tokens.access_token,
      token_expires_at: new Date(Date.now() + (tokens.expires_in ?? 3600) * 1000).toISOString(),
    })
    .eq('source_id', sourceId)
    .eq('provider', 'google');

  return tokens.access_token;
}

/** Reads a worksheet as a header-indexed array of objects. */
async function readSheet(
  accessToken: string,
  spreadsheetId: string,
  worksheet: string,
): Promise<{ headers: string[]; rows: Record<string, string>[] }> {
  const range = encodeURIComponent(`'${worksheet}'!A1:ZZ10000`);
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${range}?majorDimension=ROWS&valueRenderOption=UNFORMATTED_VALUE&dateTimeRenderOption=FORMATTED_STRING`,
    { headers: { Authorization: `Bearer ${accessToken}` } },
  );

  if (!response.ok) {
    throw new HttpError(
      502,
      `Google Sheets read failed (HTTP ${response.status}). Verify the worksheet name and sharing.`,
    );
  }

  const payload = await response.json();
  return parseSheetValues((payload.values ?? []) as unknown[][]);
}

async function startJob(
  admin: ReturnType<typeof adminClient>,
  sourceId: string,
  jobType: string,
  userId: string,
): Promise<string> {
  const { data, error } = await admin
    .from('sync_jobs')
    .insert({ source_id: sourceId, job_type: jobType, status: 'running', requested_by: userId })
    .select('id')
    .single();
  if (error) throw new HttpError(500, 'Could not create a sync job record');
  return data.id;
}

async function finishJob(
  admin: ReturnType<typeof adminClient>,
  jobId: string,
  patch: Record<string, unknown>,
): Promise<void> {
  await admin
    .from('sync_jobs')
    .update({ ...patch, finished_at: new Date().toISOString() })
    .eq('id', jobId);
}

Deno.serve(
  handler(async (req) => {
    if (req.method !== 'POST') return fail('Use POST', 405);
    const caller = await requireAdmin(req);
    const body = await req.json().catch(() => ({}));
    const action = String(body?.action ?? '');
    const sourceId = String(body?.source_id ?? '');
    if (!sourceId) return fail('source_id is required');

    const admin = adminClient();
    const { data: sourceRow, error: sourceError } = await admin
      .from('data_sources')
      .select('*')
      .eq('id', sourceId)
      .single();
    if (sourceError || !sourceRow) return fail('Data source not found', 404);
    const source = sourceRow as Source;
    const config = (source.configuration ?? {}) as Record<string, unknown>;
    const mapping = (source.column_mapping ?? {}) as Record<string, string>;
    const spreadsheetId = String(config.spreadsheet_id ?? config.external_id ?? '');
    const worksheet = String(config.worksheet ?? '');

    // ---------------------------------------------------------------- tests
    if (action === 'test_connection') {
      if (source.source_type === 'manual') {
        return json({
          ok: true,
          verified: true,
          message: 'Manual entry source — no external connection is required.',
        });
      }
      if (source.source_type === 'excel_upload') {
        return json({
          ok: false,
          verified: false,
          message:
            'Uploaded files are not linked to the cloud. Re-import the file to refresh, or connect a OneDrive/SharePoint workbook for continuous sync.',
        });
      }
      if (source.source_type !== 'google_sheets') {
        return json({
          ok: false,
          verified: false,
          message: 'Microsoft Graph integration is not configured on this deployment yet.',
        });
      }
      if (!spreadsheetId || !worksheet) {
        return json({
          ok: false,
          verified: false,
          message: 'Select a spreadsheet and worksheet before testing the connection.',
        });
      }

      try {
        const token = await googleAccessToken(admin, sourceId);
        const { headers } = await readSheet(token, spreadsheetId, worksheet);
        const mappedFields = Object.keys(mapping);
        await admin
          .from('data_sources')
          .update({
            connection_status: 'connected',
            last_error: null,
            last_sync_at: new Date().toISOString(),
          })
          .eq('id', sourceId);
        return json({
          ok: true,
          verified: true,
          message: `Google Sheets responded: ${headers.length} column(s), ${mappedFields.length} mapped field(s).`,
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Connection test failed';
        await admin
          .from('data_sources')
          .update({ connection_status: 'error', last_error: message })
          .eq('id', sourceId);
        return json({ ok: false, verified: false, message });
      }
    }

    // ---------------------------------------------------------------- retry
    if (action === 'retry_failed') {
      const { data: failed } = await admin
        .from('sync_jobs')
        .select('id, job_type, attempts')
        .eq('source_id', sourceId)
        .eq('status', 'failed')
        .order('started_at', { ascending: false })
        .limit(10);

      if (!failed?.length) {
        return json({ ok: false, verified: true, message: 'No failed jobs to retry.' });
      }

      const retried: string[] = [];
      for (const job of failed) {
        const { error } = await admin
          .from('sync_jobs')
          .update({ status: 'queued', next_attempt_at: new Date().toISOString(), error_message: null })
          .eq('id', job.id);
        if (!error) retried.push(job.id);
      }

      await audit(admin, caller, 'sync.retry_requested', 'data_source', sourceId, {
        jobs: retried.length,
      });
      return json({
        ok: retried.length > 0,
        verified: true,
        message: `${retried.length} failed job(s) queued for retry.`,
      });
    }

    // ------------------------------------------------------------- write-back
    if (action === 'write_back') {
      if (!source.write_back_enabled) {
        return json({
          ok: false,
          verified: true,
          message: 'Write-back is disabled for this source. Enable it in source settings first.',
        });
      }
      if (source.source_type !== 'google_sheets' || !spreadsheetId) {
        return json({ ok: false, verified: true, message: 'Write-back is only available for Google Sheets.' });
      }
      const leadIds: string[] = Array.isArray(body?.lead_ids) ? body.lead_ids : [];
      if (!leadIds.length) return json({ ok: false, verified: true, message: 'No leads selected.' });

      const jobId = await startJob(admin, sourceId, 'write_back', caller.user.id);
      try {
        const { data: leads } = await admin.from('leads').select('*').in('id', leadIds);
        const token = await googleAccessToken(admin, sourceId);
        const { headers } = await readSheet(token, spreadsheetId, worksheet);

        // Cell addressing + status labels live in the tested shared module.
        const updates = buildWriteBackUpdates(
          (leads ?? []).map((lead) => ({
            source_record_id: lead.source_record_id,
            lead_status: lead.lead_status,
            notes: lead.notes,
          })),
          headers,
          worksheet,
          mapping,
        );
        if (!updates.length) {
          throw new HttpError(409, 'None of the selected leads has a writable source row.');
        }

        const response = await fetch(
          `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values:batchUpdate`,
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ valueInputOption: 'USER_ENTERED', data: updates }),
          },
        );

        if (!response.ok) {
          const detail = await response.text();
          throw new HttpError(502, `Google write-back failed (HTTP ${response.status}): ${detail.slice(0, 300)}`);
        }

        await finishJob(admin, jobId, {
          status: 'success',
          records_updated: updates.length,
        });
        await audit(admin, caller, 'sync.write_back', 'data_source', sourceId, {
          cells: updates.length,
        });
        return json({
          ok: true,
          verified: true,
          message: `Wrote ${updates.length} cell update(s) back to “${worksheet}”.`,
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Write-back failed';
        await finishJob(admin, jobId, { status: 'failed', error_message: message });
        return json({ ok: false, verified: true, message });
      }
    }

    // ------------------------------------------------------------------ sync
    if (action !== 'sync_now' && action !== 'incremental') {
      return fail(`Unknown action: ${action}`, 400);
    }

    if (source.source_type === 'excel_upload' || source.source_type === 'manual') {
      return json({
        ok: false,
        verified: true,
        message:
          'This source has no linked online file. Re-import the workbook to refresh its records.',
      });
    }
    if (!spreadsheetId || !worksheet) {
      return json({
        ok: false,
        verified: false,
        message: 'Choose a spreadsheet and worksheet in source settings before syncing.',
      });
    }

    const jobId = await startJob(admin, sourceId, body?.job_type === 'incremental' ? 'incremental' : 'manual_refresh', caller.user.id);

    try {
      const token = await googleAccessToken(admin, sourceId);
      const { rows } = await readSheet(token, spreadsheetId, worksheet);

      const payload = rows.map((row, index) =>
        mapSheetRow(row, mapping, { spreadsheetId, worksheet, rowNumber: index + 2 }),
      );

      // import_leads handles dedupe, idempotency and counts in one transaction.
      const { data: result, error } = await caller.client.rpc('import_leads', {
        p_source_id: sourceId,
        p_rows: payload,
        p_policy: source.duplicate_policy ?? 'update',
        p_job_type: body?.job_type === 'incremental' ? 'incremental' : 'manual_refresh',
      });
      if (error) throw new HttpError(500, error.message);

      await finishJob(admin, jobId, {
        status: 'success',
        records_added: Number(result?.added ?? 0),
        records_updated: Number(result?.updated ?? 0),
        records_skipped: Number(result?.skipped ?? 0),
        attempts: 1,
      });

      await admin
        .from('data_sources')
        .update({
          connection_status: 'connected',
          last_error: null,
          last_sync_at: new Date().toISOString(),
          last_success_at: new Date().toISOString(),
        })
        .eq('id', sourceId);

      return json({
        ok: true,
        verified: true,
        message: `${result?.added ?? 0} added · ${result?.updated ?? 0} updated · ${result?.skipped ?? 0} skipped.`,
        job_id: jobId,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Sync failed';
      // Exponential backoff is applied inside the database.
      await admin.rpc('schedule_job_retry', { p_job_id: jobId, p_error: message });
      await admin
        .from('data_sources')
        .update({ connection_status: 'error', last_error: message })
        .eq('id', sourceId);
      return json({ ok: false, verified: false, message });
    }
  }),
);
