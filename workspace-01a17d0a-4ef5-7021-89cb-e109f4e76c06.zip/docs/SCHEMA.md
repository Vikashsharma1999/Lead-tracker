# Database schema reference

Migrations (applied in filename order):

1. `20260101000000_init_schema.sql` — enums, tables, indexes, triggers, audit plumbing.
2. `20260101000100_functions.sql` — identity helpers, profile bootstrap, guards, RPCs.
3. `20260101000200_rls.sql` — Row Level Security policies, realtime publication, storage bucket.
4. `20260101000300_seed_statuses.sql` — configurable status vocabulary (idempotent).

## Tables

### profiles
`id uuid pk → auth.users`, `full_name`, `email citext unique`, `role user_role` (`admin|caller`),
`active bool`, `last_seen_at`, `created_at`, `updated_at`.
First profile created becomes admin; later accounts default to caller. `guard_profile_write` blocks
non-admin role changes and self-demotion.

### leads
`id uuid pk`, `source_id → data_sources`, `source_external_id`, `source_sheet_name`, `source_record_id`,
`name`, `phone`, `phone_normalized` (generated via `normalize_phone`), `email citext`,
`lead_status`, `lead_outcome`, `assigned_to → profiles`, `last_call_at`, `next_follow_up_at`, `notes`,
`version int` (optimistic concurrency), `source_updated_at`, `source_hash`, `created_at`, `updated_at`.

Indexes: unique `(source_id, source_sheet_name, source_record_id)`; `phone_normalized`; `email`;
`assigned_to`; `lead_status`; `created_at desc`; partial `next_follow_up_at`; trigram on `name`.

### call_activities
`id`, `lead_id → leads (cascade)`, `caller_id → profiles`, `call_time`, `outcome`, `notes`,
`duration_seconds`, `client_reference` (unique per caller for idempotent offline replay), `created_at`.
Many calls per lead; lead counts never derive from this table.

### lead_assignments
Immutable history: `lead_id`, `caller_id`, `assigned_by`, `assigned_at`. Written by trigger.

### data_sources
`id`, `name`, `source_type`, `connection_status`, `sync_mode`, `sync_interval_seconds` (15–86400),
`last_sync_at`, `last_success_at`, `last_error`, `configuration jsonb` (non-secret),
`column_mapping jsonb`, `duplicate_policy` (`skip|update|create`), `write_back_enabled`,
`created_by`, timestamps. Unique expression index on `(source_type, configuration->>'external_id')`.

### integration_credentials
OAuth tokens (`access_token`, `refresh_token`, `token_expires_at`, `scopes`) per provider/account.
RLS enabled with **no policies** → service role only.

### sync_jobs
`id`, `source_id`, `job_type`, `status`, `records_added/updated/skipped`, `attempts`, `next_attempt_at`,
`error_message`, `error_details`, `requested_by`, `started_at`, `finished_at`.

### lead_conflicts
`lead_id`, `field`, `local_value`, `server_value`, `local_source`, `server_source`, `base_version`,
`server_version`, `status`, `resolved_by`, `resolved_at`, `created_at`.

### audit_logs
`user_id`, `user_name`, `action`, `entity_type`, `entity_id`, `metadata jsonb`, `ip_address`,
`created_at`. Append-only: no insert/update/delete policy for authenticated users.

### lead_statuses
`value lead_status pk`, `label`, `color`, `sort_order`, `counts_as_dialed`, `active`.

## RPCs

| Function | Who | Purpose |
| --- | --- | --- |
| `dashboard_summary(from,to)` | authenticated | KPI buckets, calls today, callbacks, overdue, unassigned — unique leads only |
| `report_summary(from,to,caller,source)` | authenticated | caller/source comparisons, 14-day series, work queues |
| `import_leads(source, rows jsonb, policy, job_type)` | admin | idempotent upsert with duplicate policy + job accounting |
| `log_call(lead, outcome, notes, time, status, follow_up, client_ref)` | assigned caller/admin | transactional call write + lead roll-forward |
| `resolve_conflict(conflict, resolution)` | admin | apply local value or keep server value, audited |
| `schedule_job_retry(job, error)` | service role | exponential backoff (2^n s, cap 300 s, 5 attempts) |
| `is_admin()`, `is_active_user()`, `owns_lead()`, `normalize_phone()` | helpers | policy support |

## RLS summary

| Table | Read | Write |
| --- | --- | --- |
| profiles | own, admins all, active-caller directory | own (basic), admins any, admins insert |
| leads | admins all, callers assigned only | admins all; callers own-row limited to call fields |
| call_activities | admins all, caller own/assigned | insert for assigned leads, append-only |
| lead_assignments | admins all, caller own | admins |
| data_sources | active users (read) | admins |
| sync_jobs / audit_logs | admins | triggers/service role |
| lead_conflicts | admins; callers for own leads | admins resolve |
| integration_credentials | none | service role only |
