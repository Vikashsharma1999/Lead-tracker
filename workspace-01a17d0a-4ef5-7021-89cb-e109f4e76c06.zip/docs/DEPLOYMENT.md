# Deployment, backup and recovery

## 1. Supabase (database + auth + functions)

```bash
npm i -g supabase
supabase login
supabase link --project-ref <PROJECT_REF>
supabase db push                     # applies migrations
supabase secrets set --env-file supabase/.env.production
npm run fn:deploy
```

`supabase/.env.production` (never committed):

```
SUPABASE_URL=https://<ref>.supabase.co
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
OAUTH_STATE_SECRET=...            # openssl rand -hex 32
GOOGLE_OAUTH_CLIENT_ID=...
GOOGLE_OAUTH_CLIENT_SECRET=...
GOOGLE_OAUTH_REDIRECT_URI=https://<ref>.functions.supabase.co/google-oauth-callback
APP_REDIRECT_URL=https://<your-domain>/sources
```

Then:

* Authentication → URL configuration: set Site URL and add your deployed origin to redirect URLs.
* Authentication → Providers → Email: enable, decide on "Confirm email".
* Database → Replication: confirm `leads`, `call_activities`, `data_sources`, `sync_jobs` are in the
  `supabase_realtime` publication.
* Create the first user; it becomes admin automatically.

### Interval sync scheduler

Edge Functions are request-driven. For 15–60 s freshness, schedule `source-sync` per source with
pg_cron:

```sql
select cron.schedule(
  'lead-sync-every-minute',
  '* * * * *',
  $$
  select net.http_post(
    url := 'https://<ref>.functions.supabase.co/source-sync',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer <SERVICE_ROLE_KEY>',
      'apikey', '<SERVICE_ROLE_KEY>'
    ),
    body := jsonb_build_object('action', 'sync_now')
  );
  $$
);
```

Store the service-role key in Supabase Vault and read it in the function body rather than pasting it
into the cron definition. Keep the schedule no faster than your sources change.

## 2. Vercel (frontend)

1. Import the repo; Vite preset is detected. `vercel.json` sets build command, SPA rewrites and headers.
2. Environment variables (Production + Preview):
   `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, optionally `VITE_APP_NAME`, `VITE_SUPPORT_EMAIL`.
3. `npm ci --legacy-peer-deps` is used as the install command in `vercel.json`.
4. Deploy, then add the production domain to Supabase redirect URLs.
5. Verify: HTTPS redirect, `sw.js` served with `no-cache`, manifest at `/manifest.webmanifest`, install
   prompt available, dashboard loads with real data.

### Alternative hosts

* Netlify / Cloudflare Pages: same build (`npm run build` → `dist`), add the SPA rewrite to
  `/index.html`, copy the security headers from `vercel.json`.
* Self-hosted Nginx: serve `dist/`, `try_files $uri /index.html`, add the same headers, ensure HTTPS.

## 3. CI (GitHub Actions)

`.github/workflows/ci.yml` runs on every push/PR:

1. `npm ci --legacy-peer-deps`
2. `npm run typecheck`
3. `npm test` (unit)
4. `npm run build`
5. Optional e2e job (Playwright, chromium) against the built preview.

Deployment is left to Vercel's Git integration; adding a `vercel deploy --prod` step is a one-liner if
you prefer Actions-driven releases.

## 4. Backups

Supabase (Pro plan and above) provides daily automatic backups with PITR options. Additionally:

```bash
# Logical backup (schema + data), run nightly from a trusted machine
pg_dump "postgresql://postgres:<password>@db.<ref>.supabase.co:5432/postgres" \
  --no-owner --format=custom --file "backup-$(date +%F).dump"

# Restore into a scratch project to verify the backup
pg_restore --clean --no-owner --dbname "postgresql://.../postgres" backup-2026-10-23.dump
```

Also export `storage.objects` for the `lead-imports` bucket if you rely on uploaded files.

## 5. Recovery runbook

| Scenario | Action |
| --- | --- |
| Bad migration | `supabase migration repair --status reverted <version>` then deploy a corrective migration; restore from PITR only if data was lost |
| Accidental bulk delete | Restore the `leads` table from the most recent backup into a scratch schema and re-insert by `id`; audit log shows who/when |
| Compromised service-role key | Rotate in Supabase → update function secrets + scheduler → redeploy functions |
| Compromised Google token | Revoke access in the Google account, delete the `integration_credentials` row, reconnect |
| Frontend regression | Vercel → Deployments → Promote a previous build (instant rollback) |
| Sync stuck/failing | Data Sources → Retry failed; inspect `sync_jobs.error_message`; check OAuth expiry |

## 6. Playwright on minimal containers

If Chromium fails to launch with `libnspr4.so: cannot open shared object file`, install the browser
dependencies:

```bash
npx playwright install --with-deps chromium   # needs root
# or, without root, extract the .deb files locally and point LD_LIBRARY_PATH at them
apt-get download libnspr4 libnss3 libatk1.0-0t64 libatk-bridge2.0-0t64 libcups2t64 libdrm2 \
  libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 \
  libasound2t64 libatspi2.0-0t64
for f in *.deb; do dpkg-deb -x "$f" ./root; done
LD_LIBRARY_PATH=$PWD/root/usr/lib/x86_64-linux-gnu npx playwright test
```
