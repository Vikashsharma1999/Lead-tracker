# Synchronisation architecture

Four independent pipelines. The UI keeps them visually separate so no one confuses "the dashboard
updated" with "the spreadsheet was written back".

## 1. Database realtime (always on)

`leads`, `call_activities`, `data_sources`, `sync_jobs` are in the `supabase_realtime` publication.
`subscribeToRealtime()` opens a channel and invalidates React Query caches on change. RLS is applied to
realtime payloads, so a caller receives only their own rows.

Latency: sub-second. This is *not* spreadsheet sync.

## 2. Google Sheets sync (per source)

```
scheduler/UI ──POST──▶ source-sync (admin verified)
                        ├─ load source + column_mapping + duplicate_policy
                        ├─ refresh OAuth token if < 60 s to expiry
                        ├─ GET  sheets.values  'Worksheet'!A1:ZZ10000
                        ├─ mapSheetRow()  → internal fields (pure, unit-tested)
                        ├─ RPC import_leads() → upsert + job accounting (single transaction)
                        └─ update data_sources.last_sync_at / last_success_at / last_error
```

* **Idempotency** — `unique (source_id, source_sheet_name, source_record_id)` plus phone/email matching;
  replaying a job never duplicates leads.
* **Incremental** — the current implementation reads the worksheet and upserts only rows whose values
  changed (the database increments `version` only on real change). A Sheets `revisionId`/Drive `changes`
  feed can be added to skip unchanged reads; `source_updated_at` and `source_hash` columns exist for it.
* **Retries** — failures call `schedule_job_retry`: `next_attempt_at = now() + 2^attempts seconds`
  (capped at 300 s) and the job becomes `failed` after 5 attempts. `retry_failed` re-queues them.
* **Write-back** — admin-triggered, only for mapped status/notes columns, only rows with a numeric
  `row-N` source id. A single `values:batchUpdate` call; the job type is `write_back`.
* **Conflict detection** — if a lead changed in the dashboard while a sheet row also changed, the import
  keeps the dashboard's call-derived fields (status/outcome/notes are only overwritten by explicit import
  policy) and any stale-version write from a client is recorded in `lead_conflicts` instead of applied.

## 3. Excel synchronisation

| File location | What happens |
| --- | --- |
| Uploaded `.xlsx`/`.xls`/`.csv` | Manual import; `excel_upload` source with `sync_mode = manual`. Re-import the changed file to refresh. **Never auto-synced.** |
| OneDrive / SharePoint (Phase 5) | Intended Graph-based interval sync; not implemented yet |
| Local file on a laptop | Only via the upload flow, or via a local sync agent (below) |

### Optional local sync agent architecture

For a file that lives on a workstation and must stay authoritative:

```
laptop: watcher (chokidar) ── changed file ──▶ parse (SheetJS) ──▶ POST /functions/v1/source-sync
                                                                  (admin JWT or scoped agent key)
                                                                  action: 'upload_rows'
```

Requirements for a safe agent:

* Runs under a dedicated `caller`-style service account with an **admin** profile limited to one source,
  or a signed agent token stored in the OS keychain (never in the repository).
* Watches file mtime/hash, debounces, uploads only valid rows, and reports per-run results to `sync_jobs`.
* Respects the duplicate policy and never writes back unless explicitly enabled.
* Documented as opt-in: the hosted dashboard cannot read a local disk, and the UI states that plainly.

## 4. Offline queue (client)

```
edit while offline ──▶ IndexedDB queued_writes (per user, with baseVersion)
reconnect ──▶ flushQueue() in order
              ├─ success  → remove, toast "synced"
              ├─ conflict → keep row, mark failed, record lead_conflicts, admin resolves
              └─ network  → stop, retry later with backoff
```

An edit is reported as saved only after the server responds. The queue is cleared on sign-out so a
shared device never exposes another user's pending customer data.

## Timing expectations

| Pipeline | Typical | Notes |
| --- | --- | --- |
| Database realtime | < 1 s | websocket |
| Google Sheets (scheduler at 60 s) | 60–90 s | Sheets API quota and scheduler granularity |
| Google Sheets (manual refresh) | 1–3 s | user-triggered |
| Excel upload | immediate | foreground import |
| OneDrive (Phase 5) | 30–120 s | not implemented |
| Offline replay | on reconnect | backoff up to 60 s between attempts |
