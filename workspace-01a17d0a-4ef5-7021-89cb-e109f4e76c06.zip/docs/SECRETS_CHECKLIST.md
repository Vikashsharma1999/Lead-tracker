# Credentials checklist

Tick these off before going live. Everything here is server-side unless marked **client**.

## Required for the app to work (no integrations)
- [ ] `VITE_SUPABASE_URL` **client**
- [ ] `VITE_SUPABASE_ANON_KEY` **client**
- [ ] `SUPABASE_URL` (Edge Functions)
- [ ] `SUPABASE_ANON_KEY` (Edge Functions)
- [ ] `SUPABASE_SERVICE_ROLE_KEY` (Edge Functions — never client)

## Required for Google Sheets (Phase 4)
- [ ] Google Cloud project with **Google Sheets API** + **Drive API** enabled
- [ ] OAuth client (Web application) + authorized redirect URI
- [ ] `GOOGLE_OAUTH_CLIENT_ID`
- [ ] `GOOGLE_OAUTH_CLIENT_SECRET`
- [ ] `GOOGLE_OAUTH_REDIRECT_URI`
- [ ] `OAUTH_STATE_SECRET` (`openssl rand -hex 32`)
- [ ] `APP_REDIRECT_URL` (where the callback sends the browser afterwards)
- [ ] Test spreadsheet shared with (or owned by) the connecting Google account
- [ ] Run `source-sync` → `test_connection` and confirm it reports success

## Required for OneDrive/SharePoint (Phase 5 — not implemented yet)
- [ ] Entra ID app registration, delegated `Files.Read`, `Files.ReadWrite`, `offline_access`
- [ ] `MS_OAUTH_TENANT_ID`, `MS_OAUTH_CLIENT_ID`, `MS_OAUTH_CLIENT_SECRET`, `MS_OAUTH_REDIRECT_URI`
- [ ] Graph functions deployed (to be built)

## Recommended
- [ ] GitHub Actions secrets for CI (`E2E_BASE_URL`, Supabase test project keys) — separate project
- [ ] Vercel env vars for Production and Preview environments
- [ ] Scheduled job runner (pg_cron or external) holding a service-role key in its own secret store

## Rotation
- Rotate `OAUTH_STATE_SECRET` at any time (invalidates in-flight OAuth states only).
- Rotate Google client secret → update function secret → reconnect sources.
- Rotate the Supabase service role key → update function secrets + scheduler → redeploy functions.
- Never rotate by pasting a key into client code or a `VITE_` variable.
