/**
 * Core domain types shared by the UI, the demo repository and the Supabase
 * repository. These mirror the SQL schema in supabase/migrations.
 */

export type Role = 'admin' | 'caller';

export type LeadStatus =
  | 'not_dialed'
  | 'dialed'
  | 'interested'
  | 'not_interested'
  | 'call_back'
  | 'webinar_link_shared'
  | 'follow_up_pending'
  | 'bad_timing'
  | 'switched_off'
  | 'no_answer';

/** Outcome is intentionally separate from call activity (see call_activities). */
export type LeadOutcome = 'pending' | 'positive' | 'neutral' | 'negative' | 'invalid';

export type SourceType = 'google_sheets' | 'excel_onedrive' | 'excel_upload' | 'manual';

export type ConnectionStatus = 'not_configured' | 'connected' | 'error' | 'disconnected';

export type SyncMode = 'manual' | 'interval' | 'webhook';

export type SyncJobType = 'initial_import' | 'incremental' | 'write_back' | 'manual_refresh';

export type SyncJobStatus = 'queued' | 'running' | 'success' | 'partial' | 'failed' | 'cancelled';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  role: Role;
  active: boolean;
  created_at: string;
}

export interface Lead {
  /** Internal, stable UUID/ID — never derived from a spreadsheet row. */
  id: string;
  source_id: string | null;
  /** Spreadsheet ID / workbook ID the record came from. */
  source_external_id: string | null;
  /** Worksheet/tab name the record came from. */
  source_sheet_name: string | null;
  /** Original row identifier in the source (e.g. sheet row number or key). */
  source_record_id: string | null;
  name: string;
  phone: string;
  email: string | null;
  lead_status: LeadStatus;
  lead_outcome: LeadOutcome;
  assigned_to: string | null;
  last_call_at: string | null;
  next_follow_up_at: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  /** Optimistic concurrency guard — incremented on every server write. */
  version: number;
}

export interface CallActivity {
  id: string;
  lead_id: string;
  caller_id: string;
  call_time: string;
  outcome: LeadOutcome;
  notes: string | null;
  created_at: string;
}

export interface DataSource {
  id: string;
  name: string;
  source_type: SourceType;
  connection_status: ConnectionStatus;
  sync_mode: SyncMode;
  sync_interval_seconds: number;
  last_sync_at: string | null;
  last_success_at: string | null;
  last_error: string | null;
  configuration: Record<string, unknown>;
  created_at: string;
}

export interface SyncJob {
  id: string;
  source_id: string;
  job_type: SyncJobType;
  status: SyncJobStatus;
  records_added: number;
  records_updated: number;
  records_skipped: number;
  attempts: number;
  error_message: string | null;
  started_at: string;
  finished_at: string | null;
}

export interface AuditLog {
  id: string;
  user_id: string | null;
  user_name: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface DashboardSummary {
  totalLeads: number;
  byStatus: Record<LeadStatus, number>;
  callsToday: number;
  callbacksDueToday: number;
  overdueFollowUps: number;
  unassigned: number;
}

export interface LeadFilters {
  search?: string;
  statuses?: LeadStatus[];
  assignedTo?: string | 'unassigned';
  sourceId?: string;
  outcome?: LeadOutcome;
  /** Inclusive ISO date (YYYY-MM-DD) applied to created_at. */
  dateFrom?: string;
  dateTo?: string;
  followUpDueBefore?: string;
}

export type SortField =
  | 'created_at'
  | 'name'
  | 'phone'
  | 'lead_status'
  | 'assigned_to'
  | 'last_call_at'
  | 'next_follow_up_at'
  | 'updated_at';

export interface SortSpec {
  field: SortField;
  direction: 'asc' | 'desc';
}

export interface PageRequest {
  page: number;
  pageSize: number;
  sort: SortSpec;
}

export interface Paginated<T> {
  rows: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface CallerStats {
  callerId: string;
  callerName: string;
  totalCalls: number;
  interested: number;
  callbacks: number;
  assignedLeads: number;
}

export interface SourceStats {
  sourceId: string;
  sourceName: string;
  total: number;
  interested: number;
  notDialed: number;
  lastSyncAt: string | null;
}

export interface DashboardReport {
  callerStats: CallerStats[];
  sourceStats: SourceStats[];
  leadsPerDay: { date: string; count: number }[];
  callbacksDueToday: Lead[];
  overdueFollowUps: Lead[];
}
