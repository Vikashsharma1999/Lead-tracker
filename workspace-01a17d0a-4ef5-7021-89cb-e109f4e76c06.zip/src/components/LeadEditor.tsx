import { useEffect, useMemo, useState } from 'react';
import { History, Info, PhoneCall, Save } from 'lucide-react';
import type { Lead, LeadOutcome, LeadStatus, Profile, Role } from '@/types/domain';
import { LEAD_OUTCOMES, LEAD_STATUSES } from '@/lib/constants';
import { formatDateTime, shortLeadId, toDateTimeInputValue } from '@/lib/format';
import { editableFields } from '@/lib/permissions';
import { useLeadActivities, useLogCall, useUpdateLead } from '@/hooks/useLeads';
import { Modal } from './Modal';
import { StatusChip } from './StatusChip';

interface Props {
  lead: Lead | null;
  mode: 'edit' | 'call';
  profiles: Profile[];
  role: Role;
  onClose: () => void;
  onSaved?: () => void;
}

interface FormState {
  name: string;
  phone: string;
  email: string;
  lead_status: LeadStatus;
  lead_outcome: LeadOutcome;
  assigned_to: string;
  last_call_at: string;
  next_follow_up_at: string;
  notes: string;
}

function toForm(lead: Lead): FormState {
  return {
    name: lead.name,
    phone: lead.phone,
    email: lead.email ?? '',
    lead_status: lead.lead_status,
    lead_outcome: lead.lead_outcome,
    assigned_to: lead.assigned_to ?? '',
    last_call_at: toDateTimeInputValue(lead.last_call_at),
    next_follow_up_at: toDateTimeInputValue(lead.next_follow_up_at),
    notes: lead.notes ?? '',
  };
}

export function LeadEditor({ lead, mode, profiles, role, onClose, onSaved }: Props) {
  const [form, setForm] = useState<FormState | null>(lead ? toForm(lead) : null);
  const [callNotes, setCallNotes] = useState('');
  const [callOutcome, setCallOutcome] = useState<LeadOutcome>('neutral');
  const updateLead = useUpdateLead();
  const logCall = useLogCall();
  const { data: activities, isLoading: loadingActivities } = useLeadActivities(lead?.id ?? null);

  const allowed = useMemo(() => new Set(editableFields(role)), [role]);

  useEffect(() => {
    setForm(lead ? toForm(lead) : null);
    setCallNotes('');
    setCallOutcome('neutral');
  }, [lead]);

  if (!lead || !form) return null;

  const isCall = mode === 'call' && allowed.has('lead_status');
  const canAssign = allowed.has('assigned_to');
  const busy = updateLead.isPending || logCall.isPending;

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((current) => (current ? { ...current, [key]: value } : current));

  const handleSave = async () => {
    const patch = {
      ...(allowed.has('name') ? { name: form.name.trim() } : {}),
      ...(allowed.has('phone') ? { phone: form.phone.trim() } : {}),
      ...(allowed.has('email') ? { email: form.email.trim() || null } : {}),
      ...(allowed.has('lead_status') ? { lead_status: form.lead_status } : {}),
      ...(allowed.has('lead_outcome') ? { lead_outcome: form.lead_outcome } : {}),
      ...(allowed.has('assigned_to') ? { assigned_to: form.assigned_to || null } : {}),
      ...(allowed.has('last_call_at')
        ? { last_call_at: form.last_call_at ? new Date(form.last_call_at).toISOString() : null }
        : {}),
      ...(allowed.has('next_follow_up_at')
        ? {
            next_follow_up_at: form.next_follow_up_at
              ? new Date(form.next_follow_up_at).toISOString()
              : null,
          }
        : {}),
      ...(allowed.has('notes') ? { notes: form.notes.trim() || null } : {}),
    };

    if (isCall) {
      await logCall.mutateAsync({
        lead_id: lead.id,
        leadName: lead.name,
        outcome: callOutcome,
        notes: callNotes.trim() || null,
        call_time: new Date().toISOString(),
        updateLead: {
          lead_status: form.lead_status,
          next_follow_up_at: form.next_follow_up_at
            ? new Date(form.next_follow_up_at).toISOString()
            : null,
        },
      });
      // Persist other permitted field edits (notes etc.) in the same action.
      if (form.notes !== (lead.notes ?? '') && allowed.has('notes')) {
        await updateLead.mutateAsync({ lead, patch: { notes: form.notes.trim() || null } });
      }
      onSaved?.();
      onClose();
      return;
    }

    await updateLead.mutateAsync({ lead, patch, label: `Update ${lead.name}` });
    onSaved?.();
    onClose();
  };

  return (
    <Modal
      open={Boolean(lead)}
      onClose={onClose}
      size="lg"
      title={isCall ? `Log call — ${lead.name}` : `Edit lead — ${lead.name}`}
      description={`${shortLeadId(lead.id)} · ${lead.source_sheet_name ?? 'no worksheet'} · row ${
        lead.source_record_id ?? '—'
      }`}
      footer={
        <>
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <button type="button" className="btn-primary" onClick={() => void handleSave()} disabled={busy}>
            {isCall ? <PhoneCall className="h-4 w-4" /> : <Save className="h-4 w-4" />}
            {busy ? 'Saving…' : isCall ? 'Save call & update lead' : 'Save changes'}
          </button>
        </>
      }
    >
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {!canAssign && (
            <p className="flex items-start gap-2 rounded-lg bg-navy-50 px-3 py-2 text-xs text-navy-600">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              You can update call status, outcome, follow-up date and notes. Contact details and
              assignment are admin-only.
            </p>
          )}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label>
              <span className="label">Full name</span>
              <input
                className="input"
                value={form.name}
                onChange={(e) => set('name', e.target.value)}
                disabled={!allowed.has('name')}
                required
              />
            </label>
            <label>
              <span className="label">Mobile number</span>
              <input
                className="input"
                value={form.phone}
                onChange={(e) => set('phone', e.target.value)}
                disabled={!allowed.has('phone')}
                inputMode="tel"
              />
            </label>
            <label>
              <span className="label">Email</span>
              <input
                className="input"
                type="email"
                value={form.email}
                onChange={(e) => set('email', e.target.value)}
                disabled={!allowed.has('email')}
              />
            </label>
            <label>
              <span className="label">Assigned caller</span>
              <select
                className="input"
                value={form.assigned_to}
                onChange={(e) => set('assigned_to', e.target.value)}
                disabled={!canAssign}
              >
                <option value="">Unassigned</option>
                {profiles
                  .filter((p) => p.role === 'caller')
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.full_name}
                      {!p.active ? ' (inactive)' : ''}
                    </option>
                  ))}
              </select>
            </label>
            <label>
              <span className="label">Call status</span>
              <select
                className="input"
                value={form.lead_status}
                onChange={(e) => set('lead_status', e.target.value as LeadStatus)}
                disabled={!allowed.has('lead_status')}
              >
                {LEAD_STATUSES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span className="label">Lead outcome</span>
              <select
                className="input"
                value={form.lead_outcome}
                onChange={(e) => set('lead_outcome', e.target.value as LeadOutcome)}
                disabled={!allowed.has('lead_outcome')}
              >
                {LEAD_OUTCOMES.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span className="label">Last call</span>
              <input
                type="datetime-local"
                className="input"
                value={form.last_call_at}
                onChange={(e) => set('last_call_at', e.target.value)}
                disabled={!allowed.has('last_call_at')}
              />
            </label>
            <label>
              <span className="label">Next follow-up</span>
              <input
                type="datetime-local"
                className="input"
                value={form.next_follow_up_at}
                onChange={(e) => set('next_follow_up_at', e.target.value)}
                disabled={!allowed.has('next_follow_up_at')}
              />
            </label>
          </div>

          {isCall && (
            <div className="rounded-xl border border-forest-200 bg-forest-50/60 p-3">
              <p className="mb-2 text-xs font-bold tracking-wide text-forest-800 uppercase">
                Call details
              </p>
              <label>
                <span className="label">Call outcome</span>
                <select
                  className="input"
                  value={callOutcome}
                  onChange={(e) => setCallOutcome(e.target.value as LeadOutcome)}
                >
                  {LEAD_OUTCOMES.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="mt-2 block">
                <span className="label">Call notes</span>
                <textarea
                  className="input min-h-20"
                  value={callNotes}
                  onChange={(e) => setCallNotes(e.target.value)}
                  placeholder="What did the lead say?"
                />
              </label>
            </div>
          )}

          <label className="block">
            <span className="label">Notes</span>
            <textarea
              className="input min-h-24"
              value={form.notes}
              onChange={(e) => set('notes', e.target.value)}
              disabled={!allowed.has('notes')}
              placeholder="Context for the next caller…"
            />
          </label>
        </div>

        <aside className="lg:col-span-1">
          <div className="rounded-xl border border-[var(--color-hairline)] bg-navy-50/40 p-3">
            <p className="flex items-center gap-1.5 text-xs font-bold tracking-wide text-navy-700 uppercase">
              <History className="h-3.5 w-3.5" aria-hidden /> Call history
            </p>
            {loadingActivities ? (
              <div className="mt-2 h-16 animate-pulse rounded bg-white" aria-hidden />
            ) : activities?.length ? (
              <ol className="mt-2 space-y-2">
                {activities.slice(0, 8).map((activity) => (
                  <li key={activity.id} className="rounded-lg bg-white p-2 text-[11px] shadow-sm">
                    <p className="font-semibold text-navy-900">{formatDateTime(activity.call_time)}</p>
                    <p className="text-navy-500 capitalize">{activity.outcome}</p>
                    {activity.notes && <p className="mt-0.5 line-clamp-2 text-navy-600">{activity.notes}</p>}
                  </li>
                ))}
              </ol>
            ) : (
              <p className="mt-2 text-[11px] text-navy-500">No calls logged yet for this lead.</p>
            )}
          </div>

          <div className="mt-3 rounded-xl border border-[var(--color-hairline)] p-3">
            <p className="text-xs font-bold tracking-wide text-navy-700 uppercase">Current status</p>
            <div className="mt-2">
              <StatusChip status={lead.lead_status} />
            </div>
            <dl className="mt-2 space-y-1 text-[11px] text-navy-500">
              <div className="flex justify-between gap-2">
                <dt>Outcome</dt>
                <dd className="font-semibold text-navy-800 capitalize">{lead.lead_outcome}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt>Version</dt>
                <dd className="font-mono">{lead.version}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt>Updated</dt>
                <dd>{formatDateTime(lead.updated_at)}</dd>
              </div>
            </dl>
          </div>
        </aside>
      </div>
    </Modal>
  );
}
