import { useMemo, useState } from 'react';
import { ChevronDown, FilterX, Search, SlidersHorizontal } from 'lucide-react';
import type { DataSource, LeadFilters, LeadStatus, Profile } from '@/types/domain';
import { LEAD_STATUSES } from '@/lib/constants';

interface Props {
  filters: LeadFilters;
  onChange: (patch: Partial<LeadFilters>) => void;
  onReset: () => void;
  profiles: Profile[];
  sources: DataSource[];
  showCallerFilter: boolean;
  resultCount?: number;
  totalCount?: number;
}

export function FilterBar({
  filters,
  onChange,
  onReset,
  profiles,
  sources,
  showCallerFilter,
  resultCount,
  totalCount,
}: Props) {
  const [expanded, setExpanded] = useState(false);
  const activeStatuses = useMemo(() => new Set(filters.statuses ?? []), [filters.statuses]);
  const activeCount =
    (filters.statuses?.length ?? 0) +
    (filters.assignedTo ? 1 : 0) +
    (filters.sourceId ? 1 : 0) +
    (filters.dateFrom ? 1 : 0) +
    (filters.dateTo ? 1 : 0) +
    (filters.outcome ? 1 : 0);

  const toggleStatus = (status: LeadStatus) => {
    const next = new Set(activeStatuses);
    if (next.has(status)) next.delete(status);
    else next.add(status);
    onChange({ statuses: next.size ? [...next] : undefined });
  };

  return (
    <div className="border-b border-[var(--color-hairline)] p-3 sm:p-4">
      <div className="flex flex-col gap-2.5 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
          <input
            type="search"
            className="input pl-9"
            placeholder="Search by name, phone number or lead ID…"
            value={filters.search ?? ''}
            onChange={(event) => onChange({ search: event.target.value })}
            aria-label="Search leads"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <details className="group relative">
            <summary className="btn-secondary list-none cursor-pointer select-none">
              <SlidersHorizontal className="h-4 w-4" aria-hidden />
              Status
              {activeStatuses.size > 0 && (
                <span className="ml-1 rounded-full bg-forest-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                  {activeStatuses.size}
                </span>
              )}
              <ChevronDown className="h-3.5 w-3.5 transition group-open:rotate-180" aria-hidden />
            </summary>
            <div className="absolute right-0 z-30 mt-2 w-64 rounded-xl border border-[var(--color-hairline)] bg-white p-2 shadow-xl">
              {LEAD_STATUSES.map((status) => (
                <label
                  key={status.value}
                  className="flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-1.5 text-sm hover:bg-navy-50"
                >
                  <input
                    type="checkbox"
                    className="h-3.5 w-3.5 rounded border-slate-300 accent-forest-600"
                    checked={activeStatuses.has(status.value)}
                    onChange={() => toggleStatus(status.value)}
                  />
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: status.color }} aria-hidden />
                  <span className="text-navy-800">{status.label}</span>
                </label>
              ))}
              <button
                type="button"
                onClick={() => onChange({ statuses: undefined })}
                className="mt-1 w-full rounded-lg px-2 py-1.5 text-left text-xs font-semibold text-forest-700 hover:bg-forest-50"
              >
                Clear status filter
              </button>
            </div>
          </details>

          <button
            type="button"
            className="btn-secondary lg:hidden"
            onClick={() => setExpanded((v) => !v)}
            aria-expanded={expanded}
          >
            More filters
            {activeCount > 0 && (
              <span className="rounded-full bg-forest-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                {activeCount}
              </span>
            )}
          </button>

          <div className={`${expanded ? 'grid' : 'hidden'} grid-cols-1 gap-2.5 sm:grid-cols-2 lg:flex lg:items-center`}>
            {showCallerFilter && (
              <select
                className="input lg:w-44"
                value={filters.assignedTo ?? ''}
                onChange={(event) => onChange({ assignedTo: event.target.value || undefined })}
                aria-label="Filter by caller"
              >
                <option value="">All callers</option>
                <option value="unassigned">Unassigned</option>
                {profiles
                  .filter((p) => p.role === 'caller')
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.full_name}
                      {!p.active ? ' (inactive)' : ''}
                    </option>
                  ))}
              </select>
            )}

            <select
              className="input lg:w-44"
              value={filters.sourceId ?? ''}
              onChange={(event) => onChange({ sourceId: event.target.value || undefined })}
              aria-label="Filter by source"
            >
              <option value="">All sources</option>
              {sources.map((source) => (
                <option key={source.id} value={source.id}>
                  {source.name}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-2">
              <label className="flex-1">
                <span className="sr-only">Created from</span>
                <input
                  type="date"
                  className="input lg:w-38"
                  value={filters.dateFrom ?? ''}
                  onChange={(event) => onChange({ dateFrom: event.target.value || undefined })}
                />
              </label>
              <span className="text-xs text-navy-500">to</span>
              <label className="flex-1">
                <span className="sr-only">Created to</span>
                <input
                  type="date"
                  className="input lg:w-38"
                  value={filters.dateTo ?? ''}
                  onChange={(event) => onChange({ dateTo: event.target.value || undefined })}
                />
              </label>
            </div>

            <button type="button" className="btn-ghost" onClick={onReset}>
              <FilterX className="h-4 w-4" aria-hidden />
              Reset
            </button>
          </div>
        </div>
      </div>

      {(resultCount !== undefined || activeCount > 0) && (
        <p className="mt-2 text-[11px] font-medium text-navy-500">
          {resultCount !== undefined ? (
            <>
              Showing <strong className="text-navy-800">{resultCount.toLocaleString()}</strong>
              {totalCount !== undefined && ` of ${totalCount.toLocaleString()}`} matching leads
            </>
          ) : (
            `${activeCount} filter${activeCount === 1 ? '' : 's'} active`
          )}
        </p>
      )}
    </div>
  );
}
