import { useMemo } from 'react';
import { MessageSquare, Pencil, Phone, Trash2 } from 'lucide-react';
import type { DataSource, Lead, Profile, Role, SortField, SortSpec } from '@/types/domain';
import { formatDate, formatDateTime, shortLeadId } from '@/lib/format';
import { StatusChip, OutcomeChip } from './StatusChip';
import { SortHeader } from './SortHeader';
import { EmptyState } from './EmptyState';
import { TableSkeleton } from './Spinner';

interface Props {
  leads: Lead[];
  loading: boolean;
  sort: SortSpec;
  onSort: (field: SortField) => void;
  profiles: Profile[];
  sources: DataSource[];
  role: Role;
  selected: Set<string>;
  onToggleRow: (id: string) => void;
  onToggleAll: () => void;
  onEdit: (lead: Lead) => void;
  onLogCall: (lead: Lead) => void;
  onDelete?: (lead: Lead) => void;
  emptyAction?: React.ReactNode;
}

export function LeadTable({
  leads,
  loading,
  sort,
  onSort,
  profiles,
  sources,
  role,
  selected,
  onToggleRow,
  onToggleAll,
  onEdit,
  onLogCall,
  onDelete,
  emptyAction,
}: Props) {
  const callerName = useMemo(() => {
    const map = new Map(profiles.map((p) => [p.id, p.full_name]));
    return (id: string | null) => (id ? (map.get(id) ?? 'Unassigned') : 'Unassigned');
  }, [profiles]);

  const sourceName = useMemo(() => {
    const map = new Map(sources.map((s) => [s.id, s.name]));
    return (id: string | null) => (id ? (map.get(id) ?? '—') : '—');
  }, [sources]);

  const allSelected = leads.length > 0 && leads.every((l) => selected.has(l.id));

  if (loading) return <TableSkeleton rows={8} cols={7} />;

  if (!leads.length) {
    return (
      <EmptyState
        title="No leads match these filters"
        description="Try clearing the search or widening the date range."
        action={emptyAction}
      />
    );
  }

  return (
    <>
      {/* Desktop / tablet table */}
      <div className="hidden max-h-[70vh] overflow-auto md:block">
        <table className="w-full min-w-[1020px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-[var(--color-hairline)]">
              <th scope="col" className="table-header sticky top-0 z-10 w-10 px-3 py-2.5">
                <input
                  type="checkbox"
                  className="h-3.5 w-3.5 rounded border-slate-300 accent-forest-600"
                  checked={allSelected}
                  onChange={onToggleAll}
                  aria-label="Select all rows on this page"
                />
              </th>
              <SortHeader field="created_at" label="Lead ID / Date" sort={sort} onSort={onSort} />
              <SortHeader field="name" label="Name" sort={sort} onSort={onSort} />
              <SortHeader field="phone" label="Mobile" sort={sort} onSort={onSort} />
              <th scope="col" className="table-header hidden px-3 py-2.5 text-left 2xl:table-cell">Email</th>
              <th scope="col" className="table-header px-3 py-2.5 text-left">Source / Worksheet</th>
              <SortHeader field="assigned_to" label="Caller" sort={sort} onSort={onSort} />
              <SortHeader field="lead_status" label="Status" sort={sort} onSort={onSort} />
              <th scope="col" className="table-header px-3 py-2.5 text-left">Outcome</th>
              <SortHeader field="last_call_at" label="Last Call" sort={sort} onSort={onSort} />
              <SortHeader field="next_follow_up_at" label="Next Follow-up" sort={sort} onSort={onSort} />
              <th scope="col" className="table-header hidden px-3 py-2.5 text-left 2xl:table-cell">Notes</th>
              <th scope="col" className="table-header hidden px-3 py-2.5 text-left 2xl:table-cell">Updated</th>
              <th scope="col" className="table-header px-3 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--color-hairline)]">
            {leads.map((lead) => {
              const checked = selected.has(lead.id);
              return (
                <tr
                  key={lead.id}
                  className={`transition hover:bg-forest-50/40 ${checked ? 'bg-forest-50/60' : ''}`}
                >
                  <td className="px-3 py-2.5 align-top">
                    <input
                      type="checkbox"
                      className="h-3.5 w-3.5 rounded border-slate-300 accent-forest-600"
                      checked={checked}
                      onChange={() => onToggleRow(lead.id)}
                      aria-label={`Select lead ${lead.name}`}
                    />
                  </td>
                  <td className="px-3 py-2.5 align-top whitespace-nowrap">
                    <span className="block font-mono text-[11px] font-semibold text-forest-700">
                      {shortLeadId(lead.id)}
                    </span>
                    <span className="text-[11px] text-navy-500">{formatDate(lead.created_at)}</span>
                  </td>
                  <td className="px-3 py-2.5 align-top">
                    <span className="block max-w-[160px] truncate font-semibold text-navy-900">{lead.name}</span>
                    <span className="text-[11px] text-navy-500">
                      {lead.source_record_id ? `Row ${lead.source_record_id.replace(/^row-/, '')}` : '—'}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 align-top whitespace-nowrap text-navy-800">{lead.phone}</td>
                  <td className="hidden px-3 py-2.5 align-top 2xl:table-cell">
                    <span className="block max-w-[180px] truncate text-navy-700">{lead.email ?? '—'}</span>
                  </td>
                  <td className="px-3 py-2.5 align-top">
                    <span className="block max-w-[170px] truncate text-navy-800">{sourceName(lead.source_id)}</span>
                    <span className="text-[11px] text-navy-500">{lead.source_sheet_name ?? '—'}</span>
                  </td>
                  <td className="px-3 py-2.5 align-top whitespace-nowrap text-navy-700">
                    {callerName(lead.assigned_to)}
                  </td>
                  <td className="px-3 py-2.5 align-top">
                    <StatusChip status={lead.lead_status} />
                  </td>
                  <td className="px-3 py-2.5 align-top">
                    <OutcomeChip outcome={lead.lead_outcome} />
                  </td>
                  <td className="px-3 py-2.5 align-top whitespace-nowrap text-[12px] text-navy-700">
                    {lead.last_call_at ? formatDateTime(lead.last_call_at) : '—'}
                  </td>
                  <td className="px-3 py-2.5 align-top whitespace-nowrap text-[12px]">
                    {lead.next_follow_up_at ? (
                      <span
                        className={
                          new Date(lead.next_follow_up_at).getTime() <
                          new Date(new Date().toDateString()).getTime()
                            ? 'font-semibold text-red-600'
                            : 'text-navy-700'
                        }
                      >
                        {formatDateTime(lead.next_follow_up_at)}
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="hidden px-3 py-2.5 align-top 2xl:table-cell">
                    <span className="block max-w-[190px] truncate text-[12px] text-navy-500" title={lead.notes ?? ''}>
                      {lead.notes || '—'}
                    </span>
                  </td>
                  <td className="hidden px-3 py-2.5 align-top whitespace-nowrap text-[11px] text-navy-500 2xl:table-cell">
                    {formatDateTime(lead.updated_at)}
                  </td>
                  <td className="px-3 py-2.5 align-top text-right whitespace-nowrap">
                    <div className="inline-flex gap-1">
                      <button
                        type="button"
                        onClick={() => onLogCall(lead)}
                        className="rounded-lg p-1.5 text-forest-700 hover:bg-forest-50"
                        title="Log a call"
                        aria-label={`Log a call for ${lead.name}`}
                      >
                        <Phone className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onEdit(lead)}
                        className="rounded-lg p-1.5 text-navy-700 hover:bg-navy-50"
                        title="Edit lead"
                        aria-label={`Edit ${lead.name}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      {role === 'admin' && onDelete && (
                        <button
                          type="button"
                          onClick={() => onDelete(lead)}
                          className="rounded-lg p-1.5 text-red-600 hover:bg-red-50"
                          title="Delete lead"
                          aria-label={`Delete ${lead.name}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <ul className="divide-y divide-[var(--color-hairline)] md:hidden">
        {leads.map((lead) => (
          <li key={lead.id} className="p-3.5">
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                className="mt-1 h-4 w-4 rounded border-slate-300 accent-forest-600"
                checked={selected.has(lead.id)}
                onChange={() => onToggleRow(lead.id)}
                aria-label={`Select lead ${lead.name}`}
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-semibold text-navy-900">{lead.name}</p>
                    <p className="font-mono text-[11px] text-forest-700">{shortLeadId(lead.id)}</p>
                  </div>
                  <StatusChip status={lead.lead_status} />
                </div>
                <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[12px]">
                  <div>
                    <dt className="text-[10px] text-navy-500 uppercase">Mobile</dt>
                    <dd className="truncate text-navy-800">{lead.phone}</dd>
                  </div>
                  <div>
                    <dt className="text-[10px] text-navy-500 uppercase">Caller</dt>
                    <dd className="truncate text-navy-800">{callerName(lead.assigned_to)}</dd>
                  </div>
                  <div>
                    <dt className="text-[10px] text-navy-500 uppercase">Last call</dt>
                    <dd className="truncate text-navy-800">
                      {lead.last_call_at ? formatDate(lead.last_call_at) : '—'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[10px] text-navy-500 uppercase">Follow-up</dt>
                    <dd className="truncate text-navy-800">
                      {lead.next_follow_up_at ? formatDate(lead.next_follow_up_at) : '—'}
                    </dd>
                  </div>
                  <div className="col-span-2">
                    <dt className="text-[10px] text-navy-500 uppercase">Source</dt>
                    <dd className="truncate text-navy-800">
                      {sourceName(lead.source_id)} · {lead.source_sheet_name ?? '—'}
                    </dd>
                  </div>
                </dl>
                {lead.notes && (
                  <p className="mt-1.5 flex gap-1.5 text-[12px] text-navy-500">
                    <MessageSquare className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                    <span className="line-clamp-2">{lead.notes}</span>
                  </p>
                )}
                <div className="mt-2.5 flex gap-2">
                  <button type="button" className="btn-secondary flex-1 py-1.5 text-xs" onClick={() => onLogCall(lead)}>
                    <Phone className="h-3.5 w-3.5" /> Log call
                  </button>
                  <button type="button" className="btn-primary flex-1 py-1.5 text-xs" onClick={() => onEdit(lead)}>
                    <Pencil className="h-3.5 w-3.5" /> Edit
                  </button>
                  {role === 'admin' && onDelete && (
                    <button
                      type="button"
                      className="btn-ghost px-2 py-1.5 text-xs text-red-600"
                      onClick={() => onDelete(lead)}
                      aria-label={`Delete ${lead.name}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
}
