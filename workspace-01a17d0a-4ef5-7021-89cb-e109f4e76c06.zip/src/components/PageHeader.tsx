import type { ReactNode } from 'react';
import { DemoBadge } from './DemoBadge';

interface PageHeaderProps {
  title: string;
  subtitle: string;
  actions?: ReactNode;
  meta?: ReactNode;
}

/**
 * Dark forest-green page header: white title + subtitle, action buttons on the
 * right. Used on every authenticated page for a consistent CRM shell.
 */
export function PageHeader({ title, subtitle, actions, meta }: PageHeaderProps) {
  return (
    <header className="relative overflow-hidden rounded-2xl bg-forest-800 px-5 py-5 text-white shadow-[0_18px_30px_-24px_rgba(7,26,16,0.9)] sm:px-7 sm:py-6">
      <div
        className="pointer-events-none absolute -top-24 -right-16 h-64 w-64 rounded-full bg-forest-600/40 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -bottom-28 left-1/3 h-56 w-56 rounded-full bg-forest-500/20 blur-3xl"
        aria-hidden
      />
      <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <div className="mb-1.5 flex items-center gap-2">
            <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold tracking-[0.14em] text-forest-100 uppercase ring-1 ring-white/15 ring-inset">
              CRM
            </span>
            <DemoBadge />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white sm:text-2xl">{title}</h1>
          <p className="mt-1 text-sm text-forest-100/90">{subtitle}</p>
          {meta && <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-forest-100/80">{meta}</div>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </header>
  );
}
