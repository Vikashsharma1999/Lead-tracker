import { Activity, CloudOff, Database, FileSpreadsheet, Sheet } from 'lucide-react';
import type { DataSource } from '@/types/domain';
import { formatDateTime, formatRelative } from '@/lib/format';
import { appMode } from '@/lib/env';

interface Props {
  sources: DataSource[] | undefined;
  pendingCount: number;
  online: boolean;
  lastRefreshedAt: Date | null;
}

/**
 * Distinguishes the four independent pipelines the spec requires:
 *   1. database realtime, 2. Google Sheets sync, 3. Excel sync, 4. offline queue.
 * A green dot only appears when the server reports a real connection.
 */
export function SyncStatusBar({ sources, pendingCount, online, lastRefreshedAt }: Props) {
  const connected = (sources ?? []).filter((s) => s.connection_status === 'connected');
  const sheets = (sources ?? []).filter((s) => s.source_type === 'google_sheets');
  const excel = (sources ?? []).filter(
    (s) => s.source_type === 'excel_onedrive' || s.source_type === 'excel_upload',
  );
  const successTimes = (sources ?? [])
    .map((s) => s.last_success_at)
    .filter((v): v is string => Boolean(v))
    .sort();
  const lastSync = successTimes.at(-1) ?? null;

  const sheetsStatus =
    sheets.length === 0
      ? { text: 'Not connected', tone: 'bg-slate-300' }
      : sheets.some((s) => s.connection_status === 'connected')
        ? { text: `${sheets.filter((s) => s.connection_status === 'connected').length} connected`, tone: 'bg-emerald-500' }
        : { text: sheets.some((s) => s.connection_status === 'error') ? 'Error' : 'Not configured', tone: sheets.some((s) => s.connection_status === 'error') ? 'bg-red-500' : 'bg-amber-500' };

  const excelStatus =
    excel.length === 0
      ? { text: 'Manual import only', tone: 'bg-slate-300' }
      : excel.some((s) => s.connection_status === 'connected')
        ? { text: 'Connected', tone: 'bg-emerald-500' }
        : { text: 'Not configured', tone: 'bg-amber-500' };

  return (
    <div className="card grid grid-cols-1 divide-y divide-[var(--color-hairline)] sm:grid-cols-2 sm:divide-y-0 lg:grid-cols-4 lg:divide-x">
      <div className="flex items-start gap-3 p-3.5">
        <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-forest-50 text-forest-700">
          <Database className="h-4 w-4" aria-hidden />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold tracking-wide text-navy-500 uppercase">Database</p>
          <p className="flex items-center gap-1.5 text-sm font-semibold text-navy-900">
            <span
              className={`h-1.5 w-1.5 rounded-full ${appMode === 'live' && online ? 'bg-emerald-500' : 'bg-amber-500'}`}
              aria-hidden
            />
            {appMode === 'live' ? (online ? 'Realtime connected' : 'Reconnecting…') : 'Local demo store'}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-navy-500">
            {lastRefreshedAt ? `Refreshed ${formatRelative(lastRefreshedAt.toISOString())}` : 'Awaiting first refresh'}
          </p>
        </div>
      </div>

      <div className="flex items-start gap-3 p-3.5">
        <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-violet-50 text-violet-700">
          <Sheet className="h-4 w-4" aria-hidden />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold tracking-wide text-navy-500 uppercase">Google Sheets</p>
          <p className="flex items-center gap-1.5 text-sm font-semibold text-navy-900">
            <span className={`h-1.5 w-1.5 rounded-full ${sheetsStatus.tone}`} aria-hidden />
            {sheetsStatus.text}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-navy-500">
            Last success: {lastSync ? formatDateTime(lastSync) : 'never'}
          </p>
        </div>
      </div>

      <div className="flex items-start gap-3 p-3.5">
        <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-700">
          <FileSpreadsheet className="h-4 w-4" aria-hidden />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold tracking-wide text-navy-500 uppercase">Excel / OneDrive</p>
          <p className="flex items-center gap-1.5 text-sm font-semibold text-navy-900">
            <span className={`h-1.5 w-1.5 rounded-full ${excelStatus.tone}`} aria-hidden />
            {excelStatus.text}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-navy-500">
            {connected.length
              ? `${connected.length} source${connected.length === 1 ? '' : 's'} connected`
              : 'Uploads are manual; no background sync'}
          </p>
        </div>
      </div>

      <div className="flex items-start gap-3 p-3.5">
        <span
          className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
            pendingCount ? 'bg-amber-50 text-amber-700' : 'bg-navy-50 text-navy-500'
          }`}
        >
          {pendingCount ? <CloudOff className="h-4 w-4" aria-hidden /> : <Activity className="h-4 w-4" aria-hidden />}
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold tracking-wide text-navy-500 uppercase">Offline queue</p>
          <p className="text-sm font-semibold text-navy-900">
            {pendingCount === 0 ? 'All changes saved' : `${pendingCount} pending`}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-navy-500">
            {online ? 'Online' : 'Offline — edits held on device'}
          </p>
        </div>
      </div>
    </div>
  );
}
