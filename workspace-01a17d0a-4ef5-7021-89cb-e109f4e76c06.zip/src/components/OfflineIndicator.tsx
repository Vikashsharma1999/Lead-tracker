import { useCallback, useEffect, useState } from 'react';
import { CloudOff, RefreshCw, WifiOff } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useOnline } from '@/hooks/useOnline';
import { useToast } from '@/hooks/useToasts';
import { getRepository } from '@/data';
import { flushQueue } from '@/lib/offline/queue';
import { listQueuedWrites, type QueuedWrite } from '@/lib/offline/db';

/**
 * Offline status + pending-write counter.
 *
 * The count comes from IndexedDB, never from optimism: an edit stays "pending"
 * until the server acknowledges it.
 */
export function OfflineIndicator() {
  const online = useOnline();
  const { profile } = useAuth();
  const { push } = useToast();
  const [pending, setPending] = useState<QueuedWrite[]>([]);
  const [flushing, setFlushing] = useState(false);

  const refresh = useCallback(async () => {
    if (!profile) return;
    try {
      setPending(await listQueuedWrites(profile.id));
    } catch {
      setPending([]);
    }
  }, [profile]);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => void refresh(), 8000);
    window.addEventListener('online', () => void refresh());
    return () => {
      window.clearInterval(timer);
    };
  }, [refresh]);

  const flush = useCallback(async () => {
    if (!profile || flushing) return;
    setFlushing(true);
    try {
      const result = await flushQueue({
        repository: getRepository(),
        userId: profile.id,
        role: profile.role,
      });
      if (result.synced > 0) {
        push({
          variant: 'success',
          title: `${result.synced} queued change${result.synced === 1 ? '' : 's'} synced`,
        });
      }
      if (result.conflicts.length) {
        push({
          variant: 'error',
          title: `${result.conflicts.length} conflict(s) need review`,
          description: 'Your offline edit was kept local; the server copy was not overwritten.',
        });
      }
      if (result.failed > 0) {
        push({ variant: 'error', title: `${result.failed} queued change(s) failed` });
      }
    } catch (error) {
      push({
        variant: 'error',
        title: 'Could not flush the offline queue',
        description: error instanceof Error ? error.message : 'Unknown error',
      });
    } finally {
      setFlushing(false);
      await refresh();
    }
  }, [profile, flushing, push, refresh]);

  useEffect(() => {
    if (online && pending.length) void flush();
    // Only re-run when connectivity changes; the flush guard prevents loops.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online]);

  if (online && pending.length === 0) return null;

  return (
    <div
      className={`flex flex-wrap items-center justify-between gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold ring-1 ring-inset ${
        online ? 'bg-amber-50 text-amber-900 ring-amber-200' : 'bg-navy-900 text-white ring-navy-700'
      }`}
      role="status"
      aria-live="polite"
    >
      <span className="flex items-center gap-2">
        {online ? <CloudOff className="h-4 w-4" aria-hidden /> : <WifiOff className="h-4 w-4" aria-hidden />}
        {online
          ? `${pending.length} change${pending.length === 1 ? '' : 's'} waiting to sync — not yet saved to the server`
          : 'You are offline. Edits are queued on this device until the connection returns.'}
      </span>
      {pending.length > 0 && (
        <button
          type="button"
          onClick={() => void flush()}
          disabled={!online || flushing}
          className={`inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] font-bold uppercase tracking-wide ${
            online ? 'bg-amber-900/10 hover:bg-amber-900/20' : 'bg-white/10 hover:bg-white/20'
          } disabled:opacity-50`}
        >
          <RefreshCw className={`h-3.5 w-3.5 ${flushing ? 'animate-spin' : ''}`} aria-hidden />
          {flushing ? 'Syncing' : 'Retry now'}
        </button>
      )}
    </div>
  );
}
