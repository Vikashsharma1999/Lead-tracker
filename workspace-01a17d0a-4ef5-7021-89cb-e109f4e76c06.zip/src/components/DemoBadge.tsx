import { FlaskConical } from 'lucide-react';
import { appMode } from '@/lib/env';

/**
 * Shown whenever the app is running on synthetic local data. It is deliberately
 * impossible to miss so nobody mistakes demo numbers for production figures.
 */
export function DemoBadge({ className = '' }: { className?: string }) {
  if (appMode !== 'demo') return null;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-bold tracking-wide text-amber-900 uppercase ring-1 ring-amber-300 ring-inset ${className}`}
      title="Demo mode: synthetic sample data stored in this browser. No external integration is connected."
    >
      <FlaskConical className="h-3.5 w-3.5" aria-hidden />
      Demo data
    </span>
  );
}
