import type { LeadOutcome, LeadStatus } from '@/types/domain';
import { OUTCOME_MAP, STATUS_MAP } from '@/lib/constants';

export function StatusChip({ status }: { status: LeadStatus }) {
  const meta = STATUS_MAP[status] ?? STATUS_MAP.not_dialed;
  return (
    <span className={`chip whitespace-nowrap ${meta.chip}`} title={meta.description}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.color }} aria-hidden />
      {meta.label}
    </span>
  );
}

export function OutcomeChip({ outcome }: { outcome: LeadOutcome }) {
  const meta = OUTCOME_MAP[outcome] ?? OUTCOME_MAP.pending;
  return <span className={`chip whitespace-nowrap ${meta.chip}`}>{meta.label}</span>;
}
