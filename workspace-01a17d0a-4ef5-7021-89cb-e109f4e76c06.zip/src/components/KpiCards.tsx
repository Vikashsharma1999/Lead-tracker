import {
  CalendarClock,
  CheckCircle2,
  Clock,
  Link2,
  PhoneCall,
  PhoneOff,
  Users,
  XCircle,
} from 'lucide-react';
import type { DashboardSummary, LeadStatus } from '@/types/domain';
import { KPI_TILES } from '@/lib/constants';
import { kpiValue, percentage } from '@/lib/kpi';
import { TableSkeleton } from './Spinner';

const ICONS = {
  users: Users,
  'phone-off': PhoneOff,
  phone: PhoneCall,
  check: CheckCircle2,
  x: XCircle,
  calendar: CalendarClock,
  link: Link2,
  clock: Clock,
} as const;

interface Props {
  summary: DashboardSummary | undefined;
  loading: boolean;
  activeStatus?: LeadStatus | 'total' | null;
  onSelect?: (key: 'total' | LeadStatus) => void;
}

/**
 * Eight KPI tiles. Every value is derived from records (server aggregation in
 * live mode); nothing is hardcoded. Tiles narrow the table when clicked.
 */
export function KpiCards({ summary, loading, activeStatus, onSelect }: Props) {
  if (loading || !summary) {
    return (
      <div className="card grid grid-cols-2 gap-3 p-4 md:grid-cols-4">
        <TableSkeleton rows={2} cols={3} />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8">
      {KPI_TILES.map((tile) => {
        const Icon = ICONS[tile.icon];
        const value = kpiValue(summary, tile.key);
        const share = tile.key === 'total' ? 100 : percentage(value, summary.totalLeads);
        const active = activeStatus === tile.key;
        const isTotal = tile.key === 'total';
        return (
          <button
            key={tile.key}
            type="button"
            onClick={() => onSelect?.(tile.key)}
            aria-pressed={active}
            className={`group card relative overflow-hidden p-3.5 text-left transition hover:shadow-[var(--shadow-card-hover)] ${
              active ? 'ring-2 ring-forest-500' : ''
            } ${onSelect ? 'cursor-pointer' : 'cursor-default'}`}
          >
            <span
              className={`absolute inset-x-0 top-0 h-[3px] ${isTotal ? 'bg-forest-600' : 'bg-transparent'}`}
              aria-hidden
            />
            <div className="flex items-start justify-between gap-2">
              <p className="min-h-7 text-[11px] leading-tight font-semibold tracking-wide text-navy-500 uppercase">
                {tile.label}
              </p>
              <Icon
                className={`h-4 w-4 shrink-0 ${isTotal ? 'text-forest-600' : tile.accent} opacity-80`}
                aria-hidden
              />
            </div>
            <p
              className={`mt-2 text-2xl font-bold tabular-nums ${isTotal ? 'text-navy-900' : tile.accent}`}
            >
              {value.toLocaleString()}
            </p>
            <p className="mt-0.5 text-[11px] font-medium text-navy-500">
              {isTotal ? 'unique leads' : `${share}% of pipeline`}
            </p>
          </button>
        );
      })}
    </div>
  );
}
