import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import type { DashboardSummary } from '@/types/domain';
import { LEAD_STATUSES } from '@/lib/constants';
import { percentage } from '@/lib/kpi';
import { EmptyState } from './EmptyState';

interface Props {
  summary: DashboardSummary | undefined;
  loading?: boolean;
  onSelectStatus?: (label: string) => void;
}

export function StatusPie({ summary, loading, onSelectStatus }: Props) {
  const data = LEAD_STATUSES.map((status) => ({
    name: status.label,
    value: summary?.byStatus[status.value] ?? 0,
    color: status.color,
  })).filter((d) => d.value > 0);

  const total = summary?.totalLeads ?? 0;

  return (
    <section className="card flex flex-col p-4 sm:p-5" aria-labelledby="status-breakdown-heading">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 id="status-breakdown-heading" className="text-sm font-bold text-navy-900">
            Lead Status Breakdown
          </h2>
          <p className="mt-0.5 text-xs text-navy-500">Each lead is counted once by its current status.</p>
        </div>
        <span className="rounded-lg bg-navy-50 px-2 py-1 text-[11px] font-semibold text-navy-500">
          {total.toLocaleString()} total
        </span>
      </div>

      {loading ? (
        <div className="mt-6 h-48 animate-pulse rounded-xl bg-slate-100" aria-hidden />
      ) : total === 0 ? (
        <EmptyState title="No leads yet" description="Import a spreadsheet or Excel file to populate the pipeline." />
      ) : (
        <div className="mt-4 flex flex-1 flex-col gap-5 lg:flex-row lg:items-center">
          <div className="relative mx-auto h-64 w-full max-w-[300px] shrink-0">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="name"
                  innerRadius="58%"
                  outerRadius="86%"
                  paddingAngle={2}
                  stroke="#ffffff"
                  strokeWidth={2}
                  onClick={(entry) => {
                    const name = (entry as unknown as { name?: string })?.name;
                    if (name) onSelectStatus?.(name);
                  }}
                >
                  {data.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value, name) => [
                    `${Number(value)} (${percentage(Number(value), total)}%)`,
                    String(name),
                  ]}
                  contentStyle={{
                    borderRadius: 12,
                    border: '1px solid #e5e9e7',
                    fontSize: 12,
                    boxShadow: '0 12px 24px -16px rgba(15,39,67,.4)',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-navy-900 tabular-nums">{total.toLocaleString()}</span>
              <span className="text-[10px] font-semibold tracking-wider text-navy-500 uppercase">Leads</span>
            </div>
          </div>

          <ul className="grid flex-1 grid-cols-1 gap-x-4 gap-y-1 sm:grid-cols-2 lg:grid-cols-1">
            {LEAD_STATUSES.map((status) => {
              const value = summary?.byStatus[status.value] ?? 0;
              return (
                <li key={status.value}>
                  <button
                    type="button"
                    onClick={() => onSelectStatus?.(status.label)}
                    className="flex w-full items-center justify-between gap-2 rounded-lg px-1.5 py-1.5 text-left hover:bg-navy-50"
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <span
                        className="h-2.5 w-2.5 shrink-0 rounded-sm"
                        style={{ backgroundColor: status.color }}
                        aria-hidden
                      />
                      <span className="truncate text-xs font-medium text-navy-700">{status.label}</span>
                    </span>
                    <span className="shrink-0 text-xs font-semibold text-navy-900 tabular-nums">
                      {value}
                      <span className="ml-1 text-[10px] font-medium text-navy-500">
                        {percentage(value, total)}%
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </section>
  );
}
