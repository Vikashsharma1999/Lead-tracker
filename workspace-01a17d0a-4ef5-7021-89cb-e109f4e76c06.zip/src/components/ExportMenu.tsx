import { Download, FileSpreadsheet, FileText } from 'lucide-react';
import { useState } from 'react';

interface Props {
  onExportExcel: () => void;
  onExportCsv: () => void;
  disabled?: boolean;
  label?: string;
}

export function ExportMenu({ onExportExcel, onExportCsv, disabled, label = 'Export' }: Props) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        type="button"
        className="btn-secondary"
        onClick={() => setOpen((v) => !v)}
        disabled={disabled}
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <Download className="h-4 w-4" aria-hidden />
        {label}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setOpen(false)} aria-hidden />
          <div
            role="menu"
            className="absolute right-0 z-30 mt-2 w-52 overflow-hidden rounded-xl border border-[var(--color-hairline)] bg-white py-1 shadow-xl"
          >
            <button
              type="button"
              role="menuitem"
              className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm text-navy-800 hover:bg-navy-50"
              onClick={() => {
                onExportExcel();
                setOpen(false);
              }}
            >
              <FileSpreadsheet className="h-4 w-4 text-emerald-600" aria-hidden />
              Excel (.xlsx)
            </button>
            <button
              type="button"
              role="menuitem"
              className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm text-navy-800 hover:bg-navy-50"
              onClick={() => {
                onExportCsv();
                setOpen(false);
              }}
            >
              <FileText className="h-4 w-4 text-navy-500" aria-hidden />
              CSV (.csv)
            </button>
            <p className="border-t border-[var(--color-hairline)] px-3 pt-2 pb-1 text-[10px] leading-relaxed text-navy-500">
              Exports respect the active filters and your role's visibility.
            </p>
          </div>
        </>
      )}
    </div>
  );
}
