import { ArrowDown, ArrowUp, ArrowUpDown } from 'lucide-react';
import type { SortField, SortSpec } from '@/types/domain';

interface Props {
  field: SortField;
  label: string;
  sort: SortSpec;
  onSort: (field: SortField) => void;
  className?: string;
}

export function SortHeader({ field, label, sort, onSort, className = '' }: Props) {
  const active = sort.field === field;
  const Icon = !active ? ArrowUpDown : sort.direction === 'asc' ? ArrowUp : ArrowDown;
  return (
    <th scope="col" className={`table-header sticky top-0 z-10 px-3 py-2.5 text-left ${className}`}>
      <button
        type="button"
        onClick={() => onSort(field)}
        className="inline-flex items-center gap-1.5 rounded text-[11px] font-semibold tracking-wider uppercase hover:text-forest-700"
        aria-sort={active ? (sort.direction === 'asc' ? 'ascending' : 'descending') : 'none'}
      >
        {label}
        <Icon className={`h-3 w-3 ${active ? 'text-forest-600' : 'text-slate-400'}`} aria-hidden />
      </button>
    </th>
  );
}
