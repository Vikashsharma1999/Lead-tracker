import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertOctagon } from 'lucide-react';

interface State {
  error: Error | null;
}

/**
 * Catches render errors so a single bad record cannot blank the dashboard.
 * Messages are intentionally generic: no internal details leak to the UI.
 */
export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    // Replace with your monitoring sink (Sentry, etc.) in production.
    console.error('[lead-tracker] render error', error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="flex min-h-full items-center justify-center bg-canvas p-6">
          <div className="card max-w-md p-6 text-center">
            <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-50 text-red-600">
              <AlertOctagon className="h-6 w-6" aria-hidden />
            </span>
            <h1 className="mt-3 text-lg font-bold text-navy-900">Something went wrong</h1>
            <p className="mt-1 text-sm text-navy-500">
              The dashboard hit an unexpected error. Your data was not modified. Reload to continue.
            </p>
            <button type="button" className="btn-primary mt-4" onClick={() => window.location.reload()}>
              Reload dashboard
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
