import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  BarChart3,
  Database,
  FileClock,
  LayoutDashboard,
  UploadCloud,
  ListChecks,
  LogOut,
  Menu,
  Settings,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { can, type Permission } from '@/lib/permissions';
import { ROLE_LABELS } from '@/lib/constants';
import { initials } from '@/lib/format';
import { DemoBadge } from './DemoBadge';
import { OfflineIndicator } from './OfflineIndicator';

interface NavItem {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  permission?: Permission;
  end?: boolean;
}

const NAV: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/leads', label: 'Leads', icon: ListChecks },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
  { to: '/import', label: 'Import data', icon: UploadCloud, permission: 'leads.import' },
  { to: '/sources', label: 'Data Sources', icon: Database, permission: 'sources.manage' },
  { to: '/users', label: 'Callers & Access', icon: Users, permission: 'users.manage' },
  { to: '/audit', label: 'Audit History', icon: FileClock, permission: 'audit.view' },
  { to: '/settings', label: 'Settings', icon: Settings, permission: 'settings.manage' },
];

function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/20 ring-inset">
        <ShieldCheck className="h-5 w-5 text-forest-100" aria-hidden />
      </span>
      <span className="leading-tight">
        <span className="block text-sm font-bold text-white">Lead Tracker</span>
        <span className="block text-[11px] font-medium tracking-wide text-forest-200/80 uppercase">
          Call operations
        </span>
      </span>
    </div>
  );
}

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const { profile } = useAuth();
  return (
    <nav className="flex flex-1 flex-col gap-1 px-3" aria-label="Main navigation">
      {NAV.filter((item) => !item.permission || can(profile?.role, item.permission)).map((item) => {
        const Icon = item.icon;
        return (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${
                isActive
                  ? 'bg-white/12 text-white ring-1 ring-white/15 ring-inset'
                  : 'text-forest-100/75 hover:bg-white/8 hover:text-white'
              }`
            }
          >
            <Icon className="h-4.5 w-4.5" aria-hidden />
            {item.label}
          </NavLink>
        );
      })}
    </nav>
  );
}

function UserCard({ compact = false }: { compact?: boolean }) {
  const { profile, signOut, mode } = useAuth();
  if (!profile) return null;
  return (
    <div className={compact ? 'px-3 py-3' : 'border-t border-white/10 px-3 py-3'}>
      <div className="flex items-center gap-2.5 rounded-xl bg-white/5 p-2.5 ring-1 ring-white/10 ring-inset">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-forest-500 text-xs font-bold text-white">
          {initials(profile.full_name)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{profile.full_name}</p>
          <p className="truncate text-[11px] text-forest-200/80">{ROLE_LABELS[profile.role]}</p>
        </div>
        <button
          type="button"
          onClick={() => void signOut()}
          className="rounded-lg p-1.5 text-forest-200 hover:bg-white/10 hover:text-white"
          title="Sign out"
          aria-label="Sign out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
      {mode === 'demo' && (
        <p className="mt-2 px-1 text-[10px] leading-relaxed text-forest-200/70">
          Demo session — synthetic data in this browser only.
        </p>
      )}
    </div>
  );
}

export function AppShell() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => setMobileOpen(false), [location.pathname]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMobileOpen(false);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="flex min-h-full bg-canvas">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col bg-forest-900 lg:flex">
        <div className="px-5 py-5">
          <Brand />
        </div>
        <NavList />
        <UserCard />
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy-900/50" onClick={() => setMobileOpen(false)} aria-hidden />
          <div className="animate-in-up relative flex h-full w-72 max-w-[85vw] flex-col bg-forest-900">
            <div className="flex items-center justify-between px-5 py-4">
              <Brand />
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="rounded-lg p-1.5 text-forest-100 hover:bg-white/10"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <NavList onNavigate={() => setMobileOpen(false)} />
            <UserCard />
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobile top bar */}
        <div className="flex items-center justify-between gap-3 border-b border-[var(--color-hairline)] bg-forest-800 px-4 py-3 lg:hidden">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="rounded-lg p-1.5 text-white hover:bg-white/10"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <span className="text-sm font-bold text-white">Lead Tracker Dashboard</span>
          <DemoBadge />
        </div>

        <main className="mx-auto w-full max-w-[1560px] flex-1 px-3 py-4 sm:px-5 sm:py-6">
          <div className="mb-3">
            <OfflineIndicator />
          </div>
          <Outlet />
        </main>

        <footer className="mx-auto w-full max-w-[1560px] px-4 pb-6 text-[11px] leading-relaxed text-navy-500">
          Lead Tracker Dashboard · Records are protected by Postgres Row Level Security. Integration
          status is always reported from the server, never assumed.
        </footer>
      </div>
    </div>
  );
}
