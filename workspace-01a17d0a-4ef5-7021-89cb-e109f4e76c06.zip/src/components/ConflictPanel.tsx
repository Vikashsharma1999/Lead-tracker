import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { GitCompareArrows, ShieldQuestion } from 'lucide-react';
import { getRepository } from '@/data';
import { formatDateTime } from '@/lib/format';
import { useToast } from '@/hooks/useToasts';
import { EmptyState } from './EmptyState';

/**
 * Administrator conflict resolution.
 *
 * A conflict is recorded whenever a stale edit (offline queue or a second
 * browser tab) would overwrite a newer server value. Nothing is merged
 * automatically — an admin chooses which side wins, and the choice is audited.
 */
export function ConflictPanel() {
  const queryClient = useQueryClient();
  const { push } = useToast();

  const conflictsQuery = useQuery({
    queryKey: ['conflicts'],
    queryFn: () => getRepository().listConflicts(),
    staleTime: 15_000,
  });

  const resolve = useMutation({
    mutationFn: ({ id, resolution }: { id: string; resolution: 'resolved_local' | 'resolved_server' | 'dismissed' }) =>
      getRepository().resolveConflict(id, resolution),
    onSuccess: () => {
      push({ variant: 'success', title: 'Conflict resolved', description: 'The decision was written to the audit log.' });
      void queryClient.invalidateQueries({ queryKey: ['conflicts'] });
      void queryClient.invalidateQueries({ queryKey: ['leads'] });
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Could not resolve the conflict', description: error.message }),
  });

  const conflicts = conflictsQuery.data ?? [];

  return (
    <section className="card overflow-hidden" aria-labelledby="conflicts-heading">
      <div className="flex items-start justify-between gap-3 px-4 py-3">
        <div>
          <h2 id="conflicts-heading" className="flex items-center gap-2 text-sm font-bold text-navy-900">
            <GitCompareArrows className="h-4 w-4 text-amber-600" aria-hidden />
            Sync conflicts
          </h2>
          <p className="mt-0.5 text-xs text-navy-500">
            Edits that would have overwritten a newer value. Nothing is merged until you choose.
          </p>
        </div>
        <span
          className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
            conflicts.length ? 'bg-amber-50 text-amber-800' : 'bg-navy-50 text-navy-500'
          }`}
        >
          {conflicts.length} open
        </span>
      </div>

      {conflicts.length === 0 ? (
        <EmptyState
          icon={<ShieldQuestion className="h-6 w-6" />}
          title="No open conflicts"
          description="Conflicts appear here when an offline edit or a second editor touches the same field."
        />
      ) : (
        <ul className="divide-y divide-[var(--color-hairline)]">
          {conflicts.map((conflict) => (
            <li key={conflict.id} className="px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs font-semibold text-navy-900">
                  Field <code className="rounded bg-navy-50 px-1.5 py-0.5">{conflict.field}</code>
                  <span className="ml-2 font-normal text-navy-500">{formatDateTime(conflict.created_at)}</span>
                </p>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    className="btn-secondary py-1 text-[11px]"
                    disabled={resolve.isPending}
                    onClick={() => resolve.mutate({ id: conflict.id, resolution: 'resolved_local' })}
                  >
                    Keep local
                  </button>
                  <button
                    type="button"
                    className="btn-secondary py-1 text-[11px]"
                    disabled={resolve.isPending}
                    onClick={() => resolve.mutate({ id: conflict.id, resolution: 'resolved_server' })}
                  >
                    Keep server
                  </button>
                  <button
                    type="button"
                    className="btn-ghost py-1 text-[11px]"
                    disabled={resolve.isPending}
                    onClick={() => resolve.mutate({ id: conflict.id, resolution: 'dismissed' })}
                  >
                    Dismiss
                  </button>
                </div>
              </div>
              <dl className="mt-2 grid grid-cols-1 gap-2 text-[11px] sm:grid-cols-2">
                <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-2">
                  <dt className="font-semibold text-amber-900">Local (your edit)</dt>
                  <dd className="mt-0.5 break-words text-amber-900/80">{conflict.local_value ?? '—'}</dd>
                </div>
                <div className="rounded-lg border border-navy-100 bg-navy-50/60 p-2">
                  <dt className="font-semibold text-navy-800">Server (current value)</dt>
                  <dd className="mt-0.5 break-words text-navy-700">{conflict.server_value ?? '—'}</dd>
                </div>
              </dl>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
