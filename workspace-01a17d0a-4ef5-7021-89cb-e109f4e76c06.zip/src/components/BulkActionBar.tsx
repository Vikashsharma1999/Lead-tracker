import { Download, Trash2, UserCheck, X } from 'lucide-react';
import { useState } from 'react';
import type { LeadStatus, Profile } from '@/types/domain';
import { LEAD_STATUSES } from '@/lib/constants';

interface Props {
  count: number;
  profiles: Profile[];
  onClear: () => void;
  onAssign: (callerId: string | null) => void;
  onStatusChange: (status: LeadStatus) => void;
  onExport: () => void;
  onDelete: () => void;
  busy?: boolean;
}

/** Admin-only bulk toolbar; the server enforces the same restrictions. */
export function BulkActionBar({
  count,
  profiles,
  onClear,
  onAssign,
  onStatusChange,
  onExport,
  onDelete,
  busy,
}: Props) {
  const [status, setStatus] = useState<LeadStatus | ''>('');
  const [caller, setCaller] = useState<string>('');

  if (count === 0) return null;

  return (
    <div className="safe-bottom sticky bottom-3 z-30 mx-3 mb-3 rounded-xl border border-forest-200 bg-forest-800 px-3 py-2.5 text-white shadow-xl sm:mx-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="mr-1 inline-flex items-center gap-2 text-sm font-semibold">
          <span className="rounded-md bg-white/15 px-2 py-0.5 text-xs font-bold">{count}</span>
          selected
        </span>

        <select
          className="rounded-lg border border-white/20 bg-forest-900 px-2 py-1.5 text-xs font-semibold text-white"
          value={caller}
          onChange={(event) => {
            setCaller(event.target.value);
            if (event.target.value) onAssign(event.target.value === 'unassigned' ? null : event.target.value);
            setCaller('');
          }}
          aria-label="Assign selected leads to a caller"
        >
          <option value="">Assign to…</option>
          <option value="unassigned">Unassign</option>
          {profiles
            .filter((p) => p.role === 'caller' && p.active)
            .map((p) => (
              <option key={p.id} value={p.id}>
                {p.full_name}
              </option>
            ))}
        </select>

        <select
          className="rounded-lg border border-white/20 bg-forest-900 px-2 py-1.5 text-xs font-semibold text-white"
          value={status}
          onChange={(event) => {
            const value = event.target.value as LeadStatus | '';
            setStatus(value);
            if (value) onStatusChange(value);
            setStatus('');
          }}
          aria-label="Change status of selected leads"
        >
          <option value="">Set status…</option>
          {LEAD_STATUSES.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>

        <button type="button" onClick={onExport} className="btn-light text-xs" disabled={busy}>
          <Download className="h-3.5 w-3.5" /> Export selected
        </button>
        <button type="button" onClick={onDelete} className="btn-light text-xs text-red-100" disabled={busy}>
          <Trash2 className="h-3.5 w-3.5" /> Delete
        </button>

        <button
          type="button"
          onClick={onClear}
          className="ml-auto rounded-lg p-1.5 text-white/70 hover:bg-white/10 hover:text-white"
          aria-label="Clear selection"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
      <p className="mt-1.5 flex items-center gap-1.5 text-[10px] text-forest-100/70">
        <UserCheck className="h-3 w-3" aria-hidden /> Assignments and status changes are recorded in the audit log.
      </p>
    </div>
  );
}
