import { ChevronLeft, ChevronRight } from 'lucide-react';
import { PAGE_SIZE_OPTIONS } from '@/lib/constants';

interface Props {
  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}

export function Pagination({ page, pageSize, total, onPageChange, onPageSizeChange }: Props) {
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);

  const pages: (number | '…')[] = [];
  const push = (value: number | '…') => pages.push(value);
  if (pageCount <= 7) {
    for (let i = 1; i <= pageCount; i += 1) push(i);
  } else {
    push(1);
    if (page > 3) push('…');
    for (let i = Math.max(2, page - 1); i <= Math.min(pageCount - 1, page + 1); i += 1) push(i);
    if (page < pageCount - 2) push('…');
    push(pageCount);
  }

  return (
    <div className="flex flex-col gap-2 border-t border-[var(--color-hairline)] px-3 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-2 text-xs text-navy-500">
        <span>
          {from.toLocaleString()}–{to.toLocaleString()} of {total.toLocaleString()}
        </span>
        <label className="ml-2 flex items-center gap-1.5">
          <span className="sr-only">Rows per page</span>
          <select
            className="rounded-lg border border-[var(--color-hairline)] bg-white px-1.5 py-1 text-xs font-semibold"
            value={pageSize}
            onChange={(event) => onPageSizeChange(Number(event.target.value))}
          >
            {PAGE_SIZE_OPTIONS.map((size) => (
              <option key={size} value={size}>
                {size} / page
              </option>
            ))}
          </select>
        </label>
      </div>

      <nav className="flex items-center gap-1" aria-label="Pagination">
        <button
          type="button"
          className="btn-secondary px-2 py-1.5"
          onClick={() => onPageChange(page - 1)}
          disabled={page <= 1}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        {pages.map((value, index) =>
          value === '…' ? (
            <span key={`gap-${index}`} className="px-1 text-xs text-navy-500">
              …
            </span>
          ) : (
            <button
              key={value}
              type="button"
              onClick={() => onPageChange(value)}
              aria-current={value === page ? 'page' : undefined}
              className={`min-w-8 rounded-lg px-2 py-1.5 text-xs font-semibold ${
                value === page ? 'bg-forest-700 text-white' : 'text-navy-700 hover:bg-navy-50'
              }`}
            >
              {value}
            </button>
          ),
        )}
        <button
          type="button"
          className="btn-secondary px-2 py-1.5"
          onClick={() => onPageChange(page + 1)}
          disabled={page >= pageCount}
          aria-label="Next page"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </nav>
    </div>
  );
}
