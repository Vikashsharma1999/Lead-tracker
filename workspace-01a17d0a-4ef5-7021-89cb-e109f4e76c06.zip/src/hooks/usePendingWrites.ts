import { useCallback, useEffect, useState } from 'react';
import { listQueuedWrites, type QueuedWrite } from '@/lib/offline/db';
import { useAuth } from './useAuth';

/** Reads the offline queue for the signed-in user (scoped, never global). */
export function usePendingWrites() {
  const { profile } = useAuth();
  const [writes, setWrites] = useState<QueuedWrite[]>([]);

  const refresh = useCallback(async () => {
    if (!profile) {
      setWrites([]);
      return;
    }
    try {
      setWrites(await listQueuedWrites(profile.id));
    } catch {
      setWrites([]);
    }
  }, [profile]);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => void refresh(), 6000);
    window.addEventListener('online', () => void refresh());
    return () => window.clearInterval(timer);
  }, [refresh]);

  return { writes, count: writes.length, refresh };
}
