import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Profile } from '@/types/domain';
import { getRepository } from '@/data';
import { appMode } from '@/lib/env';
import { clearUserOfflineData } from '@/lib/offline/db';

interface AuthContextValue {
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  mode: 'live' | 'demo';
  signIn: (email: string, password: string) => Promise<Profile>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const repository = getRepository();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    repository
      .getProfile()
      .then((p) => {
        if (!cancelled) setProfile(p);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Could not restore session');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    const unsubscribe = repository.onAuthChange((p) => {
      if (!cancelled) {
        setProfile(p);
        setLoading(false);
      }
    });
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, [repository]);

  const signIn = useCallback(
    async (email: string, password: string) => {
      setError(null);
      const p = await repository.signIn(email, password);
      setProfile(p);
      return p;
    },
    [repository],
  );

  const signOut = useCallback(async () => {
    // Never leave one user's queued customer data on a shared device.
    if (profile) {
      try {
        await clearUserOfflineData(profile.id);
      } catch {
        /* IndexedDB unavailable — nothing cached to clear */
      }
    }
    await repository.signOut();
    setProfile(null);
  }, [profile, repository]);

  const refreshProfile = useCallback(async () => {
    const p = await repository.getProfile();
    setProfile(p);
  }, [repository]);

  const value = useMemo<AuthContextValue>(
    () => ({ profile, loading, error, mode: appMode, signIn, signOut, refreshProfile }),
    [profile, loading, error, signIn, signOut, refreshProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
