import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { getRepository } from '@/data';
import type { LeadPatch, ReportFilters, CallActivityInput } from '@/data/repository';
import type { Lead, LeadFilters, LeadStatus, PageRequest } from '@/types/domain';
import { useAuth } from './useAuth';
import { useOnline } from './useOnline';
import { useToast } from './useToasts';
import { queueCallActivity, queueLeadUpdate } from '@/lib/offline/queue';

const repo = () => getRepository();

export const queryKeys = {
  summary: (filters?: { dateFrom?: string; dateTo?: string }) => ['summary', filters ?? {}] as const,
  leads: (filters: LeadFilters, page: PageRequest) => ['leads', filters, page] as const,
  lead: (id: string) => ['lead', id] as const,
  activities: (leadId: string) => ['activities', leadId] as const,
  profiles: ['profiles'] as const,
  sources: ['sources'] as const,
  jobs: (sourceId?: string) => ['sync-jobs', sourceId ?? 'all'] as const,
  report: (filters: ReportFilters) => ['report', filters] as const,
  audit: ['audit'] as const,
};

export function useLeads(filters: LeadFilters, page: PageRequest) {
  return useQuery({
    queryKey: queryKeys.leads(filters, page),
    queryFn: () => repo().listLeads(filters, page),
    placeholderData: (prev) => prev,
    staleTime: 15_000,
  });
}

export function useSummary(filters: { dateFrom?: string; dateTo?: string } = {}) {
  return useQuery({
    queryKey: queryKeys.summary(filters),
    queryFn: () => repo().getSummary(filters),
    staleTime: 20_000,
  });
}

export function useReport(filters: ReportFilters) {
  return useQuery({
    queryKey: queryKeys.report(filters),
    queryFn: () => repo().getReport(filters),
    staleTime: 30_000,
  });
}

export function useProfiles() {
  return useQuery({ queryKey: queryKeys.profiles, queryFn: () => repo().listProfiles(), staleTime: 60_000 });
}

export function useSources() {
  return useQuery({ queryKey: queryKeys.sources, queryFn: () => repo().listSources(), staleTime: 30_000 });
}

export function useSyncJobs(sourceId?: string) {
  return useQuery({
    queryKey: queryKeys.jobs(sourceId),
    queryFn: () => repo().listSyncJobs(sourceId),
    staleTime: 15_000,
  });
}

export function useAuditLogs() {
  return useQuery({ queryKey: queryKeys.audit, queryFn: () => repo().listAuditLogs(100), staleTime: 30_000 });
}

export function useLeadActivities(leadId: string | null) {
  return useQuery({
    queryKey: queryKeys.activities(leadId ?? ''),
    queryFn: () => repo().listCallActivities(leadId as string),
    enabled: Boolean(leadId),
  });
}

/** Invalidates everything affected by a lead write. */
function useInvalidateLeadData() {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: ['leads'] });
    void qc.invalidateQueries({ queryKey: ['summary'] });
    void qc.invalidateQueries({ queryKey: ['report'] });
    void qc.invalidateQueries({ queryKey: ['activities'] });
    void qc.invalidateQueries({ queryKey: ['audit'] });
  };
}

export interface UpdateLeadVariables {
  lead: Lead;
  patch: LeadPatch;
  label?: string;
}

export function useUpdateLead() {
  const { profile } = useAuth();
  const online = useOnline();
  const invalidate = useInvalidateLeadData();
  const { push } = useToast();
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({ lead, patch, label }: UpdateLeadVariables) => {
      if (!online && profile) {
        await queueLeadUpdate(
          { repository: repo(), userId: profile.id, role: profile.role },
          lead,
          patch,
          label ?? `Update ${lead.name}`,
        );
        return { queued: true as const };
      }
      try {
        const result = await repo().updateLead(lead.id, patch, lead.version);
        return { queued: false as const, result };
      } catch (error) {
        // Network hiccup: keep the user's work in the offline queue instead of
        // losing it, and be explicit that it has NOT reached the server.
        if (profile && /fetch|network|timeout|failed to fetch/i.test(String(error))) {
          await queueLeadUpdate(
            { repository: repo(), userId: profile.id, role: profile.role },
            lead,
            patch,
            label ?? `Update ${lead.name}`,
          );
          return { queued: true as const };
        }
        throw error;
      }
    },
    onSuccess: (data, variables) => {
      if (data.queued) {
        push({
          variant: 'warning',
          title: 'Saved on this device only',
          description: 'You are offline. This change will sync when the connection returns.',
        });
      } else if (data.result?.conflict) {
        push({
          variant: 'error',
          title: 'Update blocked by a conflict',
          description: `${data.result.conflict.field} was changed elsewhere (server value: ${String(
            data.result.conflict.serverValue,
          )}). Nothing was overwritten.`,
        });
        void qc.invalidateQueries({ queryKey: queryKeys.lead(variables.lead.id) });
      } else {
        push({ variant: 'success', title: 'Lead updated', description: variables.lead.name });
      }
      invalidate();
    },
    onError: (error: Error) => {
      push({ variant: 'error', title: 'Update failed', description: error.message });
    },
  });
}

export function useLogCall() {
  const { profile } = useAuth();
  const online = useOnline();
  const invalidate = useInvalidateLeadData();
  const { push } = useToast();

  return useMutation({
    mutationFn: async (input: CallActivityInput & { leadName: string; leadVersion?: number }) => {
      if (!online && profile) {
        await queueCallActivity(
          { repository: repo(), userId: profile.id, role: profile.role },
          {
            leadId: input.lead_id,
            outcome: input.outcome,
            notes: input.notes,
            callTime: input.call_time ?? new Date().toISOString(),
            leadStatus: input.updateLead?.lead_status,
            nextFollowUpAt: input.updateLead?.next_follow_up_at ?? null,
          },
          `Call log — ${input.leadName}`,
        );
        return { queued: true as const };
      }
      await repo().addCallActivity(input);
      return { queued: false as const };
    },
    onSuccess: (data) => {
      push(
        data.queued
          ? {
              variant: 'warning',
              title: 'Call queued offline',
              description: 'It will be logged on the server when you are back online.',
            }
          : { variant: 'success', title: 'Call activity logged' },
      );
      invalidate();
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Could not log call', description: error.message }),
  });
}

export function useBulkAssign() {
  const invalidate = useInvalidateLeadData();
  const { push } = useToast();
  return useMutation({
    mutationFn: ({ leadIds, callerId }: { leadIds: string[]; callerId: string | null }) =>
      repo().bulkAssign(leadIds, callerId),
    onSuccess: (count) => {
      push({ variant: 'success', title: 'Leads reassigned', description: `${count} lead(s) updated.` });
      invalidate();
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Assignment failed', description: error.message }),
  });
}

export function useBulkStatus() {
  const invalidate = useInvalidateLeadData();
  const { push } = useToast();
  return useMutation({
    mutationFn: ({ leadIds, status }: { leadIds: string[]; status: LeadStatus }) =>
      repo().bulkSetStatus(leadIds, status),
    onSuccess: (count) => {
      push({ variant: 'success', title: 'Statuses updated', description: `${count} lead(s) changed.` });
      invalidate();
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Bulk update failed', description: error.message }),
  });
}

export function useDeleteLeads() {
  const invalidate = useInvalidateLeadData();
  const { push } = useToast();
  return useMutation({
    mutationFn: (leadIds: string[]) => repo().deleteLeads(leadIds),
    onSuccess: (count) => {
      push({ variant: 'success', title: 'Leads deleted', description: `${count} record(s) removed.` });
      invalidate();
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Delete failed', description: error.message }),
  });
}
