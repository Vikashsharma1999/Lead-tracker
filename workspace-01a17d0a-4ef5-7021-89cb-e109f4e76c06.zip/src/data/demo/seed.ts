import type {
  AuditLog,
  CallActivity,
  DashboardSummary,
  DataSource,
  Lead,
  LeadOutcome,
  LeadStatus,
  Profile,
  SyncJob,
} from '@/types/domain';
import { LEAD_STATUSES } from '@/lib/constants';
import { computeSummary } from '@/lib/kpi';

/**
 * Deterministic synthetic dataset for development, demos and tests.
 * No real customer data is used. All names/phones/emails are invented.
 */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const FIRST = [
  'Aarav', 'Meera', 'Rahul', 'Sana', 'Daniel', 'Fatima', 'Arjun', 'Leila', 'Omar', 'Priya',
  'Karan', 'Nadia', 'Ethan', 'Zara', 'Vikram', 'Hana', 'Joseph', 'Tanya', 'Rashid', 'Isha',
  'Marcus', 'Divya', 'Imran', 'Elena', 'Nikhil', 'Amira', 'Sanjay', 'Grace', 'Yusuf', 'Ananya',
];
const LAST = [
  'Sharma', 'Iyer', 'Menon', 'Khan', 'Fernandes', 'Ali', 'Patel', 'Haddad', 'Rahman', 'Nair',
  'Kapoor', 'Siddiqui', 'Brown', 'Ahmed', 'Rao', 'Tanaka', 'D’Souza', 'Verma', 'Hussain', 'Bose',
];

const SOURCE_DEFS: { id: string; name: string; sheet: string }[] = [
  { id: 'src-webinar-q3', name: 'Q3 Webinar Registrations', sheet: 'Registrations' },
  { id: 'src-ads-oct', name: 'October Meta Ads', sheet: 'Sheet1' },
  { id: 'src-partner', name: 'Partner Referrals', sheet: 'Referrals' },
];

const CALLERS: { id: string; full_name: string; email: string; active: boolean }[] = [
  { id: 'usr-caller-1', full_name: 'Rahul Menon', email: 'rahul.caller@example.com', active: true },
  { id: 'usr-caller-2', full_name: 'Sana Ali', email: 'sana.caller@example.com', active: true },
  { id: 'usr-caller-3', full_name: 'David Fernandes', email: 'david.caller@example.com', active: true },
  { id: 'usr-caller-4', full_name: 'Priya Nair', email: 'priya.caller@example.com', active: false },
];

/** Weighted status distribution so the dashboard looks like a real pipeline. */
const STATUS_WEIGHTS: { status: LeadStatus; weight: number }[] = [
  { status: 'not_dialed', weight: 22 },
  { status: 'dialed', weight: 8 },
  { status: 'interested', weight: 16 },
  { status: 'not_interested', weight: 14 },
  { status: 'call_back', weight: 12 },
  { status: 'webinar_link_shared', weight: 9 },
  { status: 'follow_up_pending', weight: 8 },
  { status: 'bad_timing', weight: 4 },
  { status: 'switched_off', weight: 4 },
  { status: 'no_answer', weight: 5 },
];

const OUTCOME_BY_STATUS: Partial<Record<LeadStatus, LeadOutcome>> = {
  not_dialed: 'pending',
  dialed: 'neutral',
  interested: 'positive',
  not_interested: 'negative',
  call_back: 'neutral',
  webinar_link_shared: 'positive',
  follow_up_pending: 'neutral',
  bad_timing: 'neutral',
  switched_off: 'pending',
  no_answer: 'pending',
};

const NOTES = [
  'Asked for the pricing deck; follow up with the webinar recording.',
  'Prefers a call after 6pm GST.',
  'Wrong number — requested removal.',
  'Very interested, wants a demo next week.',
  'Currently evaluating two vendors.',
  'Shared webinar link on WhatsApp.',
  'Asked to call back after the weekend.',
  'Budget approval expected end of month.',
  'Not the decision maker — referred to operations head.',
  '',
  '',
  'Left a voicemail, no callback yet.',
];

function iso(daysAgo: number, hour = 10, minute = 0): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
}

export interface DemoDataset {
  profiles: Profile[];
  leads: Lead[];
  activities: CallActivity[];
  sources: DataSource[];
  jobs: SyncJob[];
  audit: AuditLog[];
}

export const DEMO_USERS = [
  {
    email: 'admin@demo.leadtracker.app',
    password: 'AdminDemo123!',
    profileId: 'usr-admin-1',
    role: 'admin' as const,
  },
  {
    email: 'rahul.caller@example.com',
    password: 'CallerDemo123!',
    profileId: 'usr-caller-1',
    role: 'caller' as const,
  },
  {
    email: 'sana.caller@example.com',
    password: 'CallerDemo123!',
    profileId: 'usr-caller-2',
    role: 'caller' as const,
  },
];

export function buildDemoDataset(now = new Date()): DemoDataset {
  const rand = mulberry32(20261023);
  const pick = <T,>(arr: T[]): T => arr[Math.floor(rand() * arr.length)];

  const profiles: Profile[] = [
    {
      id: 'usr-admin-1',
      full_name: 'Ayesha Khan',
      email: 'admin@demo.leadtracker.app',
      role: 'admin',
      active: true,
      created_at: iso(120),
    },
    ...CALLERS.map((c, i) => ({
      id: c.id,
      full_name: c.full_name,
      email: c.email,
      role: 'caller' as const,
      active: c.active,
      created_at: iso(110 - i * 7),
    })),
  ];

  const totalWeight = STATUS_WEIGHTS.reduce((sum, s) => sum + s.weight, 0);
  const leadCount = 84;
  const leads: Lead[] = [];
  const activities: CallActivity[] = [];

  for (let i = 0; i < leadCount; i += 1) {
    const first = pick(FIRST);
    const last = pick(LAST);
    const source = SOURCE_DEFS[i % SOURCE_DEFS.length];
    const createdDaysAgo = Math.floor(rand() * 28);
    const created = new Date(now.getTime() - createdDaysAgo * 86_400_000);

    let roll = rand() * totalWeight;
    let status: LeadStatus = 'not_dialed';
    for (const s of STATUS_WEIGHTS) {
      roll -= s.weight;
      if (roll <= 0) {
        status = s.status;
        break;
      }
    }

    const assigned =
      status === 'not_dialed' && rand() < 0.55
        ? null
        : rand() < 0.08
          ? null
          : pick(CALLERS.filter((c) => c.active)).id;

    const wasCalled = status !== 'not_dialed';
    const lastCallAt = wasCalled
      ? new Date(created.getTime() + Math.floor(rand() * 5 + 1) * 3_600_000).toISOString()
      : null;

    let nextFollowUp: string | null = null;
    if (status === 'call_back' || status === 'follow_up_pending') {
      const offsetDays = Math.floor(rand() * 7) - 2; // some overdue, some upcoming
      const d = new Date(now);
      d.setDate(d.getDate() + offsetDays);
      d.setHours(11 + Math.floor(rand() * 7), rand() < 0.5 ? 0 : 30, 0, 0);
      nextFollowUp = d.toISOString();
    }

    const id = `lead-${String(i + 1).padStart(4, '0')}`;
    const updated =
      nextFollowUp && lastCallAt
        ? new Date(Math.max(new Date(lastCallAt).getTime(), new Date(nextFollowUp).getTime())).toISOString()
        : (lastCallAt ?? created.toISOString());

    leads.push({
      id,
      source_id: source.id,
      source_external_id: `demo-${source.id}`,
      source_sheet_name: source.sheet,
      source_record_id: `row-${i + 2}`,
      name: `${first} ${last}`,
      phone: `+9715${Math.floor(10000000 + rand() * 89999999)}`,
      email: rand() < 0.85 ? `${first.toLowerCase()}.${last.toLowerCase().replace(/[^a-z]/g, '')}@example.com` : null,
      lead_status: status,
      lead_outcome: OUTCOME_BY_STATUS[status] ?? 'pending',
      assigned_to: assigned,
      last_call_at: lastCallAt,
      next_follow_up_at: nextFollowUp,
      notes: NOTES[Math.floor(rand() * NOTES.length)] || null,
      created_at: created.toISOString(),
      updated_at: updated,
      version: 1,
    });

    if (wasCalled) {
      const callCount = 1 + Math.floor(rand() * 2);
      for (let c = 0; c < callCount; c += 1) {
        const t = new Date(
          new Date(lastCallAt!).getTime() - c * (12 + Math.floor(rand() * 20)) * 3_600_000,
        );
        activities.push({
          id: `call-${id}-${c + 1}`,
          lead_id: id,
          caller_id: assigned ?? 'usr-caller-1',
          call_time: t.toISOString(),
          outcome: OUTCOME_BY_STATUS[status] ?? 'neutral',
          notes: c === 0 ? 'Outcome captured during latest dial.' : 'Previous attempt.',
          created_at: t.toISOString(),
        });
      }
    }
  }

  const sources: DataSource[] = [
    ...SOURCE_DEFS.map((s, i) => ({
      id: s.id,
      name: s.name,
      source_type: 'google_sheets' as const,
      // Demo mode never reports a live connection.
      connection_status: 'not_configured' as const,
      sync_mode: 'manual' as const,
      sync_interval_seconds: 60,
      last_sync_at: null,
      last_success_at: null,
      last_error: null,
      configuration: {
        demo: true,
        spreadsheet_id: null,
        worksheet: s.sheet,
        note: 'Sample source. Connect Google Sheets with real OAuth credentials to sync.',
      },
      created_at: iso(60 - i * 5),
    })),
    {
      id: 'src-sample-local',
      name: 'Sample dataset (local)',
      source_type: 'manual',
      connection_status: 'connected',
      sync_mode: 'manual',
      sync_interval_seconds: 0,
      last_sync_at: now.toISOString(),
      last_success_at: now.toISOString(),
      last_error: null,
      configuration: { demo: true, note: 'Bundled synthetic data used by demo mode.' },
      created_at: iso(60),
    },
  ];

  const jobs: SyncJob[] = [
    {
      id: 'job-demo-1',
      source_id: 'src-sample-local',
      job_type: 'initial_import',
      status: 'success',
      records_added: leadCount,
      records_updated: 0,
      records_skipped: 0,
      attempts: 1,
      error_message: null,
      started_at: now.toISOString(),
      finished_at: now.toISOString(),
    },
  ];

  const audit: AuditLog[] = [
    {
      id: 'audit-1',
      user_id: 'usr-admin-1',
      user_name: 'Ayesha Khan',
      action: 'demo.dataset.loaded',
      entity_type: 'system',
      entity_id: null,
      metadata: { leads: leadCount, synthetic: true },
      created_at: now.toISOString(),
    },
    {
      id: 'audit-2',
      user_id: 'usr-admin-1',
      user_name: 'Ayesha Khan',
      action: 'lead.bulk_assigned',
      entity_type: 'lead',
      entity_id: null,
      metadata: { count: 12, caller: 'Rahul Menon' },
      created_at: iso(1, 15),
    },
    {
      id: 'audit-3',
      user_id: 'usr-caller-2',
      user_name: 'Sana Ali',
      action: 'lead.updated',
      entity_type: 'lead',
      entity_id: 'lead-0007',
      metadata: { fields: ['lead_status', 'notes'] },
      created_at: iso(1, 11),
    },
  ];

  return { profiles, leads, activities, sources, jobs, audit };
}

export function demoSummary(dataset: DemoDataset, ref = new Date()): DashboardSummary {
  const callsToday = dataset.activities.filter((a) => {
    const d = new Date(a.call_time);
    return (
      d.getFullYear() === ref.getFullYear() &&
      d.getMonth() === ref.getMonth() &&
      d.getDate() === ref.getDate()
    );
  }).length;
  return computeSummary(dataset.leads, callsToday, ref);
}

export const DEMO_STATUS_VALUES = LEAD_STATUSES.map((s) => s.value);
