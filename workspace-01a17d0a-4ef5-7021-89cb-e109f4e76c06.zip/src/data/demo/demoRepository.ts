import type {
  AuditLog,
  CallActivity,
  DashboardReport,
  DashboardSummary,
  DataSource,
  Lead,
  LeadFilters,
  LeadStatus,
  Paginated,
  PageRequest,
  Profile,
  Role,
  SyncJob,
} from '@/types/domain';
import type {
  ImportResult,
  ImportRow,
  LeadConflict,
  CallActivityInput,
  LeadPatch,
  LeadWriteResult,
  NewProfileInput,
  ReportFilters,
  Repository,
  SyncActionResult,
} from '../repository';
import { filterLeads, paginate, sortLeads } from '../query';
import { buildDuplicateIndex, planDuplicateHandling } from '@/lib/duplicates';
import { DEMO_USERS, buildDemoDataset, type DemoDataset } from './seed';
import { computeSummary, isSameLocalDay, isOverdue } from '@/lib/kpi';

const DATASET_KEY = 'ltd.demo.dataset.v1';
const SESSION_KEY = 'ltd.demo.session.v1';

function uid(prefix: string): string {
  const rand = globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2);
  return `${prefix}-${rand}`;
}

function delay(ms = 120): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function writeJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full / private mode — demo state stays in memory only */
  }
}

/**
 * Demo repository: synthetic data persisted in localStorage so the UI is fully
 * interactive without a Supabase project. It is explicitly labelled in the UI
 * and never reports integration success.
 */
export class DemoRepository implements Repository {
  readonly mode = 'demo' as const;
  private dataset: DemoDataset;
  private conflicts: LeadConflict[] = [];
  private sessionProfileId: string | null;
  private listeners = new Set<(p: Profile | null) => void>();

  constructor() {
    const stored = readJson<DemoDataset>(DATASET_KEY);
    this.dataset = stored?.leads?.length ? stored : buildDemoDataset();
    if (!stored) writeJson(DATASET_KEY, this.dataset);
    this.sessionProfileId = readJson<{ profileId: string }>(SESSION_KEY)?.profileId ?? null;
    window.addEventListener('storage', (event) => {
      if (event.key === DATASET_KEY) {
        const next = readJson<DemoDataset>(DATASET_KEY);
        if (next) this.dataset = next;
      }
    });
  }

  private persist(): void {
    writeJson(DATASET_KEY, this.dataset);
    // Cross-tab "realtime" for the demo backend.
    window.dispatchEvent(new CustomEvent('ltd:realtime', { detail: { table: 'leads' } }));
  }

  private currentProfile(): Profile | null {
    if (!this.sessionProfileId) return null;
    return this.dataset.profiles.find((p) => p.id === this.sessionProfileId) ?? null;
  }

  private requireProfile(): Profile {
    const profile = this.currentProfile();
    if (!profile) throw new Error('Not authenticated');
    if (!profile.active) throw new Error('This account has been deactivated');
    return profile;
  }

  private visibleLeads(profile: Profile): Lead[] {
    return profile.role === 'admin'
      ? this.dataset.leads
      : this.dataset.leads.filter((l) => l.assigned_to === profile.id);
  }

  private log(action: string, entityType: string, entityId: string | null, metadata?: Record<string, unknown>): void {
    const profile = this.currentProfile();
    this.dataset.audit = [
      {
        id: uid('audit'),
        user_id: profile?.id ?? null,
        user_name: profile?.full_name ?? null,
        action,
        entity_type: entityType,
        entity_id: entityId,
        metadata: metadata ?? null,
        created_at: new Date().toISOString(),
      },
      ...this.dataset.audit,
    ].slice(0, 200);
  }

  // Auth -------------------------------------------------------------------
  async signIn(email: string, password: string): Promise<Profile> {
    await delay(220);
    const account = DEMO_USERS.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password,
    );
    if (!account) throw new Error('Invalid email or password');
    const profile = this.dataset.profiles.find((p) => p.id === account.profileId);
    if (!profile) throw new Error('Account profile missing');
    if (!profile.active) throw new Error('This account has been deactivated. Contact an administrator.');
    this.sessionProfileId = profile.id;
    writeJson(SESSION_KEY, { profileId: profile.id });
    this.listeners.forEach((cb) => cb(profile));
    return profile;
  }

  async signOut(): Promise<void> {
    this.sessionProfileId = null;
    localStorage.removeItem(SESSION_KEY);
    this.listeners.forEach((cb) => cb(null));
  }

  async getProfile(): Promise<Profile | null> {
    return this.currentProfile();
  }

  onAuthChange(cb: (profile: Profile | null) => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  // Leads ------------------------------------------------------------------
  async listLeads(filters: LeadFilters, page: PageRequest): Promise<Paginated<Lead>> {
    await delay(90);
    const profile = this.requireProfile();
    const visible = filterLeads(this.visibleLeads(profile), filters);
    return paginate(sortLeads(visible, page.sort), page.page, page.pageSize);
  }

  async listAllLeads(filters: LeadFilters, limit = 5000): Promise<Lead[]> {
    const profile = this.requireProfile();
    return filterLeads(this.visibleLeads(profile), filters).slice(0, limit);
  }

  async getLead(id: string): Promise<Lead | null> {
    const profile = this.requireProfile();
    return this.visibleLeads(profile).find((l) => l.id === id) ?? null;
  }

  async updateLead(id: string, patch: LeadPatch, expectedVersion?: number): Promise<LeadWriteResult> {
    await delay(160);
    const profile = this.requireProfile();
    const index = this.dataset.leads.findIndex((l) => l.id === id);
    if (index === -1) throw new Error('Lead not found or not accessible');
    const current = this.dataset.leads[index];

    // Server-side-equivalent permission checks (mirrored in RLS).
    if (profile.role === 'caller' && current.assigned_to !== profile.id) {
      throw new Error('You can only update leads assigned to you');
    }
    if (profile.role === 'caller') {
      const forbidden = ['assigned_to', 'name', 'phone', 'email'].filter((k) => k in patch);
      if (forbidden.length) throw new Error(`Callers cannot change: ${forbidden.join(', ')}`);
    }

    if (expectedVersion !== undefined && current.version !== expectedVersion) {
      const changedField = Object.keys(patch)[0] ?? 'lead_status';
      return {
        lead: current,
        conflict: {
          field: changedField,
          localValue: (patch as Record<string, unknown>)[changedField],
          serverValue: (current as unknown as Record<string, unknown>)[changedField],
          serverVersion: current.version,
        },
      };
    }

    const next: Lead = {
      ...current,
      ...patch,
      updated_at: new Date().toISOString(),
      version: current.version + 1,
    };
    this.dataset.leads = this.dataset.leads.map((l, i) => (i === index ? next : l));
    this.log('lead.updated', 'lead', id, { fields: Object.keys(patch) });
    this.persist();
    return { lead: next };
  }

  async bulkAssign(leadIds: string[], callerId: string | null): Promise<number> {
    await delay(180);
    const profile = this.requireProfile();
    if (profile.role !== 'admin') throw new Error('Only administrators can assign leads');
    const target = leadIds.length;
    let changed = 0;
    this.dataset.leads = this.dataset.leads.map((lead) => {
      if (!leadIds.includes(lead.id)) return lead;
      changed += 1;
      return {
        ...lead,
        assigned_to: callerId,
        updated_at: new Date().toISOString(),
        version: lead.version + 1,
      };
    });
    this.log('lead.bulk_assigned', 'lead', null, { count: changed, caller_id: callerId });
    this.persist();
    return Math.min(changed, target);
  }

  async bulkSetStatus(leadIds: string[], status: LeadStatus): Promise<number> {
    await delay(180);
    const profile = this.requireProfile();
    if (profile.role !== 'admin') throw new Error('Only administrators can bulk-update statuses');
    let changed = 0;
    this.dataset.leads = this.dataset.leads.map((lead) => {
      if (!leadIds.includes(lead.id)) return lead;
      changed += 1;
      return {
        ...lead,
        lead_status: status,
        updated_at: new Date().toISOString(),
        version: lead.version + 1,
      };
    });
    this.log('lead.bulk_status_changed', 'lead', null, { count: changed, status });
    this.persist();
    return changed;
  }

  async deleteLeads(leadIds: string[]): Promise<number> {
    await delay(200);
    const profile = this.requireProfile();
    if (profile.role !== 'admin') throw new Error('Only administrators can delete leads');
    const before = this.dataset.leads.length;
    this.dataset.leads = this.dataset.leads.filter((l) => !leadIds.includes(l.id));
    const removed = before - this.dataset.leads.length;
    this.log('lead.deleted', 'lead', null, { count: removed, ids: leadIds });
    this.persist();
    return removed;
  }

  async addCallActivity(input: CallActivityInput): Promise<CallActivity> {
    await delay(140);
    const profile = this.requireProfile();
    const lead = this.dataset.leads.find((l) => l.id === input.lead_id);
    if (!lead) throw new Error('Lead not found');
    if (profile.role === 'caller' && lead.assigned_to !== profile.id) {
      throw new Error('You can only log calls for leads assigned to you');
    }
    const activity: CallActivity = {
      id: uid('call'),
      lead_id: input.lead_id,
      caller_id: profile.id,
      call_time: input.call_time ?? new Date().toISOString(),
      outcome: input.outcome,
      notes: input.notes ?? null,
      created_at: new Date().toISOString(),
    };
    this.dataset.activities = [activity, ...this.dataset.activities];

    this.dataset.leads = this.dataset.leads.map((l) =>
      l.id === input.lead_id
        ? {
            ...l,
            last_call_at: activity.call_time,
            lead_outcome: input.outcome,
            lead_status: input.updateLead?.lead_status ?? l.lead_status,
            next_follow_up_at:
              input.updateLead?.next_follow_up_at !== undefined
                ? input.updateLead.next_follow_up_at
                : l.next_follow_up_at,
            updated_at: new Date().toISOString(),
            version: l.version + 1,
          }
        : l,
    );
    this.log('call.logged', 'lead', input.lead_id, { outcome: input.outcome });
    this.persist();
    return activity;
  }

  async listCallActivities(leadId: string): Promise<CallActivity[]> {
    return this.dataset.activities
      .filter((a) => a.lead_id === leadId)
      .sort((a, b) => b.call_time.localeCompare(a.call_time));
  }

  // People -----------------------------------------------------------------
  async listProfiles(): Promise<Profile[]> {
    const profile = this.requireProfile();
    if (profile.role === 'admin') return this.dataset.profiles;
    return this.dataset.profiles.filter((p) => p.role === 'caller' && p.active);
  }

  async createProfile(input: NewProfileInput): Promise<Profile> {
    await delay(150);
    const admin = this.requireProfile();
    if (admin.role !== 'admin') throw new Error('Only administrators can manage callers');
    if (this.dataset.profiles.some((p) => p.email.toLowerCase() === input.email.toLowerCase())) {
      throw new Error('A profile with this email already exists');
    }
    const profile: Profile = {
      id: uid('usr'),
      full_name: input.full_name,
      email: input.email,
      role: input.role,
      active: true,
      created_at: new Date().toISOString(),
    };
    this.dataset.profiles = [...this.dataset.profiles, profile];
    this.log('user.created', 'profile', profile.id, { role: input.role });
    this.persist();
    return profile;
  }

  async updateProfile(
    id: string,
    patch: { full_name?: string; role?: Role; active?: boolean },
  ): Promise<Profile> {
    await delay(130);
    const admin = this.requireProfile();
    if (admin.role !== 'admin') throw new Error('Only administrators can manage users');
    if (patch.role && admin.id === id && patch.role !== 'admin') {
      throw new Error('You cannot remove your own administrator role');
    }
    const existing = this.dataset.profiles.find((p) => p.id === id);
    if (!existing) throw new Error('Profile not found');
    const updated = { ...existing, ...patch };
    this.dataset.profiles = this.dataset.profiles.map((p) => (p.id === id ? updated : p));
    this.log('user.updated', 'profile', id, patch);
    this.persist();
    return updated;
  }

  // Sources ----------------------------------------------------------------
  async listSources(): Promise<DataSource[]> {
    this.requireProfile();
    return this.dataset.sources;
  }

  async createSource(input: {
    name: string;
    source_type: 'excel_upload' | 'google_sheets' | 'excel_onedrive' | 'manual';
    configuration?: Record<string, unknown>;
  }): Promise<DataSource> {
    await delay(120);
    const admin = this.requireProfile();
    if (admin.role !== 'admin') throw new Error('Only administrators can add data sources');
    const source: DataSource = {
      id: uid('src'),
      name: input.name,
      source_type: input.source_type,
      connection_status: 'connected',
      sync_mode: 'manual',
      sync_interval_seconds: 0,
      last_sync_at: null,
      last_success_at: null,
      last_error: null,
      configuration: input.configuration ?? {},
      created_at: new Date().toISOString(),
    };
    this.dataset.sources = [source, ...this.dataset.sources];
    this.log('source.created', 'data_source', source.id, { type: input.source_type });
    this.persist();
    return source;
  }

  async listSyncJobs(sourceId?: string, limit = 50): Promise<SyncJob[]> {
    this.requireProfile();
    return this.dataset.jobs
      .filter((j) => (sourceId ? j.source_id === sourceId : true))
      .slice(0, limit)
      .sort((a, b) => b.started_at.localeCompare(a.started_at));
  }

  async testSourceConnection(sourceId: string): Promise<SyncActionResult> {
    this.requireProfile();
    const source = this.dataset.sources.find((s) => s.id === sourceId);
    if (!source) return { ok: false, message: 'Source not found', verified: false };
    return {
      ok: false,
      verified: false,
      message:
        'Demo mode: no server-side credentials exist. Configure Google OAuth (Phase 4) or Microsoft Graph (Phase 5) to run a real connection test.',
    };
  }

  async requestSync(): Promise<SyncActionResult> {
    this.requireProfile();
    return {
      ok: false,
      verified: false,
      message:
        'Demo mode has no external source to sync. Use Excel import (Phase 3) or connect Google Sheets to enable real synchronisation.',
    };
  }

  async retryFailedJobs(): Promise<SyncActionResult> {
    this.requireProfile();
    return { ok: false, verified: false, message: 'No failed jobs to retry in demo mode.' };
  }

  async toggleSourceSync(sourceId: string, enabled: boolean, intervalSeconds?: number): Promise<DataSource> {
    const admin = this.requireProfile();
    if (admin.role !== 'admin') throw new Error('Only administrators can change sync settings');
    const source = this.dataset.sources.find((s) => s.id === sourceId);
    if (!source) throw new Error('Source not found');
    const updated: DataSource = {
      ...source,
      sync_mode: enabled ? 'interval' : 'manual',
      sync_interval_seconds: intervalSeconds ?? source.sync_interval_seconds,
    };
    this.dataset.sources = this.dataset.sources.map((s) => (s.id === sourceId ? updated : s));
    this.log('source.sync_settings_changed', 'data_source', sourceId, { enabled, intervalSeconds });
    this.persist();
    return updated;
  }

  // Reporting --------------------------------------------------------------
  async getSummary(filters: Pick<ReportFilters, 'dateFrom' | 'dateTo'> = {}): Promise<DashboardSummary> {
    const profile = this.requireProfile();
    const leads = filterLeads(this.visibleLeads(profile), {
      dateFrom: filters.dateFrom,
      dateTo: filters.dateTo,
    });
    const visibleIds = new Set(leads.map((l) => l.id));
    const callsToday = this.dataset.activities.filter(
      (a) => visibleIds.has(a.lead_id) && isSameLocalDay(a.call_time),
    ).length;
    return computeSummary(leads, callsToday, new Date());
  }

  async getReport(filters: ReportFilters): Promise<DashboardReport> {
    const profile = this.requireProfile();
    const leads = filterLeads(this.visibleLeads(profile), {
      dateFrom: filters.dateFrom,
      dateTo: filters.dateTo,
      assignedTo: filters.callerId,
      sourceId: filters.sourceId,
    });

    const callerStats = this.dataset.profiles
      .filter((p) => p.role === 'caller')
      .map((caller) => {
        const own = leads.filter((l) => l.assigned_to === caller.id);
        const calls = this.dataset.activities.filter(
          (a) => a.caller_id === caller.id && own.some((l) => l.id === a.lead_id),
        );
        return {
          callerId: caller.id,
          callerName: caller.full_name,
          totalCalls: calls.length,
          interested: own.filter((l) => l.lead_status === 'interested').length,
          callbacks: own.filter((l) => l.lead_status === 'call_back').length,
          assignedLeads: own.length,
        };
      })
      .filter((row) => filters.callerId ? row.callerId === filters.callerId : true);

    const sourceStats = this.dataset.sources.map((source) => {
      const own = leads.filter((l) => l.source_id === source.id);
      return {
        sourceId: source.id,
        sourceName: source.name,
        total: own.length,
        interested: own.filter((l) => l.lead_status === 'interested').length,
        notDialed: own.filter((l) => l.lead_status === 'not_dialed').length,
        lastSyncAt: source.last_success_at,
      };
    });

    const days: { date: string; count: number }[] = [];
    for (let i = 13; i >= 0; i -= 1) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      d.setHours(0, 0, 0, 0);
      const next = new Date(d);
      next.setDate(next.getDate() + 1);
      days.push({
        date: `${d.getMonth() + 1}/${d.getDate()}`,
        count: leads.filter((l) => {
          const t = new Date(l.created_at).getTime();
          return t >= d.getTime() && t < next.getTime();
        }).length,
      });
    }

    return {
      callerStats,
      sourceStats,
      leadsPerDay: days,
      callbacksDueToday: leads.filter(
        (l) => l.lead_status === 'call_back' && isSameLocalDay(l.next_follow_up_at),
      ),
      overdueFollowUps: leads.filter(
        (l) =>
          (l.lead_status === 'follow_up_pending' || l.lead_status === 'call_back') &&
          isOverdue(l.next_follow_up_at),
      ),
    };
  }

  async listAuditLogs(limit = 100): Promise<AuditLog[]> {
    const profile = this.requireProfile();
    if (profile.role !== 'admin') throw new Error('Only administrators can view audit logs');
    return this.dataset.audit.slice(0, limit);
  }

  // Import -----------------------------------------------------------------
  async importLeads(
    sourceId: string,
    rows: ImportRow[],
    policy: 'skip' | 'update' | 'create' = 'update',
  ): Promise<ImportResult> {
    await delay(200);
    const admin = this.requireProfile();
    if (admin.role !== 'admin') throw new Error('Only administrators can import leads');

    const source = this.dataset.sources.find((s) => s.id === sourceId);
    if (!source) throw new Error('Data source not found');

    const index = buildDuplicateIndex(this.dataset.leads);
    const decisions = planDuplicateHandling(index, rows.map((r) => ({ name: r.name, phone: r.phone, email: r.email })), policy);
    let added = 0;
    let updated = 0;
    let skipped = 0;
    const errors: { row: number; message: string }[] = [];
    const now = new Date().toISOString();
    let counter = this.dataset.leads.length;

    rows.forEach((row, i) => {
      const decision = decisions[i];
      if (!row.name?.trim() || !row.phone?.trim()) {
        skipped += 1;
        errors.push({ row: i + 2, message: 'Name and mobile number are required' });
        return;
      }
      if (decision.action === 'skip') {
        skipped += 1;
        return;
      }
      if (decision.action === 'update' && decision.existingId) {
        this.dataset.leads = this.dataset.leads.map((lead) =>
          lead.id === decision.existingId
            ? {
                ...lead,
                name: row.name,
                phone: row.phone,
                email: row.email ?? lead.email,
                lead_status: row.lead_status ?? lead.lead_status,
                lead_outcome: row.lead_outcome ?? lead.lead_outcome,
                next_follow_up_at: row.next_follow_up_at ?? lead.next_follow_up_at,
                notes: row.notes ?? lead.notes,
                source_id: sourceId,
                source_sheet_name: row.source_sheet_name ?? lead.source_sheet_name,
                source_record_id: row.source_record_id ?? lead.source_record_id,
                updated_at: now,
                version: lead.version + 1,
              }
            : lead,
        );
        updated += 1;
        return;
      }
      counter += 1;
      this.dataset.leads = [
        {
          id: `lead-imp-${counter}`,
          source_id: sourceId,
          source_external_id: row.source_external_id ?? null,
          source_sheet_name: row.source_sheet_name ?? null,
          source_record_id: row.source_record_id ?? `row-${i + 2}`,
          name: row.name,
          phone: row.phone,
          email: row.email ?? null,
          lead_status: row.lead_status ?? 'not_dialed',
          lead_outcome: row.lead_outcome ?? 'pending',
          assigned_to: null,
          last_call_at: null,
          next_follow_up_at: row.next_follow_up_at ?? null,
          notes: row.notes ?? null,
          created_at: now,
          updated_at: now,
          version: 1,
        },
        ...this.dataset.leads,
      ];
      added += 1;
    });

    this.dataset.jobs = [
      {
        id: uid('job'),
        source_id: sourceId,
        job_type: 'manual_refresh',
        status: 'success',
        records_added: added,
        records_updated: updated,
        records_skipped: skipped,
        attempts: 1,
        error_message: null,
        started_at: now,
        finished_at: now,
      },
      ...this.dataset.jobs,
    ];
    this.dataset.sources = this.dataset.sources.map((s) =>
      s.id === sourceId ? { ...s, last_sync_at: now, last_success_at: now, last_error: null } : s,
    );
    this.log('leads.imported', 'data_source', sourceId, { added, updated, skipped, policy });
    this.persist();
    return { added, updated, skipped, policy, errors };
  }

  // Conflicts ---------------------------------------------------------------
  async listConflicts(): Promise<LeadConflict[]> {
    this.requireProfile();
    return this.conflicts.filter((c) => c.status === 'open');
  }

  async resolveConflict(
    id: string,
    resolution: 'resolved_local' | 'resolved_server' | 'dismissed',
  ): Promise<void> {
    const admin = this.requireProfile();
    if (admin.role !== 'admin') throw new Error('Only administrators can resolve conflicts');
    const conflict = this.conflicts.find((c) => c.id === id);
    if (!conflict) throw new Error('Conflict not found');
    if (resolution === 'resolved_local') {
      this.dataset.leads = this.dataset.leads.map((lead) =>
        lead.id === conflict.lead_id
          ? ({ ...lead, [conflict.field]: conflict.local_value, updated_at: new Date().toISOString(), version: lead.version + 1 } as typeof lead)
          : lead,
      );
    }
    this.conflicts = this.conflicts.map((c) => (c.id === id ? { ...c, status: resolution } : c));
    this.log(`conflict.${resolution}`, 'lead', conflict.lead_id, { field: conflict.field });
    this.persist();
  }

  async exportLeads(filters: LeadFilters): Promise<Lead[]> {
    return this.listAllLeads(filters);
  }
}

