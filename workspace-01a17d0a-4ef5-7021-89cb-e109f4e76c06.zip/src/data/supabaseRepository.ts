import type {
  AuditLog,
  CallActivity,
  DashboardReport,
  DashboardSummary,
  DataSource,
  Lead,
  LeadFilters,
  LeadStatus,
  PageRequest,
  Paginated,
  Profile,
  Role,
  SyncJob,
} from '@/types/domain';
import type {
  ImportResult,
  ImportRow,
  LeadConflict,
  CallActivityInput,
  LeadPatch,
  LeadWriteResult,
  NewProfileInput,
  ReportFilters,
  Repository,
  SyncActionResult,
} from './repository';
import { SORT_FIELD_TO_COLUMN } from './repository';
import { getSupabase } from '@/lib/supabase';

/* eslint-disable @typescript-eslint/no-explicit-any */
type Row = Record<string, any>;

function mapProfile(row: Row): Profile {
  return {
    id: row.id,
    full_name: row.full_name ?? 'Unnamed user',
    email: row.email ?? '',
    role: (row.role ?? 'caller') as Role,
    active: row.active !== false,
    created_at: row.created_at,
  };
}

function mapLead(row: Row): Lead {
  return {
    id: row.id,
    source_id: row.source_id ?? null,
    source_external_id: row.source_external_id ?? null,
    source_sheet_name: row.source_sheet_name ?? null,
    source_record_id: row.source_record_id ?? null,
    name: row.name,
    phone: row.phone,
    email: row.email ?? null,
    lead_status: row.lead_status,
    lead_outcome: row.lead_outcome ?? 'pending',
    assigned_to: row.assigned_to ?? null,
    last_call_at: row.last_call_at ?? null,
    next_follow_up_at: row.next_follow_up_at ?? null,
    notes: row.notes ?? null,
    created_at: row.created_at,
    updated_at: row.updated_at,
    version: row.version ?? 1,
  };
}

function mapSource(row: Row): DataSource {
  return {
    id: row.id,
    name: row.name,
    source_type: row.source_type,
    connection_status: row.connection_status ?? 'not_configured',
    sync_mode: row.sync_mode ?? 'manual',
    sync_interval_seconds: row.sync_interval_seconds ?? 60,
    last_sync_at: row.last_sync_at ?? null,
    last_success_at: row.last_success_at ?? null,
    last_error: row.last_error ?? null,
    configuration: row.configuration ?? {},
    created_at: row.created_at,
  };
}

function mapJob(row: Row): SyncJob {
  return {
    id: row.id,
    source_id: row.source_id,
    job_type: row.job_type,
    status: row.status,
    records_added: row.records_added ?? 0,
    records_updated: row.records_updated ?? 0,
    records_skipped: row.records_skipped ?? 0,
    attempts: row.attempts ?? 0,
    error_message: row.error_message ?? null,
    started_at: row.started_at,
    finished_at: row.finished_at ?? null,
  };
}

function mapAudit(row: Row): AuditLog {
  return {
    id: row.id,
    user_id: row.user_id ?? null,
    user_name: row.user_name ?? null,
    action: row.action,
    entity_type: row.entity_type,
    entity_id: row.entity_id ?? null,
    metadata: row.metadata ?? null,
    created_at: row.created_at,
  };
}

/**
 * Live repository backed by Supabase Postgres + Auth + Realtime.
 *
 * There are no client-side shortcuts: every read and write is a query whose
 * result is filtered by RLS. Column-level restrictions for callers are
 * enforced by the `enforce_lead_write_rules` trigger, not here.
 */
export class SupabaseRepository implements Repository {
  readonly mode = 'live' as const;
  private sb = getSupabase();

  // Auth -------------------------------------------------------------------
  async signIn(email: string, password: string): Promise<Profile> {
    const { data, error } = await this.sb.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Sign-in failed');
    const profile = await this.fetchProfile(data.user.id);
    if (!profile) throw new Error('No profile is linked to this account. Ask an administrator to invite you.');
    if (!profile.active) {
      await this.sb.auth.signOut();
      throw new Error('This account has been deactivated. Contact an administrator.');
    }
    return profile;
  }

  async signOut(): Promise<void> {
    await this.sb.auth.signOut();
  }

  async getProfile(): Promise<Profile | null> {
    const { data } = await this.sb.auth.getUser();
    if (!data.user) return null;
    return this.fetchProfile(data.user.id);
  }

  private async fetchProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await this.sb.from('profiles').select('*').eq('id', userId).maybeSingle();
    if (error) throw new Error(error.message);
    return data ? mapProfile(data as Row) : null;
  }

  onAuthChange(cb: (profile: Profile | null) => void): () => void {
    const { data } = this.sb.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT' || !session?.user) {
        cb(null);
        return;
      }
      void this.fetchProfile(session.user.id)
        .then((profile) => cb(profile))
        .catch(() => cb(null));
    });
    return () => data.subscription.unsubscribe();
  }

  // Leads ------------------------------------------------------------------
  private applyFilters(query: any, filters: LeadFilters): any {
    let q = query;
    if (filters.search?.trim()) {
      const term = filters.search.trim().replace(/[%,()]/g, ' ');
      q = q.or(
        [
          `name.ilike.%${term}%`,
          `phone.ilike.%${term}%`,
          `email.ilike.%${term}%`,
          `source_record_id.ilike.%${term}%`,
        ].join(','),
      );
    }
    if (filters.statuses?.length) q = q.in('lead_status', filters.statuses);
    if (filters.outcome) q = q.eq('lead_outcome', filters.outcome);
    if (filters.assignedTo === 'unassigned') q = q.is('assigned_to', null);
    else if (filters.assignedTo) q = q.eq('assigned_to', filters.assignedTo);
    if (filters.sourceId) q = q.eq('source_id', filters.sourceId);
    if (filters.dateFrom) q = q.gte('created_at', `${filters.dateFrom}T00:00:00`);
    if (filters.dateTo) q = q.lte('created_at', `${filters.dateTo}T23:59:59.999`);
    if (filters.followUpDueBefore) q = q.lte('next_follow_up_at', filters.followUpDueBefore);
    return q;
  }

  async listLeads(filters: LeadFilters, page: PageRequest): Promise<Paginated<Lead>> {
    const from = (page.page - 1) * page.pageSize;
    const to = from + page.pageSize - 1;
    const column = SORT_FIELD_TO_COLUMN[page.sort.field];
    const query = this.applyFilters(
      this.sb.from('leads').select('*', { count: 'exact' }),
      filters,
    ).order(column, { ascending: page.sort.direction === 'asc', nullsFirst: false });

    const { data, error, count } = await query.range(from, to);
    if (error) throw new Error(error.message);
    return {
      rows: (data ?? []).map(mapLead),
      total: count ?? 0,
      page: page.page,
      pageSize: page.pageSize,
    };
  }

  async listAllLeads(filters: LeadFilters, limit = 5000): Promise<Lead[]> {
    const query = this.applyFilters(this.sb.from('leads').select('*'), filters).limit(limit);
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapLead);
  }

  async getLead(id: string): Promise<Lead | null> {
    const { data, error } = await this.sb.from('leads').select('*').eq('id', id).maybeSingle();
    if (error) throw new Error(error.message);
    return data ? mapLead(data as Row) : null;
  }

  async updateLead(id: string, patch: LeadPatch, expectedVersion?: number): Promise<LeadWriteResult> {
    let query = this.sb.from('leads').update(patch).eq('id', id);
    if (expectedVersion !== undefined) query = query.eq('version', expectedVersion);
    const { data, error } = await query.select().maybeSingle();

    if (error) throw new Error(error.message);

    if (!data) {
      // Either the row is gone or the version moved on: record a conflict
      // instead of silently overwriting the other editor's change.
      const server = await this.getLead(id);
      if (!server) throw new Error('Lead no longer exists');
      const field = Object.keys(patch)[0] ?? 'lead_status';
      await this.sb.from('lead_conflicts').insert({
        lead_id: id,
        field,
        local_value: String((patch as Row)[field] ?? ''),
        server_value: String((server as Row)[field] ?? ''),
        client: 'web',
      });
      return {
        lead: server,
        conflict: {
          field,
          localValue: (patch as Row)[field],
          serverValue: (server as unknown as Row)[field],
          serverVersion: server.version,
        },
      };
    }
    return { lead: mapLead(data as Row) };
  }

  async bulkAssign(leadIds: string[], callerId: string | null): Promise<number> {
    const { data, error } = await this.sb
      .from('leads')
      .update({ assigned_to: callerId })
      .in('id', leadIds)
      .select('id');
    if (error) throw new Error(error.message);
    return data?.length ?? 0;
  }

  async bulkSetStatus(leadIds: string[], status: LeadStatus): Promise<number> {
    const { data, error } = await this.sb
      .from('leads')
      .update({ lead_status: status })
      .in('id', leadIds)
      .select('id');
    if (error) throw new Error(error.message);
    return data?.length ?? 0;
  }

  async deleteLeads(leadIds: string[]): Promise<number> {
    const { data, error } = await this.sb.from('leads').delete().in('id', leadIds).select('id');
    if (error) throw new Error(error.message);
    return data?.length ?? 0;
  }

  async addCallActivity(input: CallActivityInput): Promise<CallActivity> {
    const { data, error } = await this.sb.rpc('log_call', {
      p_lead_id: input.lead_id,
      p_outcome: input.outcome,
      p_notes: input.notes ?? null,
      p_call_time: input.call_time ?? new Date().toISOString(),
      p_lead_status: input.updateLead?.lead_status ?? null,
      p_next_follow_up_at: input.updateLead?.next_follow_up_at ?? null,
    });
    if (error) throw new Error(error.message);
    const row = Array.isArray(data) ? data[0] : data;
    return {
      id: row.id,
      lead_id: row.lead_id,
      caller_id: row.caller_id,
      call_time: row.call_time,
      outcome: row.outcome,
      notes: row.notes,
      created_at: row.created_at,
    };
  }

  async listCallActivities(leadId: string): Promise<CallActivity[]> {
    const { data, error } = await this.sb
      .from('call_activities')
      .select('*')
      .eq('lead_id', leadId)
      .order('call_time', { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return (data ?? []).map((row: Row) => ({
      id: row.id,
      lead_id: row.lead_id,
      caller_id: row.caller_id,
      call_time: row.call_time,
      outcome: row.outcome,
      notes: row.notes ?? null,
      created_at: row.created_at,
    }));
  }

  // People -----------------------------------------------------------------
  async listProfiles(): Promise<Profile[]> {
    const { data, error } = await this.sb.from('profiles').select('*').order('full_name');
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapProfile);
  }

  async createProfile(input: NewProfileInput): Promise<Profile> {
    // Creating auth users requires the service role: that only happens inside
    // the `admin-users` Edge Function, which re-verifies the caller's role.
    const { data, error } = await this.sb.functions.invoke('admin-users', {
      body: { action: 'create', ...input },
    });
    if (error) throw new Error(error.message);
    if (!data?.profile) throw new Error(data?.error ?? 'Could not create the caller account');
    return mapProfile(data.profile);
  }

  async updateProfile(
    id: string,
    patch: { full_name?: string; role?: Role; active?: boolean },
  ): Promise<Profile> {
    const { data, error } = await this.sb.from('profiles').update(patch).eq('id', id).select().single();
    if (error) throw new Error(error.message);
    return mapProfile(data as Row);
  }

  // Sources & sync ---------------------------------------------------------
  async listSources(): Promise<DataSource[]> {
    const { data, error } = await this.sb.from('data_sources').select('*').order('name');
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapSource);
  }

  async createSource(input: {
    name: string;
    source_type: 'excel_upload' | 'google_sheets' | 'excel_onedrive' | 'manual';
    configuration?: Record<string, unknown>;
  }): Promise<DataSource> {
    const { data, error } = await this.sb
      .from('data_sources')
      .insert({
        name: input.name,
        source_type: input.source_type,
        configuration: input.configuration ?? {},
        // Uploaded workbooks are imported in the foreground; they are never
        // presented as a live connection until a sync actually runs.
        connection_status: input.source_type === 'excel_upload' ? 'connected' : 'not_configured',
        sync_mode: 'manual',
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return mapSource(data as Row);
  }

  async listSyncJobs(sourceId?: string, limit = 50): Promise<SyncJob[]> {
    let query = this.sb.from('sync_jobs').select('*').order('started_at', { ascending: false }).limit(limit);
    if (sourceId) query = query.eq('source_id', sourceId);
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapJob);
  }

  private async invokeSync(body: Record<string, unknown>): Promise<SyncActionResult> {
    const { data, error } = await this.sb.functions.invoke('source-sync', { body });
    if (error) return { ok: false, message: error.message, verified: false };
    return {
      ok: Boolean(data?.ok),
      message: String(data?.message ?? (data?.ok ? 'Request accepted.' : 'Request failed.')),
      verified: Boolean(data?.verified),
    };
  }

  async testSourceConnection(sourceId: string): Promise<SyncActionResult> {
    return this.invokeSync({ action: 'test_connection', source_id: sourceId });
  }

  async requestSync(sourceId: string, jobType: 'manual_refresh' | 'incremental' = 'manual_refresh') {
    return this.invokeSync({ action: 'sync_now', source_id: sourceId, job_type: jobType });
  }

  async retryFailedJobs(sourceId: string): Promise<SyncActionResult> {
    return this.invokeSync({ action: 'retry_failed', source_id: sourceId });
  }

  async toggleSourceSync(sourceId: string, enabled: boolean, intervalSeconds?: number): Promise<DataSource> {
    const { data, error } = await this.sb
      .from('data_sources')
      .update({
        sync_mode: enabled ? 'interval' : 'manual',
        ...(intervalSeconds ? { sync_interval_seconds: intervalSeconds } : {}),
      })
      .eq('id', sourceId)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return mapSource(data as Row);
  }

  // Reporting --------------------------------------------------------------
  async getSummary(filters: Pick<ReportFilters, 'dateFrom' | 'dateTo'> = {}): Promise<DashboardSummary> {
    const { data, error } = await this.sb.rpc('dashboard_summary', {
      p_from: filters.dateFrom ?? null,
      p_to: filters.dateTo ?? null,
    });
    if (error) throw new Error(error.message);
    const row = (data ?? {}) as Row;
    return {
      totalLeads: Number(row.total_leads ?? 0),
      byStatus: row.by_status ?? {},
      callsToday: Number(row.calls_today ?? 0),
      callbacksDueToday: Number(row.callbacks_due_today ?? 0),
      overdueFollowUps: Number(row.overdue_follow_ups ?? 0),
      unassigned: Number(row.unassigned ?? 0),
    };
  }

  async getReport(filters: ReportFilters): Promise<DashboardReport> {
    const { data, error } = await this.sb.rpc('report_summary', {
      p_from: filters.dateFrom ?? null,
      p_to: filters.dateTo ?? null,
      p_caller: filters.callerId ?? null,
      p_source: filters.sourceId ?? null,
    });
    if (error) throw new Error(error.message);
    const row = (data ?? {}) as Row;
    return {
      callerStats: (row.caller_stats ?? []).map((c: Row) => ({
        callerId: c.caller_id,
        callerName: c.caller_name,
        totalCalls: Number(c.total_calls ?? 0),
        interested: Number(c.interested ?? 0),
        callbacks: Number(c.callbacks ?? 0),
        assignedLeads: Number(c.assigned_leads ?? 0),
      })),
      sourceStats: (row.source_stats ?? []).map((s: Row) => ({
        sourceId: s.source_id,
        sourceName: s.source_name,
        total: Number(s.total ?? 0),
        interested: Number(s.interested ?? 0),
        notDialed: Number(s.not_dialed ?? 0),
        lastSyncAt: s.last_sync_at ?? null,
      })),
      leadsPerDay: (row.leads_per_day ?? []).map((d: Row) => ({
        date: d.date,
        count: Number(d.count ?? 0),
      })),
      callbacksDueToday: (row.callbacks ?? []).map(mapLead),
      overdueFollowUps: (row.overdue ?? []).map(mapLead),
    };
  }

  async listAuditLogs(limit = 100): Promise<AuditLog[]> {
    const { data, error } = await this.sb
      .from('audit_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapAudit);
  }

  // Import -----------------------------------------------------------------
  async importLeads(
    sourceId: string,
    rows: ImportRow[],
    policy: 'skip' | 'update' | 'create' = 'update',
  ): Promise<ImportResult> {
    // The RPC is SECURITY DEFINER but re-checks is_admin() and writes a durable
    // sync_jobs record in the same transaction.
    const { data, error } = await this.sb.rpc('import_leads', {
      p_source_id: sourceId,
      p_rows: rows,
      p_policy: policy,
      p_job_type: 'manual_refresh',
    });
    if (error) throw new Error(error.message);
    const row = (data ?? {}) as Row;
    return {
      added: Number(row.added ?? 0),
      updated: Number(row.updated ?? 0),
      skipped: Number(row.skipped ?? 0),
      policy: String(row.policy ?? policy),
    };
  }

  // Conflicts ---------------------------------------------------------------
  async listConflicts(): Promise<LeadConflict[]> {
    const { data, error } = await this.sb
      .from('lead_conflicts')
      .select('*')
      .eq('status', 'open')
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return (data ?? []).map((row: Row) => ({
      id: row.id,
      lead_id: row.lead_id,
      field: row.field,
      local_value: row.local_value,
      server_value: row.server_value,
      status: row.status,
      created_at: row.created_at,
    }));
  }

  async resolveConflict(
    id: string,
    resolution: 'resolved_local' | 'resolved_server' | 'dismissed',
  ): Promise<void> {
    const { error } = await this.sb.rpc('resolve_conflict', {
      p_conflict_id: id,
      p_resolution: resolution,
    });
    if (error) throw new Error(error.message);
  }

  async exportLeads(filters: LeadFilters): Promise<Lead[]> {
    return this.listAllLeads(filters, 20000);
  }
}
