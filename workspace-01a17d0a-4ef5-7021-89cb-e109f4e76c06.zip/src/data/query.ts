import type { Lead, LeadFilters, PageRequest, Paginated, SortSpec } from '@/types/domain';
import { normalizePhone } from '@/lib/duplicates';

/** Shared in-memory query engine used by the demo repo and by unit tests. */
export function matchesSearch(lead: Lead, search: string): boolean {
  const q = search.trim().toLowerCase();
  if (!q) return true;
  if (lead.id.toLowerCase().includes(q)) return true;
  if (lead.name.toLowerCase().includes(q)) return true;
  if (lead.email?.toLowerCase().includes(q)) return true;
  // Phone matching ignores formatting and country prefixes.
  const qDigits = normalizePhone(q);
  if (qDigits.length >= 4 && normalizePhone(lead.phone).includes(qDigits)) return true;
  if (lead.phone.toLowerCase().includes(q)) return true;
  if (lead.source_record_id?.toLowerCase().includes(q)) return true;
  if (lead.notes?.toLowerCase().includes(q)) return true;
  return false;
}

export function filterLeads(leads: Lead[], filters: LeadFilters): Lead[] {
  return leads.filter((lead) => {
    if (filters.search && !matchesSearch(lead, filters.search)) return false;

    if (filters.statuses?.length && !filters.statuses.includes(lead.lead_status)) return false;
    if (filters.outcome && lead.lead_outcome !== filters.outcome) return false;

    if (filters.assignedTo === 'unassigned') {
      if (lead.assigned_to) return false;
    } else if (filters.assignedTo && lead.assigned_to !== filters.assignedTo) {
      return false;
    }

    if (filters.sourceId && lead.source_id !== filters.sourceId) return false;

    if (filters.dateFrom) {
      const from = new Date(`${filters.dateFrom}T00:00:00`);
      if (new Date(lead.created_at).getTime() < from.getTime()) return false;
    }
    if (filters.dateTo) {
      const to = new Date(`${filters.dateTo}T23:59:59.999`);
      if (new Date(lead.created_at).getTime() > to.getTime()) return false;
    }
    if (filters.followUpDueBefore) {
      const due = lead.next_follow_up_at ? new Date(lead.next_follow_up_at).getTime() : Infinity;
      if (due > new Date(filters.followUpDueBefore).getTime()) return false;
    }
    return true;
  });
}

const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });

export function compareBy(sort: SortSpec) {
  const dir = sort.direction === 'asc' ? 1 : -1;
  return (a: Lead, b: Lead): number => {
    const av = a[sort.field];
    const bv = b[sort.field];
    if (av === bv) return collator.compare(a.name, b.name);
    if (av === null || av === undefined) return 1; // nulls last
    if (bv === null || bv === undefined) return -1;
    if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
    return collator.compare(String(av), String(bv)) * dir;
  };
}

export function sortLeads(leads: Lead[], sort: SortSpec): Lead[] {
  return [...leads].sort(compareBy(sort));
}

export function paginate<T>(rows: T[], page: number, pageSize: number): Paginated<T> {
  const safePage = Math.max(1, Math.floor(page));
  const safeSize = Math.max(1, Math.floor(pageSize));
  const start = (safePage - 1) * safeSize;
  return {
    rows: rows.slice(start, start + safeSize),
    total: rows.length,
    page: safePage,
    pageSize: safeSize,
  };
}

export function queryLeads(leads: Lead[], filters: LeadFilters, page: PageRequest): Paginated<Lead> {
  const filtered = sortLeads(filterLeads(leads, filters), page.sort);
  return paginate(filtered, page.page, page.pageSize);
}
