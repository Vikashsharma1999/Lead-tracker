import type { Repository } from './repository';
import { DemoRepository } from './demo/demoRepository';
import { SupabaseRepository } from './supabaseRepository';
import { getSupabase } from '@/lib/supabase';
import { isDemoMode } from '@/lib/env';

let instance: Repository | null = null;

export function getRepository(): Repository {
  if (!instance) {
    // The Supabase client itself is created lazily, so demo builds never make
    // a network call or require credentials.
    instance = isDemoMode ? new DemoRepository() : new SupabaseRepository();
  }
  return instance;
}

export function setRepository(repo: Repository): void {
  instance = repo;
}

/**
 * Subscribe to database realtime changes.
 *
 * - live mode: Supabase Realtime `postgres_changes` on leads / call_activities /
 *   data_sources / sync_jobs. RLS still applies: callers only receive rows they
 *   are allowed to read.
 * - demo mode: a local event bus that fires on the same tab and on other tabs.
 *
 * Note: this is *database* realtime. It says nothing about Google Sheets or
 * Excel sync, which are separate pipelines shown on the Data Sources page.
 */
export function subscribeToRealtime(onChange: (table: string) => void): () => void {
  if (isDemoMode) {
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<{ table?: string }>).detail;
      onChange(detail?.table ?? 'leads');
    };
    window.addEventListener('ltd:realtime', handler);
    const storageHandler = (event: StorageEvent) => {
      if (event.key === 'ltd.demo.dataset.v1') onChange('leads');
    };
    window.addEventListener('storage', storageHandler);
    return () => {
      window.removeEventListener('ltd:realtime', handler);
      window.removeEventListener('storage', storageHandler);
    };
  }

  const sb = getSupabase();
  const channel = sb
    .channel('db-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, () => onChange('leads'))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'call_activities' }, () =>
      onChange('call_activities'),
    )
    .on('postgres_changes', { event: '*', schema: 'public', table: 'data_sources' }, () =>
      onChange('data_sources'),
    )
    .on('postgres_changes', { event: '*', schema: 'public', table: 'sync_jobs' }, () =>
      onChange('sync_jobs'),
    )
    .subscribe();
  return () => {
    void sb.removeChannel(channel);
  };
}
