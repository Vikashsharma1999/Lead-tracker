import type {
  AuditLog,
  CallActivity,
  DashboardReport,
  DashboardSummary,
  DataSource,
  Lead,
  LeadFilters,
  LeadOutcome,
  LeadStatus,
  Paginated,
  PageRequest,
  Profile,
  Role,
  SortField,
  SyncJob,
} from '@/types/domain';

export interface LeadPatch {
  name?: string;
  phone?: string;
  email?: string | null;
  lead_status?: LeadStatus;
  lead_outcome?: LeadOutcome;
  assigned_to?: string | null;
  last_call_at?: string | null;
  next_follow_up_at?: string | null;
  notes?: string | null;
}

export interface LeadWriteResult {
  lead: Lead;
  /** Present when the server rejected the write because the row changed. */
  conflict?: {
    field: string;
    localValue: unknown;
    serverValue: unknown;
    serverVersion: number;
  };
}

export interface CallActivityInput {
  lead_id: string;
  outcome: LeadOutcome;
  notes?: string | null;
  call_time?: string;
  /** When true, also derives lead_status / last_call_at / next_follow_up_at. */
  updateLead?: {
    lead_status?: LeadStatus;
    next_follow_up_at?: string | null;
  };
}

export interface SyncActionResult {
  ok: boolean;
  message: string;
  /** True only when a real server-side connection test succeeded. */
  verified?: boolean;
}

export interface ReportFilters {
  dateFrom?: string;
  dateTo?: string;
  callerId?: string;
  sourceId?: string;
}

export interface ImportRow {
  name: string;
  phone: string;
  email?: string | null;
  lead_status?: LeadStatus;
  lead_outcome?: LeadOutcome;
  next_follow_up_at?: string | null;
  notes?: string | null;
  source_sheet_name?: string | null;
  source_record_id?: string | null;
  source_external_id?: string | null;
}

export interface ImportResult {
  added: number;
  updated: number;
  skipped: number;
  policy: string;
  /** Per-row rejections reported by the server (validation/duplicates). */
  errors?: { row: number; message: string }[];
}

export interface LeadConflict {
  id: string;
  lead_id: string;
  field: string;
  local_value: string | null;
  server_value: string | null;
  status: 'open' | 'resolved_local' | 'resolved_server' | 'dismissed';
  created_at: string;
}

export interface NewProfileInput {
  email: string;
  full_name: string;
  role: Role;
  password?: string;
}

/** Everything the UI needs, independent of the backing store. */
export interface Repository {
  readonly mode: 'live' | 'demo';

  // Auth ------------------------------------------------------------------
  signIn(email: string, password: string): Promise<Profile>;
  signUpWithInvite?(email: string, password: string, fullName: string): Promise<Profile>;
  signOut(): Promise<void>;
  getProfile(): Promise<Profile | null>;
  onAuthChange(cb: (profile: Profile | null) => void): () => void;

  // Leads -----------------------------------------------------------------
  listLeads(filters: LeadFilters, page: PageRequest): Promise<Paginated<Lead>>;
  listAllLeads(filters: LeadFilters, limit?: number): Promise<Lead[]>;
  getLead(id: string): Promise<Lead | null>;
  updateLead(id: string, patch: LeadPatch, expectedVersion?: number): Promise<LeadWriteResult>;
  bulkAssign(leadIds: string[], callerId: string | null): Promise<number>;
  bulkSetStatus(leadIds: string[], status: LeadStatus): Promise<number>;
  deleteLeads(leadIds: string[]): Promise<number>;
  addCallActivity(input: CallActivityInput): Promise<CallActivity>;
  listCallActivities(leadId: string): Promise<CallActivity[]>;

  // People ----------------------------------------------------------------
  listProfiles(): Promise<Profile[]>;
  createProfile(input: NewProfileInput): Promise<Profile>;
  updateProfile(id: string, patch: { full_name?: string; role?: Role; active?: boolean }): Promise<Profile>;

  // Sources & sync --------------------------------------------------------
  listSources(): Promise<DataSource[]>;
  createSource(input: {
    name: string;
    source_type: 'excel_upload' | 'google_sheets' | 'excel_onedrive' | 'manual';
    configuration?: Record<string, unknown>;
  }): Promise<DataSource>;
  listSyncJobs(sourceId?: string, limit?: number): Promise<SyncJob[]>;
  testSourceConnection(sourceId: string): Promise<SyncActionResult>;
  requestSync(sourceId: string, jobType?: 'manual_refresh' | 'incremental'): Promise<SyncActionResult>;
  retryFailedJobs(sourceId: string): Promise<SyncActionResult>;
  toggleSourceSync(sourceId: string, enabled: boolean, intervalSeconds?: number): Promise<DataSource>;

  // Reporting -------------------------------------------------------------
  getSummary(filters?: Pick<ReportFilters, 'dateFrom' | 'dateTo'>): Promise<DashboardSummary>;
  getReport(filters: ReportFilters): Promise<DashboardReport>;
  listAuditLogs(limit?: number): Promise<AuditLog[]>;

  // Import ----------------------------------------------------------------
  importLeads(
    sourceId: string,
    rows: ImportRow[],
    policy?: 'skip' | 'update' | 'create',
  ): Promise<ImportResult>;

  // Conflicts -------------------------------------------------------------
  listConflicts(): Promise<LeadConflict[]>;
  resolveConflict(id: string, resolution: 'resolved_local' | 'resolved_server' | 'dismissed'): Promise<void>;

  // Export ----------------------------------------------------------------
  exportLeads(filters: LeadFilters): Promise<Lead[]>;
}

export const SORT_FIELD_TO_COLUMN: Record<SortField, string> = {
  created_at: 'created_at',
  name: 'name',
  phone: 'phone',
  lead_status: 'lead_status',
  assigned_to: 'assigned_to',
  last_call_at: 'last_call_at',
  next_follow_up_at: 'next_follow_up_at',
  updated_at: 'updated_at',
};
