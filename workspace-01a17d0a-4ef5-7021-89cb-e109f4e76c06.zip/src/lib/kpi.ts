import type { DashboardSummary, Lead, LeadStatus } from '@/types/domain';
import { LEAD_STATUSES } from './constants';

const EMPTY_BY_STATUS = (): Record<LeadStatus, number> =>
  Object.fromEntries(LEAD_STATUSES.map((s) => [s.value, 0])) as Record<LeadStatus, number>;

export function isSameLocalDay(iso: string | null | undefined, ref = new Date()): boolean {
  if (!iso) return false;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return false;
  return (
    d.getFullYear() === ref.getFullYear() &&
    d.getMonth() === ref.getMonth() &&
    d.getDate() === ref.getDate()
  );
}

export function isOverdue(iso: string | null | undefined, ref = new Date()): boolean {
  if (!iso) return false;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return false;
  const endOfToday = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate(), 23, 59, 59, 999);
  return d.getTime() < endOfToday.getTime() && !isSameLocalDay(iso, ref);
}

/**
 * Computes dashboard KPIs from lead rows.
 *
 * Rules (mirrored by the `dashboard_summary` SQL function):
 *  - Every lead is counted exactly once, keyed by its unique internal id.
 *  - KPI tiles are mutually exclusive: a lead contributes to one status bucket.
 *  - Multiple call activities never inflate lead counts.
 */
export function computeSummary(leads: Lead[], callCountToday = 0, ref = new Date()): DashboardSummary {
  const seen = new Set<string>();
  const byStatus = EMPTY_BY_STATUS();
  let unassigned = 0;
  let callbacksDueToday = 0;
  let overdueFollowUps = 0;

  for (const lead of leads) {
    if (seen.has(lead.id)) continue;
    seen.add(lead.id);

    if (byStatus[lead.lead_status] === undefined) continue; // unknown status guarded
    byStatus[lead.lead_status] += 1;

    if (!lead.assigned_to) unassigned += 1;

    if (lead.lead_status === 'call_back' && isSameLocalDay(lead.next_follow_up_at, ref)) {
      callbacksDueToday += 1;
    }
    if (
      (lead.lead_status === 'follow_up_pending' || lead.lead_status === 'call_back') &&
      isOverdue(lead.next_follow_up_at, ref)
    ) {
      overdueFollowUps += 1;
    }
  }

  return {
    totalLeads: seen.size,
    byStatus,
    callsToday: callCountToday,
    callbacksDueToday,
    overdueFollowUps,
    unassigned,
  };
}

/** Value shown inside a KPI tile; totals never double count. */
export function kpiValue(summary: DashboardSummary, key: 'total' | LeadStatus): number {
  return key === 'total' ? summary.totalLeads : (summary.byStatus[key] ?? 0);
}

/** Leads that need a dial: never contacted, no answer, switched off. */
export function isPendingDial(status: LeadStatus): boolean {
  return status === 'not_dialed' || status === 'no_answer' || status === 'switched_off';
}

export function percentage(part: number, total: number): number {
  if (!total) return 0;
  return Math.round((part / total) * 1000) / 10;
}
