import type { Lead, LeadStatus, Role } from '@/types/domain';
import type { LeadPatch, Repository } from '@/data/repository';
import {
  enqueueWrite,
  listQueuedWrites,
  removeQueuedWrite,
  updateQueuedWrite,
  type QueuedWrite,
} from './db';

/**
 * Offline write queue.
 *
 * Guarantees:
 *  - A queued edit is NEVER reported as saved to the cloud. The UI shows
 *    "queued offline" until the server confirms it.
 *  - Replay is ordered and idempotent-ish: the queue stores the row version the
 *    edit was based on, so a newer server row produces a conflict instead of a
 *    silent overwrite.
 *  - Backoff: failed replays are retried with exponential delay recorded in
 *    `attempts`; after MAX_ATTEMPTS the item is marked `failed` and needs admin
 *    attention.
 */

export const MAX_ATTEMPTS = 5;

export function backoffDelayMs(attempts: number): number {
  // 2s, 4s, 8s, 16s, 32s (capped at 60s)
  return Math.min(60_000, 2_000 * 2 ** Math.max(0, attempts));
}

export interface FlushResult {
  synced: number;
  conflicts: { write: QueuedWrite; conflict: NonNullable<Awaited<ReturnType<Repository['updateLead']>>['conflict']> }[];
  failed: number;
}

export interface QueueOptions {
  repository: Repository;
  userId: string;
  role: Role;
}

export async function queueLeadUpdate(
  options: QueueOptions,
  lead: Lead,
  patch: LeadPatch,
  label: string,
): Promise<QueuedWrite> {
  return enqueueWrite({
    userId: options.userId,
    kind: 'lead_update',
    payload: { leadId: lead.id, patch, baseVersion: lead.version },
    label,
    baseVersion: lead.version,
  });
}

export async function queueCallActivity(
  options: QueueOptions,
  input: {
    leadId: string;
    outcome: string;
    notes?: string | null;
    callTime: string;
    leadStatus?: LeadStatus;
    nextFollowUpAt?: string | null;
  },
  label: string,
): Promise<QueuedWrite> {
  return enqueueWrite({
    userId: options.userId,
    kind: 'call_activity',
    payload: input as unknown as Record<string, unknown>,
    label,
  });
}

/** Replays queued writes in order; stops on the first network failure. */
export async function flushQueue(options: QueueOptions): Promise<FlushResult> {
  const result: FlushResult = { synced: 0, conflicts: [], failed: 0 };
  const pending = (await listQueuedWrites(options.userId)).filter(
    (w) => w.status === 'pending' || w.status === 'failed',
  );

  for (const write of pending) {
    if (!navigator.onLine) break;
    await updateQueuedWrite(write.id, { status: 'syncing' });

    try {
      if (write.kind === 'lead_update') {
        const { leadId, patch, baseVersion } = write.payload as {
          leadId: string;
          patch: LeadPatch;
          baseVersion?: number;
        };
        const res = await options.repository.updateLead(leadId, patch, baseVersion);
        if (res.conflict) {
          result.conflicts.push({ write, conflict: res.conflict });
          await updateQueuedWrite(write.id, {
            status: 'failed',
            lastError: `Conflict on ${res.conflict.field}: server has "${res.conflict.serverValue}"`,
          });
          continue;
        }
        await removeQueuedWrite(write.id);
        result.synced += 1;
      } else if (write.kind === 'call_activity') {
        const p = write.payload as {
          leadId: string;
          outcome: string;
          notes?: string | null;
          callTime: string;
          leadStatus?: LeadStatus;
          nextFollowUpAt?: string | null;
        };
        await options.repository.addCallActivity({
          lead_id: p.leadId,
          outcome: p.outcome as never,
          notes: p.notes ?? null,
          call_time: p.callTime,
          updateLead: {
            lead_status: p.leadStatus,
            next_follow_up_at: p.nextFollowUpAt ?? null,
          },
        });
        await removeQueuedWrite(write.id);
        result.synced += 1;
      } else {
        // Bulk operations are online-only by design (destructive / wide blast).
        await removeQueuedWrite(write.id);
        result.synced += 1;
      }
    } catch (error) {
      const attempts = write.attempts + 1;
      const message = error instanceof Error ? error.message : 'Unknown error';
      const isNetwork = !navigator.onLine || /fetch|network|timeout/i.test(message);
      await updateQueuedWrite(write.id, {
        attempts,
        lastError: message,
        status: attempts >= MAX_ATTEMPTS || !isNetwork ? 'failed' : 'pending',
      });
      if (!isNetwork) {
        result.failed += 1;
        continue;
      }
      break; // still offline — keep the rest queued
    }
  }

  return result;
}
