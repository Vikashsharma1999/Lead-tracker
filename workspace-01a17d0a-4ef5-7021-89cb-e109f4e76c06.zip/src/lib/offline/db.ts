import { openDB, type DBSchema, type IDBPDatabase } from 'idb';

/**
 * IndexedDB store for offline queued writes.
 *
 * Privacy: every record is namespaced by the signed-in user id and the queue
 * is wiped on sign-out, so a shared device never shows another user's data.
 * No credentials, tokens or service keys are ever stored here.
 */

export type QueuedKind = 'lead_update' | 'call_activity' | 'bulk_assign';

export interface QueuedWrite {
  id: string;
  userId: string;
  kind: QueuedKind;
  /** Payload needed to replay the request once back online. */
  payload: Record<string, unknown>;
  /** Human label for the pending-changes panel. */
  label: string;
  createdAt: string;
  attempts: number;
  lastError: string | null;
  status: 'pending' | 'syncing' | 'failed';
  /** Version of the server row when the edit was queued (conflict detection). */
  baseVersion?: number;
}

interface LeadTrackerDB extends DBSchema {
  queued_writes: {
    key: string;
    value: QueuedWrite;
    indexes: { 'by-user': string; 'by-created': string };
  };
  meta: { key: string; value: { key: string; value: unknown } };
}

const DB_NAME = 'lead-tracker-offline';
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<LeadTrackerDB>> | null = null;

function db(): Promise<IDBPDatabase<LeadTrackerDB>> {
  if (!dbPromise) {
    dbPromise = openDB<LeadTrackerDB>(DB_NAME, DB_VERSION, {
      upgrade(database) {
        const store = database.createObjectStore('queued_writes', { keyPath: 'id' });
        store.createIndex('by-user', 'userId');
        store.createIndex('by-created', 'createdAt');
        database.createObjectStore('meta', { keyPath: 'key' });
      },
    });
  }
  return dbPromise;
}

export async function enqueueWrite(
  input: Omit<QueuedWrite, 'id' | 'createdAt' | 'attempts' | 'lastError' | 'status'>,
): Promise<QueuedWrite> {
  const record: QueuedWrite = {
    ...input,
    id: globalThis.crypto?.randomUUID?.() ?? `q-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    createdAt: new Date().toISOString(),
    attempts: 0,
    lastError: null,
    status: 'pending',
  };
  const database = await db();
  await database.put('queued_writes', record);
  return record;
}

export async function listQueuedWrites(userId: string): Promise<QueuedWrite[]> {
  const database = await db();
  const rows = await database.getAllFromIndex('queued_writes', 'by-user', userId);
  return rows.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function updateQueuedWrite(id: string, patch: Partial<QueuedWrite>): Promise<void> {
  const database = await db();
  const existing = await database.get('queued_writes', id);
  if (!existing) return;
  await database.put('queued_writes', { ...existing, ...patch });
}

export async function removeQueuedWrite(id: string): Promise<void> {
  const database = await db();
  await database.delete('queued_writes', id);
}

/** Removes all locally cached data for a user (called on sign-out). */
export async function clearUserOfflineData(userId: string): Promise<void> {
  const database = await db();
  const tx = database.transaction('queued_writes', 'readwrite');
  const index = tx.store.index('by-user');
  for await (const cursor of index.iterate(userId)) {
    await cursor.delete();
  }
  await tx.done;
}

export async function setMeta(key: string, value: unknown): Promise<void> {
  const database = await db();
  await database.put('meta', { key, value });
}

export async function getMeta<T>(key: string): Promise<T | null> {
  const database = await db();
  const row = await database.get('meta', key);
  return (row?.value as T) ?? null;
}
