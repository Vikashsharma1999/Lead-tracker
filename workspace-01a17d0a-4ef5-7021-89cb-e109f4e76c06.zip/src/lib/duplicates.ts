import type { Lead } from '@/types/domain';

/**
 * Normalisation helpers for duplicate detection.
 *
 * Duplicate handling is configurable per source
 * (data_sources.configuration.duplicate_policy):
 *   - 'skip'    : keep the existing lead, count the row as skipped
 *   - 'update'  : merge into the existing lead (default)
 *   - 'create'  : allow a second lead (rare; requires admin opt-in)
 */

export type DuplicatePolicy = 'skip' | 'update' | 'create';

export interface DuplicateCandidate {
  name?: string | null;
  phone?: string | null;
  email?: string | null;
}

export interface DuplicateMatch {
  key: 'phone' | 'email' | 'name+phone';
  existing: Lead;
  incoming: DuplicateCandidate;
}

/**
 * Canonical phone key used for duplicate detection (and mirrored by the
 * `normalize_phone` SQL function so client previews match server matching).
 *
 * Steps: keep digits → drop a leading `00` international prefix → drop a known
 * country code when what remains is a plausible national number → drop trunk
 * zeros. This makes "+971 50 123 4567", "00971501234567" and "050 123 4567"
 * compare equal without inventing digits that were not there.
 */
const COUNTRY_CODES = [
  '971', '966', '974', '973', '968', '965', '962', '961', '963', '964', '880', '234',
  '254', '255', '256', '233', '44', '20', '27', '61', '65', '60', '62', '63', '66',
  '91', '92', '94', '1',
].sort((a, b) => b.length - a.length);

export function normalizePhone(input: string | null | undefined): string {
  if (!input) return '';
  let digits = String(input).replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('00')) digits = digits.slice(2);
  for (const code of COUNTRY_CODES) {
    if (digits.startsWith(code)) {
      const rest = digits.slice(code.length);
      if (rest.length >= 7 && rest.length <= 10) {
        digits = rest;
        break;
      }
    }
  }
  return digits.replace(/^0+/, '');
}

export function normalizeEmail(input: string | null | undefined): string {
  return String(input ?? '').trim().toLowerCase();
}

export function normalizeName(input: string | null | undefined): string {
  return String(input ?? '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

export interface DuplicateIndex {
  byPhone: Map<string, Lead>;
  byEmail: Map<string, Lead>;
  byNamePhone: Map<string, Lead>;
}

export function buildDuplicateIndex(leads: Lead[]): DuplicateIndex {
  const byPhone = new Map<string, Lead>();
  const byEmail = new Map<string, Lead>();
  const byNamePhone = new Map<string, Lead>();
  for (const lead of leads) {
    const phone = normalizePhone(lead.phone);
    const email = normalizeEmail(lead.email);
    const name = normalizeName(lead.name);
    if (phone && !byPhone.has(phone)) byPhone.set(phone, lead);
    if (email && !byEmail.has(email)) byEmail.set(email, lead);
    if (phone && name) {
      const key = `${name}|${phone}`;
      if (!byNamePhone.has(key)) byNamePhone.set(key, lead);
    }
  }
  return { byPhone, byEmail, byNamePhone };
}

/** Finds the strongest duplicate match for an incoming row. */
export function findDuplicate(
  index: DuplicateIndex,
  candidate: DuplicateCandidate,
  options: { requireEmailMatch?: boolean } = {},
): DuplicateMatch | null {
  const phone = normalizePhone(candidate.phone);
  const email = normalizeEmail(candidate.email);
  const name = normalizeName(candidate.name);

  if (email) {
    const hit = index.byEmail.get(email);
    if (hit) return { key: 'email', existing: hit, incoming: candidate };
  }
  if (phone) {
    const hit = index.byPhone.get(phone);
    if (hit) return { key: 'phone', existing: hit, incoming: candidate };
    if (name) {
      const hitName = index.byNamePhone.get(`${name}|${phone}`);
      if (hitName) return { key: 'name+phone', existing: hitName, incoming: candidate };
    }
  }
  if (options.requireEmailMatch) return null;
  return null;
}

export interface DuplicateDecision<T> {
  action: 'insert' | 'update' | 'skip';
  existingId?: string;
  row: T;
  reason?: string;
}

/** Applies a duplicate policy to a batch of incoming rows (idempotent import). */
export function planDuplicateHandling<T extends DuplicateCandidate>(
  index: DuplicateIndex,
  rows: T[],
  policy: DuplicatePolicy,
): DuplicateDecision<T>[] {
  return rows.map((row) => {
    const match = findDuplicate(index, row);
    if (!match) return { action: 'insert', row };
    if (policy === 'create') return { action: 'insert', row, reason: 'policy:create' };
    if (policy === 'skip') {
      return { action: 'skip', row, existingId: match.existing.id, reason: `duplicate:${match.key}` };
    }
    return { action: 'update', row, existingId: match.existing.id, reason: `duplicate:${match.key}` };
  });
}
