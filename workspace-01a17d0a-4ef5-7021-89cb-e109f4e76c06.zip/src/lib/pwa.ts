import { registerSW } from 'virtual:pwa-register';

/**
 * Service worker registration.
 *
 * - App shell is precached for offline start.
 * - API/Supabase requests are NetworkOnly (never cached).
 * - Updates are surfaced to the user; we never silently swap code mid-session.
 */
export function registerPWA(): void {
  if (!('serviceWorker' in navigator) || import.meta.env.DEV) return;

  const updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      window.dispatchEvent(new CustomEvent('ltd:pwa-update-available', { detail: { updateSW } }));
    },
    onOfflineReady() {
      window.dispatchEvent(new CustomEvent('ltd:pwa-offline-ready'));
    },
  });
}
