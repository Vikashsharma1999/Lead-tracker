import * as XLSX from 'xlsx';
import type { DataSource, Lead, LeadStatus, Profile } from '@/types/domain';
import { STATUS_MAP } from './constants';

/**
 * Spreadsheet import/export utilities.
 *
 * SheetJS (xlsx 0.20.3, official CDN build) handles .xlsx, .xls and .csv in the
 * browser. Parsing happens client-side for preview + column mapping; the actual
 * write is a server call (Phase 3), so no file ever bypasses validation.
 */

export type InternalField =
  | 'name'
  | 'phone'
  | 'email'
  | 'lead_status'
  | 'lead_outcome'
  | 'assigned_caller'
  | 'last_call_at'
  | 'next_follow_up_at'
  | 'notes'
  | 'source_record_id';

export interface FieldDef {
  key: InternalField;
  label: string;
  required?: boolean;
  /** Header aliases used for automatic column mapping (normalised, lowercase). */
  aliases: string[];
}

export const INTERNAL_FIELDS: FieldDef[] = [
  { key: 'name', label: 'Full name', required: true, aliases: ['name', 'full name', 'lead name', 'contact', 'contact name', 'customer'] },
  { key: 'phone', label: 'Mobile number', required: true, aliases: ['mobile', 'phone', 'phone number', 'mobile number', 'contact number', 'whatsapp'] },
  { key: 'email', label: 'Email', aliases: ['email', 'e-mail', 'email address', 'mail'] },
  { key: 'lead_status', label: 'Lead status', aliases: ['status', 'lead status', 'call status', 'stage', 'disposition'] },
  { key: 'lead_outcome', label: 'Lead outcome', aliases: ['outcome', 'lead outcome', 'result'] },
  { key: 'assigned_caller', label: 'Assigned caller', aliases: ['assigned to', 'assigned caller', 'caller', 'owner', 'agent', 'telecaller'] },
  { key: 'last_call_at', label: 'Last call date', aliases: ['last call', 'last call date', 'last called', 'last contact'] },
  { key: 'next_follow_up_at', label: 'Next follow-up date', aliases: ['follow up', 'follow-up', 'follow up date', 'next follow up', 'callback date', 'next follow-up date'] },
  { key: 'notes', label: 'Notes', aliases: ['notes', 'remarks', 'comments', 'comment', 'note'] },
  { key: 'source_record_id', label: 'Source row ID', aliases: ['row id', 'id', 'lead id', 'sr no', 's.no', 'serial', 'row number'] },
];

export function normalizeHeader(header: string): string {
  return header
    .toString()
    .trim()
    .toLowerCase()
    .replace(/[_\-.]/g, ' ')
    .replace(/[^a-z0-9 ]/g, '')
    .replace(/\s+/g, ' ');
}

/** Maps spreadsheet headers to internal fields using aliases + fuzzy contains. */
export function autoMapColumns(headers: string[]): Partial<Record<InternalField, string>> {
  const normalized = headers.map((h) => ({ raw: h, norm: normalizeHeader(h) }));
  const mapping: Partial<Record<InternalField, string>> = {};
  const used = new Set<string>();

  for (const field of INTERNAL_FIELDS) {
    const exact = normalized.find((h) => !used.has(h.raw) && field.aliases.includes(h.norm));
    if (exact) {
      mapping[field.key] = exact.raw;
      used.add(exact.raw);
      continue;
    }
    const partial = normalized.find(
      (h) => !used.has(h.raw) && field.aliases.some((alias) => h.norm.includes(alias) || alias.includes(h.norm)),
    );
    if (partial && partial.norm.length > 1) {
      mapping[field.key] = partial.raw;
      used.add(partial.raw);
    }
  }
  return mapping;
}

export interface ParsedSheet {
  name: string;
  headers: string[];
  rows: Record<string, unknown>[];
  rowCount: number;
}

export interface ParsedWorkbook {
  fileName: string;
  sheets: ParsedSheet[];
}

/** Parses .xlsx / .xls / .csv into per-sheet headers + rows. */
export async function parseSpreadsheetFile(file: File): Promise<ParsedWorkbook> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true, raw: false });
  const sheets: ParsedSheet[] = workbook.SheetNames.map((name) => {
    const sheet = workbook.Sheets[name];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
      defval: '',
      raw: false,
      blankrows: false,
    });
    const headers =
      rows.length > 0
        ? Object.keys(rows[0])
        : (XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1 })[0] ?? []).map(String);
    return { name, headers, rows, rowCount: rows.length };
  });
  return { fileName: file.name, sheets };
}

export interface MappedRow {
  name: string;
  phone: string;
  email: string | null;
  lead_status: LeadStatus;
  lead_outcome: string;
  assigned_caller: string | null;
  last_call_at: string | null;
  next_follow_up_at: string | null;
  notes: string | null;
  source_record_id: string | null;
  /** 1-based row index in the original sheet (header is row 1). */
  rowNumber: number;
  errors: string[];
}

const STATUS_ALIASES: Record<string, LeadStatus> = Object.fromEntries(
  Object.values(STATUS_MAP).flatMap((meta) => [
    [normalizeHeader(meta.label), meta.value],
    [normalizeHeader(meta.value), meta.value],
  ]),
) as Record<string, LeadStatus>;

export function parseStatus(value: unknown): LeadStatus {
  const key = normalizeHeader(String(value ?? ''));
  return STATUS_ALIASES[key] ?? 'not_dialed';
}

function asIsoDate(value: unknown): string | null {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString();
  const str = String(value).trim();
  if (!str) return null;
  // Excel serial numbers
  if (/^\d{5}$/.test(str)) {
    const parsed = XLSX.SSF.parse_date_code(Number(str));
    if (parsed) {
      return new Date(Date.UTC(parsed.y, parsed.m - 1, parsed.d)).toISOString();
    }
  }
  const direct = new Date(str);
  return Number.isNaN(direct.getTime()) ? null : direct.toISOString();
}

/** Applies a column mapping, validates required fields, returns per-row errors. */
export function mapRows(
  rows: Record<string, unknown>[],
  mapping: Partial<Record<InternalField, string>>,
): MappedRow[] {
  return rows.map((row, index) => {
    const get = (field: InternalField): unknown => {
      const header = mapping[field];
      return header ? row[header] : undefined;
    };
    const errors: string[] = [];
    const name = String(get('name') ?? '').trim();
    const phone = String(get('phone') ?? '').trim();

    if (!name) errors.push('Name is required');
    if (!phone) errors.push('Mobile number is required');
    if (phone && !/^[+\d][\d\s\-()]{5,}$/.test(phone)) errors.push('Mobile number looks invalid');

    const emailRaw = String(get('email') ?? '').trim();
    if (emailRaw && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailRaw)) errors.push('Email looks invalid');

    return {
      name,
      phone,
      email: emailRaw || null,
      lead_status: parseStatus(get('lead_status')),
      lead_outcome: String(get('lead_outcome') ?? 'pending').trim().toLowerCase() || 'pending',
      assigned_caller: String(get('assigned_caller') ?? '').trim() || null,
      last_call_at: asIsoDate(get('last_call_at')),
      next_follow_up_at: asIsoDate(get('next_follow_up_at')),
      notes: String(get('notes') ?? '').trim() || null,
      source_record_id: String(get('source_record_id') ?? '').trim() || `row-${index + 2}`,
      rowNumber: index + 2,
      errors,
    };
  });
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

export interface ExportContext {
  profiles?: Profile[];
  sources?: DataSource[];
}

export interface LeadExportRow {
  'Lead ID': string;
  Date: string;
  Name: string;
  'Mobile Number': string;
  Email: string;
  'Source Spreadsheet': string;
  Worksheet: string;
  'Source Row': string;
  'Assigned Caller': string;
  'Call Status': string;
  'Lead Outcome': string;
  'Last Call Date': string;
  'Next Follow-up Date': string;
  Notes: string;
  'Last Updated': string;
}

function fmt(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 19).replace('T', ' ');
}

export function leadsToExportRows(leads: Lead[], context: ExportContext = {}): LeadExportRow[] {
  const callerMap = new Map((context.profiles ?? []).map((p) => [p.id, p.full_name]));
  const sourceMap = new Map((context.sources ?? []).map((s) => [s.id, s.name]));

  return leads.map((lead) => ({
    'Lead ID': lead.id,
    Date: fmt(lead.created_at),
    Name: lead.name,
    'Mobile Number': lead.phone,
    Email: lead.email ?? '',
    'Source Spreadsheet': lead.source_id ? (sourceMap.get(lead.source_id) ?? '') : '',
    Worksheet: lead.source_sheet_name ?? '',
    'Source Row': lead.source_record_id ?? '',
    'Assigned Caller': lead.assigned_to ? (callerMap.get(lead.assigned_to) ?? '') : 'Unassigned',
    'Call Status': STATUS_MAP[lead.lead_status]?.label ?? lead.lead_status,
    'Lead Outcome': lead.lead_outcome,
    'Last Call Date': fmt(lead.last_call_at),
    'Next Follow-up Date': fmt(lead.next_follow_up_at),
    Notes: lead.notes ?? '',
    'Last Updated': fmt(lead.updated_at),
  }));
}

function download(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function timestamp(): string {
  return new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
}

/** Builds an .xlsx workbook from leads (also used by tests). */
export function buildLeadWorkbook(leads: Lead[], context: ExportContext = {}): XLSX.WorkBook {
  const rows = leadsToExportRows(leads, context);
  const worksheet = XLSX.utils.json_to_sheet(rows);
  worksheet['!cols'] = [
    { wch: 38 }, { wch: 19 }, { wch: 22 }, { wch: 16 }, { wch: 26 }, { wch: 24 },
    { wch: 14 }, { wch: 10 }, { wch: 18 }, { wch: 18 }, { wch: 14 }, { wch: 19 },
    { wch: 19 }, { wch: 40 }, { wch: 19 },
  ];
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Leads');
  return workbook;
}

export function exportLeadsToExcel(leads: Lead[], context: ExportContext = {}, prefix = 'leads'): void {
  const workbook = buildLeadWorkbook(leads, context);
  const data = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' }) as ArrayBuffer;
  download(
    new Blob([data], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    }),
    `${prefix}-${timestamp()}.xlsx`,
  );
}

/** RFC 4180-safe CSV (quotes, newlines, UTF-8 BOM for Excel). */
export function buildCsv(leads: Lead[], context: ExportContext = {}): string {
  const rows = leadsToExportRows(leads, context);
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]) as (keyof LeadExportRow)[];
  const escape = (value: unknown): string => {
    const str = String(value ?? '');
    return /[",\n\r]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
  };
  const lines = [headers.join(','), ...rows.map((row) => headers.map((h) => escape(row[h])).join(','))];
  return `\uFEFF${lines.join('\r\n')}`;
}

export function exportLeadsToCsv(leads: Lead[], context: ExportContext = {}, prefix = 'leads'): void {
  download(new Blob([buildCsv(leads, context)], { type: 'text/csv;charset=utf-8;' }), `${prefix}-${timestamp()}.csv`);
}
