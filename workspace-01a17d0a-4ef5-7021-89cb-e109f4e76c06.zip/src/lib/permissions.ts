import type { Lead, Profile, Role } from '@/types/domain';
import { CALLER_EDITABLE_FIELDS } from './constants';

/**
 * Client-side permission map.
 *
 * IMPORTANT: this is a UX convenience only. Every rule here is duplicated in
 * Postgres Row Level Security policies + trigger-based column guards
 * (supabase/migrations/*_rls.sql). The client must never be trusted.
 */

export type Permission =
  | 'leads.view_all'
  | 'leads.view_assigned'
  | 'leads.edit_all_fields'
  | 'leads.edit_call_fields'
  | 'leads.assign'
  | 'leads.delete'
  | 'leads.bulk_update'
  | 'leads.import'
  | 'leads.export'
  | 'sources.manage'
  | 'sources.sync'
  | 'users.manage'
  | 'statuses.manage'
  | 'audit.view'
  | 'reports.view_all'
  | 'reports.view_own'
  | 'conflicts.resolve'
  | 'settings.manage';

const ADMIN_PERMISSIONS: Permission[] = [
  'leads.view_all',
  'leads.edit_all_fields',
  'leads.assign',
  'leads.delete',
  'leads.bulk_update',
  'leads.import',
  'leads.export',
  'sources.manage',
  'sources.sync',
  'users.manage',
  'statuses.manage',
  'audit.view',
  'reports.view_all',
  'conflicts.resolve',
  'settings.manage',
];

const CALLER_PERMISSIONS: Permission[] = [
  'leads.view_assigned',
  'leads.edit_call_fields',
  'leads.export',
  'reports.view_own',
];

export function permissionsFor(role: Role | null | undefined): Set<Permission> {
  if (!role) return new Set();
  return new Set(role === 'admin' ? ADMIN_PERMISSIONS : CALLER_PERMISSIONS);
}

export function can(role: Role | null | undefined, permission: Permission): boolean {
  return permissionsFor(role).has(permission);
}

/** Which lead fields this role may write. */
export function editableFields(role: Role | null | undefined): readonly string[] {
  if (role === 'admin') {
    return [
      'name',
      'phone',
      'email',
      'lead_status',
      'lead_outcome',
      'assigned_to',
      'last_call_at',
      'next_follow_up_at',
      'notes',
    ];
  }
  if (role === 'caller') return CALLER_EDITABLE_FIELDS;
  return [];
}

/**
 * Returns the subset of `patch` the role is allowed to persist. Used to build
 * upload payloads; the database enforces the same rules again.
 */
export function sanitizeLeadPatch<T extends Record<string, unknown>>(
  role: Role | null | undefined,
  patch: T,
): Partial<T> {
  const allowed = new Set(editableFields(role));
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(patch)) {
    if (allowed.has(key)) out[key] = value;
  }
  return out as Partial<T>;
}

/** A caller may only open a lead that is assigned to them. */
export function canAccessLead(profile: Profile | null, lead: Lead): boolean {
  if (!profile) return false;
  if (profile.role === 'admin') return true;
  return lead.assigned_to === profile.id;
}

/** Only admins may grant admin. Nobody may self-elevate. */
export function canChangeRole(actor: Profile | null, targetId: string, nextRole: Role): boolean {
  if (!actor || actor.role !== 'admin') return false;
  if (actor.id === targetId && nextRole !== 'admin') {
    // Prevent an admin locking themselves out accidentally.
    return false;
  }
  return true;
}
