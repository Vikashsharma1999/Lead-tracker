import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { isSupabaseConfigured, supabaseAnonKey, supabaseUrl } from './env';

/**
 * Browser Supabase client.
 *
 * Only the anon (publishable) key is used here. All authorisation is enforced
 * by Row Level Security in Postgres; the service-role key never reaches the
 * browser. Sessions persist in localStorage by default so the PWA can keep the
 * user signed in, and tokens auto-refresh in the background.
 */
let client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (!isSupabaseConfigured) {
    throw new Error(
      'Supabase is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY, or use demo mode.',
    );
  }
  if (!client) {
    client = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: 'pkce',
        storageKey: 'ltd.auth.session',
      },
      realtime: { params: { eventsPerSecond: 5 } },
      global: { headers: { 'x-application-name': 'lead-tracker-dashboard' } },
    });
  }
  return client;
}

export const supabaseEnabled = isSupabaseConfigured;
