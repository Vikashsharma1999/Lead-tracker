/**
 * Environment access + runtime mode detection.
 *
 * The app runs in one of two clearly separated modes:
 *
 *  - `live`  : a real Supabase project is configured. All data comes from
 *              Postgres through RLS-protected queries, auth is real, and
 *              integrations are performed by server-side Edge Functions.
 *  - `demo`  : no Supabase credentials were supplied (or VITE_DEMO_MODE=true).
 *              The app uses a local sample-data repository in IndexedDB/
 *              localStorage. It is labelled "Demo data" everywhere and no
 *              integration ever reports a connected state.
 *
 * Integrations (Google Sheets, Microsoft Graph) additionally require their own
 * server-side credentials. `integrationsConfigured` only reflects the public
 * signal the server exposes; it is never inferred from the client bundle.
 */

const raw = import.meta.env;

function clean(value: string | undefined): string {
  const v = (value ?? '').trim();
  if (!v) return '';
  // Treat the obvious placeholders from .env.example as "not configured".
  if (/YOUR[-_]|CHANGE[-_]ME|abc123|example\.com\/YOUR/i.test(v)) return '';
  return v;
}

export const supabaseUrl = clean(raw.VITE_SUPABASE_URL as string | undefined);
export const supabaseAnonKey = clean(raw.VITE_SUPABASE_ANON_KEY as string | undefined);
export const appName = (raw.VITE_APP_NAME as string | undefined)?.trim() || 'Lead Tracker Dashboard';
export const supportEmail = (raw.VITE_SUPPORT_EMAIL as string | undefined)?.trim() || '';

const forcedDemo = String(raw.VITE_DEMO_MODE ?? '').toLowerCase() === 'true';

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey && !forcedDemo);
export const isDemoMode = !isSupabaseConfigured;
export const appMode: 'live' | 'demo' = isDemoMode ? 'demo' : 'live';

/** Public description of the integration state shown in the UI. */
export interface IntegrationAvailability {
  googleSheets: 'server_unconfigured' | 'ready';
  microsoftGraph: 'server_unconfigured' | 'ready';
}

/**
 * The client deliberately does not try to guess whether server credentials
 * exist. It asks the server (`data_sources` / health endpoint) at runtime.
 * These defaults keep the "not configured" copy honest until then.
 */
export const initialIntegrationAvailability: IntegrationAvailability = {
  googleSheets: 'server_unconfigured',
  microsoftGraph: 'server_unconfigured',
};
