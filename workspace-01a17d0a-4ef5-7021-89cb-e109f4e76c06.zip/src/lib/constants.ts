import type { LeadOutcome, LeadStatus, Role } from '@/types/domain';

export interface StatusMeta {
  value: LeadStatus;
  label: string;
  /** Hex colour used by the pie chart and status chips. */
  color: string;
  /** Tailwind classes for chips (bg / text / ring). */
  chip: string;
  /** Statuses that represent "no conversation happened yet". */
  countsAsDialed: boolean;
  description: string;
}

/**
 * Initial configurable statuses. In production the admin-editable list is
 * stored in `lead_statuses` (Phase 2 migration) and this array is the seed;
 * the UI reads from the repository so admins can relabel/re-colour statuses.
 */
export const LEAD_STATUSES: StatusMeta[] = [
  {
    value: 'not_dialed',
    label: 'Not Dialed',
    color: '#94a3b8',
    chip: 'bg-slate-100 text-slate-700 ring-slate-200',
    countsAsDialed: false,
    description: 'Lead imported, no call attempt recorded yet.',
  },
  {
    value: 'dialed',
    label: 'Dialed',
    color: '#3b82f6',
    chip: 'bg-blue-50 text-blue-700 ring-blue-200',
    countsAsDialed: true,
    description: 'Number dialled; call in progress or outcome not captured.',
  },
  {
    value: 'interested',
    label: 'Interested',
    color: '#22c55e',
    chip: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    countsAsDialed: true,
    description: 'Lead expressed interest in the offer or webinar.',
  },
  {
    value: 'not_interested',
    label: 'Not Interested',
    color: '#ef4444',
    chip: 'bg-red-50 text-red-700 ring-red-200',
    countsAsDialed: true,
    description: 'Lead declined; do not re-contact unless requested.',
  },
  {
    value: 'call_back',
    label: 'Call Back',
    color: '#f59e0b',
    chip: 'bg-amber-50 text-amber-700 ring-amber-200',
    countsAsDialed: true,
    description: 'Lead asked to be contacted again at a specific time.',
  },
  {
    value: 'webinar_link_shared',
    label: 'Webinar Link Shared',
    color: '#8b5cf6',
    chip: 'bg-violet-50 text-violet-700 ring-violet-200',
    countsAsDialed: true,
    description: 'Webinar registration link sent to the lead.',
  },
  {
    value: 'follow_up_pending',
    label: 'Follow-up Pending',
    color: '#06b6d4',
    chip: 'bg-cyan-50 text-cyan-700 ring-cyan-200',
    countsAsDialed: true,
    description: 'Awaiting a scheduled follow-up action.',
  },
  {
    value: 'bad_timing',
    label: 'Bad Timing',
    color: '#a855f7',
    chip: 'bg-purple-50 text-purple-700 ring-purple-200',
    countsAsDialed: true,
    description: 'Reachable but asked for contact later.',
  },
  {
    value: 'switched_off',
    label: 'Switched Off',
    color: '#64748b',
    chip: 'bg-slate-100 text-slate-600 ring-slate-200',
    countsAsDialed: true,
    description: 'Phone switched off when dialled.',
  },
  {
    value: 'no_answer',
    label: 'No Answer',
    color: '#f97316',
    chip: 'bg-orange-50 text-orange-700 ring-orange-200',
    countsAsDialed: true,
    description: 'Rang but nobody answered.',
  },
];

export const STATUS_MAP: Record<LeadStatus, StatusMeta> = Object.fromEntries(
  LEAD_STATUSES.map((s) => [s.value, s]),
) as Record<LeadStatus, StatusMeta>;

export const LEAD_OUTCOMES: { value: LeadOutcome; label: string; chip: string }[] = [
  { value: 'pending', label: 'Pending', chip: 'bg-slate-100 text-slate-600 ring-slate-200' },
  { value: 'positive', label: 'Positive', chip: 'bg-emerald-50 text-emerald-700 ring-emerald-200' },
  { value: 'neutral', label: 'Neutral', chip: 'bg-amber-50 text-amber-700 ring-amber-200' },
  { value: 'negative', label: 'Negative', chip: 'bg-red-50 text-red-700 ring-red-200' },
  { value: 'invalid', label: 'Invalid', chip: 'bg-zinc-100 text-zinc-600 ring-zinc-200' },
];

export const OUTCOME_MAP = Object.fromEntries(LEAD_OUTCOMES.map((o) => [o.value, o]));

/**
 * The seven KPI tiles required by the dashboard spec. Each tile maps to an
 * explicit, mutually exclusive status set so a lead is never counted twice.
 */
export const KPI_TILES: {
  key: 'total' | LeadStatus;
  label: string;
  statuses: LeadStatus[];
  accent: string;
  icon: 'users' | 'phone-off' | 'phone' | 'check' | 'x' | 'calendar' | 'link' | 'clock';
}[] = [
  { key: 'total', label: 'Total Leads', statuses: [], accent: 'text-slate-900', icon: 'users' },
  { key: 'not_dialed', label: 'Not Dialed', statuses: ['not_dialed'], accent: 'text-slate-600', icon: 'phone-off' },
  { key: 'dialed', label: 'Dialed', statuses: ['dialed'], accent: 'text-blue-600', icon: 'phone' },
  { key: 'interested', label: 'Interested', statuses: ['interested'], accent: 'text-emerald-600', icon: 'check' },
  { key: 'not_interested', label: 'Not Interested', statuses: ['not_interested'], accent: 'text-red-600', icon: 'x' },
  { key: 'call_back', label: 'Call Back', statuses: ['call_back'], accent: 'text-amber-600', icon: 'phone' },
  {
    key: 'webinar_link_shared',
    label: 'Webinar Link Shared',
    statuses: ['webinar_link_shared'],
    accent: 'text-violet-600',
    icon: 'link',
  },
  {
    key: 'follow_up_pending',
    label: 'Follow-up Pending',
    statuses: ['follow_up_pending'],
    accent: 'text-cyan-600',
    icon: 'clock',
  },
];

export const ROLE_LABELS: Record<Role, string> = {
  admin: 'Administrator',
  caller: 'Caller',
};

/** Fields a caller is allowed to write. Everything else is admin-only. */
export const CALLER_EDITABLE_FIELDS = [
  'lead_status',
  'lead_outcome',
  'notes',
  'last_call_at',
  'next_follow_up_at',
] as const;

export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];
export const DEFAULT_PAGE_SIZE = 25;
