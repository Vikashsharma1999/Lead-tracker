import { useCallback, useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useSearchParams } from 'react-router-dom';
import { CheckSquare, RefreshCw } from 'lucide-react';
import type { Lead, LeadFilters, LeadStatus, SortField, SortSpec } from '@/types/domain';
import { DEFAULT_PAGE_SIZE } from '@/lib/constants';
import { getRepository } from '@/data';
import { exportLeadsToCsv, exportLeadsToExcel } from '@/lib/excel';
import { useAuth } from '@/hooks/useAuth';
import {
  useBulkAssign,
  useBulkStatus,
  useDeleteLeads,
  useLeads,
  useProfiles,
  useSources,
} from '@/hooks/useLeads';
import { useToast } from '@/hooks/useToasts';
import { PageHeader } from '@/components/PageHeader';
import { FilterBar } from '@/components/FilterBar';
import { LeadTable } from '@/components/LeadTable';
import { Pagination } from '@/components/Pagination';
import { BulkActionBar } from '@/components/BulkActionBar';
import { ExportMenu } from '@/components/ExportMenu';
import { LeadEditor } from '@/components/LeadEditor';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { LEAD_STATUSES } from '@/lib/constants';

type PendingAction =
  | { type: 'delete'; leads: Lead[] }
  | { type: 'bulk-status'; leadIds: string[]; status: LeadStatus }
  | { type: 'bulk-assign'; leadIds: string[]; callerId: string | null }
  | null;

export function LeadsPage() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const queryClient = useQueryClient();
  const { push } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const initialStatus = searchParams.get('status');
  const [filters, setFilters] = useState<LeadFilters>(() => ({
    search: searchParams.get('q') ?? undefined,
    statuses: initialStatus && LEAD_STATUSES.some((s) => s.value === initialStatus)
      ? [initialStatus as LeadStatus]
      : undefined,
    assignedTo: searchParams.get('assigned') === 'unassigned' ? 'unassigned' : undefined,
  }));
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [sort, setSort] = useState<SortSpec>({ field: 'created_at', direction: 'desc' });
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [editing, setEditing] = useState<{ lead: Lead; mode: 'edit' | 'call' } | null>(null);
  const [pending, setPending] = useState<PendingAction>(null);
  const [exporting, setExporting] = useState(false);

  const profilesQuery = useProfiles();
  const sourcesQuery = useSources();
  const leadsQuery = useLeads(filters, { page, pageSize, sort });

  const bulkAssign = useBulkAssign();
  const bulkStatus = useBulkStatus();
  const deleteLeads = useDeleteLeads();

  // Reset selection when the visible page or filters change.
  useEffect(() => setSelected(new Set()), [filters, page, pageSize, sort]);
  useEffect(() => setPage(1), [filters, pageSize]);

  const updateFilters = useCallback(
    (patch: Partial<LeadFilters>) => {
      setFilters((current) => ({ ...current, ...patch }));
      const next = new URLSearchParams(searchParams);
      if (patch.statuses?.length === 1) next.set('status', patch.statuses[0]);
      else next.delete('status');
      if (patch.assignedTo === 'unassigned') next.set('assigned', 'unassigned');
      else next.delete('assigned');
      if (patch.search) next.set('q', patch.search);
      else next.delete('q');
      setSearchParams(next, { replace: true });
    },
    [searchParams, setSearchParams],
  );

  const resetFilters = () => {
    setFilters({});
    setSearchParams({}, { replace: true });
  };

  const handleSort = (field: SortField) =>
    setSort((current) =>
      current.field === field
        ? { field, direction: current.direction === 'asc' ? 'desc' : 'asc' }
        : { field, direction: 'asc' },
    );

  const rows = leadsQuery.data?.rows ?? [];
  const total = leadsQuery.data?.total ?? 0;

  const toggleRow = (id: string) =>
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const toggleAll = () =>
    setSelected((current) => {
      const allSelected = rows.every((r) => current.has(r.id));
      if (allSelected) {
        const next = new Set(current);
        rows.forEach((r) => next.delete(r.id));
        return next;
      }
      return new Set([...current, ...rows.map((r) => r.id)]);
    });

  const runExport = async (format: 'xlsx' | 'csv', explicit?: Lead[]) => {
    setExporting(true);
    try {
      const leads = explicit?.length ? explicit : await getRepository().exportLeads(filters);
      if (!leads.length) {
        push({ variant: 'warning', title: 'Nothing to export', description: 'No leads match the current filters.' });
        return;
      }
      const context = { profiles: profilesQuery.data ?? [], sources: sourcesQuery.data ?? [] };
      if (format === 'xlsx') exportLeadsToExcel(leads, context, 'leads-export');
      else exportLeadsToCsv(leads, context, 'leads-export');
      push({
        variant: 'success',
        title: `Exported ${leads.length} lead${leads.length === 1 ? '' : 's'}`,
        description: `Saved as ${format === 'xlsx' ? 'Excel' : 'CSV'} using the active filters.`,
      });
    } catch (error) {
      push({
        variant: 'error',
        title: 'Export failed',
        description: error instanceof Error ? error.message : 'Unknown error',
      });
    } finally {
      setExporting(false);
    }
  };

  const confirmAction = async () => {
    if (!pending) return;
    if (pending.type === 'delete') {
      await deleteLeads.mutateAsync(pending.leads.map((l) => l.id));
      setSelected(new Set());
    } else if (pending.type === 'bulk-status') {
      await bulkStatus.mutateAsync({ leadIds: pending.leadIds, status: pending.status });
      setSelected(new Set());
    } else if (pending.type === 'bulk-assign') {
      await bulkAssign.mutateAsync({ leadIds: pending.leadIds, callerId: pending.callerId });
      setSelected(new Set());
    }
    setPending(null);
  };

  const confirmCopy = useMemo(() => {
    if (!pending) return { title: '', message: '' };
    if (pending.type === 'delete') {
      return {
        title: `Delete ${pending.leads.length} lead${pending.leads.length === 1 ? '' : 's'}?`,
        message:
          'This permanently removes the selected lead records, their call activities and assignment history. The source spreadsheet is not modified. This cannot be undone.',
      };
    }
    if (pending.type === 'bulk-status') {
      return {
        title: 'Change status for selected leads?',
        message: `${pending.leadIds.length} lead(s) will be set to "${pending.status.replace(/_/g, ' ')}". This is recorded in the audit log and does not write back to the source sheet unless write-back is enabled.`,
      };
    }
    return {
      title: 'Reassign selected leads?',
      message: `${pending.leadIds.length} lead(s) will be reassigned. The previous assignment is kept in the assignment history.`,
    };
  }, [pending]);

  return (
    <div className="space-y-4">
      <PageHeader
        title={isAdmin ? 'All Leads' : 'My Leads'}
        subtitle={
          isAdmin
            ? 'Search, filter, edit and export every lead in the workspace'
            : 'Leads assigned to you — update status, outcomes and follow-ups'
        }
        meta={
          <>
            <span className="inline-flex items-center gap-1.5">
              <CheckSquare className="h-3.5 w-3.5" aria-hidden />
              {total.toLocaleString()} record{total === 1 ? '' : 's'} match your filters
            </span>
            {selected.size > 0 && <span>{selected.size} selected</span>}
          </>
        }
        actions={
          <>
            <button
              type="button"
              className="btn-light"
              onClick={() => void queryClient.invalidateQueries({ queryKey: ['leads'] })}
            >
              <RefreshCw className={`h-4 w-4 ${leadsQuery.isFetching ? 'animate-spin' : ''}`} aria-hidden />
              Refresh
            </button>
            <ExportMenu
              onExportExcel={() => void runExport('xlsx')}
              onExportCsv={() => void runExport('csv')}
              disabled={exporting}
            />
          </>
        }
      />

      <section className="card overflow-hidden">
        <FilterBar
          filters={filters}
          onChange={updateFilters}
          onReset={resetFilters}
          profiles={profilesQuery.data ?? []}
          sources={sourcesQuery.data ?? []}
          showCallerFilter={isAdmin}
          resultCount={total}
        />

        {leadsQuery.isError && (
          <div className="border-b border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
            {leadsQuery.error instanceof Error ? leadsQuery.error.message : 'Could not load leads'}
          </div>
        )}

        <LeadTable
          leads={rows}
          loading={leadsQuery.isLoading}
          sort={sort}
          onSort={handleSort}
          profiles={profilesQuery.data ?? []}
          sources={sourcesQuery.data ?? []}
          role={profile?.role ?? 'caller'}
          selected={selected}
          onToggleRow={toggleRow}
          onToggleAll={toggleAll}
          onEdit={(lead) => setEditing({ lead, mode: 'edit' })}
          onLogCall={(lead) => setEditing({ lead, mode: 'call' })}
          onDelete={(lead) => setPending({ type: 'delete', leads: [lead] })}
          emptyAction={
            <button type="button" className="btn-secondary" onClick={resetFilters}>
              Clear filters
            </button>
          }
        />

        <Pagination
          page={page}
          pageSize={pageSize}
          total={total}
          onPageChange={(next) => setPage(Math.max(1, next))}
          onPageSizeChange={(size) => {
            setPageSize(size);
            setPage(1);
          }}
        />
      </section>

      {isAdmin && selected.size > 0 && (
        <BulkActionBar
          count={selected.size}
          profiles={profilesQuery.data ?? []}
          onClear={() => setSelected(new Set())}
          onAssign={(callerId) => setPending({ type: 'bulk-assign', leadIds: [...selected], callerId })}
          onStatusChange={(status) => setPending({ type: 'bulk-status', leadIds: [...selected], status })}
          onExport={() => void runExport('xlsx', rows.filter((r) => selected.has(r.id)))}
          onDelete={() => setPending({ type: 'delete', leads: rows.filter((r) => selected.has(r.id)) })}
          busy={bulkAssign.isPending || bulkStatus.isPending || deleteLeads.isPending}
        />
      )}

      {selected.size > 0 && !isAdmin && (
        <div className="sticky bottom-3 z-30 mx-3 rounded-xl border border-[var(--color-hairline)] bg-white px-3 py-2 text-xs text-navy-600 shadow-lg">
          {selected.size} selected — export is available; assignment and bulk status changes require an
          administrator.
        </div>
      )}

      {editing && (
        <LeadEditor
          lead={editing.lead}
          mode={editing.mode}
          profiles={profilesQuery.data ?? []}
          role={profile?.role ?? 'caller'}
          onClose={() => setEditing(null)}
        />
      )}

      <ConfirmDialog
        open={pending !== null}
        title={confirmCopy.title}
        message={confirmCopy.message}
        confirmLabel={pending?.type === 'delete' ? 'Delete permanently' : 'Apply changes'}
        busy={deleteLeads.isPending || bulkAssign.isPending || bulkStatus.isPending}
        onCancel={() => setPending(null)}
        onConfirm={() => void confirmAction()}
      />
    </div>
  );
}
