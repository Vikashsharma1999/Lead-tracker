import { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { AlertTriangle, CalendarClock, Users } from 'lucide-react';
import type { ReportFilters } from '@/data/repository';
import { formatDate, formatDateTime, shortLeadId } from '@/lib/format';
import { exportLeadsToCsv, exportLeadsToExcel } from '@/lib/excel';
import { useAuth } from '@/hooks/useAuth';
import { useProfiles, useReport, useSources, useSummary } from '@/hooks/useLeads';
import { useToast } from '@/hooks/useToasts';
import { PageHeader } from '@/components/PageHeader';
import { EmptyState } from '@/components/EmptyState';
import { StatusChip } from '@/components/StatusChip';
import { ExportMenu } from '@/components/ExportMenu';

const CALLER_COLORS = ['#12351f', '#2f6d46', '#4c8d63', '#7cb18c', '#235636', '#0f2743'];

export function ReportsPage() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const { push } = useToast();
  const [filters, setFilters] = useState<ReportFilters>({});
  const reportQuery = useReport(filters);
  const summaryQuery = useSummary({ dateFrom: filters.dateFrom, dateTo: filters.dateTo });
  const profilesQuery = useProfiles();
  const sourcesQuery = useSources();

  const report = reportQuery.data;
  const summary = summaryQuery.data;

  const callerChart = useMemo(
    () =>
      (report?.callerStats ?? []).map((c) => ({
        name: c.callerName.split(' ')[0],
        calls: c.totalCalls,
        interested: c.interested,
        callbacks: c.callbacks,
      })),
    [report],
  );

  const sourceChart = useMemo(
    () =>
      (report?.sourceStats ?? []).map((s) => ({
        name: s.sourceName.length > 22 ? `${s.sourceName.slice(0, 22)}…` : s.sourceName,
        total: s.total,
        interested: s.interested,
        notDialed: s.notDialed,
      })),
    [report],
  );

  const exportReport = (format: 'xlsx' | 'csv') => {
    const rows = report?.callerStats ?? [];
    if (!rows.length) {
      push({ variant: 'warning', title: 'No report data to export yet' });
      return;
    }
    const leadLike = (report?.callbacksDueToday ?? []).concat(report?.overdueFollowUps ?? []);
    const context = { profiles: profilesQuery.data ?? [], sources: sourcesQuery.data ?? [] };
    if (leadLike.length) {
      if (format === 'xlsx') exportLeadsToExcel(leadLike, context, 'callbacks-and-overdue');
      else exportLeadsToCsv(leadLike, context, 'callbacks-and-overdue');
      push({
        variant: 'success',
        title: 'Report exported',
        description: `${leadLike.length} callback / overdue leads included.`,
      });
    } else {
      push({ variant: 'info', title: 'Nothing to export', description: 'No callbacks or overdue follow-ups in range.' });
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Reports"
        subtitle="Pipeline health, caller performance and follow-up workload"
        meta={
          <>
            <span>{isAdmin ? 'All callers' : 'Your performance'}</span>
            <span>Unique leads only — calls never inflate counts</span>
          </>
        }
        actions={
          <ExportMenu onExportExcel={() => exportReport('xlsx')} onExportCsv={() => exportReport('csv')} label="Export report" />
        }
      />

      <section className="card flex flex-wrap items-end gap-3 p-4">
        <label>
          <span className="label">From</span>
          <input
            type="date"
            className="input w-40"
            value={filters.dateFrom ?? ''}
            onChange={(e) => setFilters((f) => ({ ...f, dateFrom: e.target.value || undefined }))}
          />
        </label>
        <label>
          <span className="label">To</span>
          <input
            type="date"
            className="input w-40"
            value={filters.dateTo ?? ''}
            onChange={(e) => setFilters((f) => ({ ...f, dateTo: e.target.value || undefined }))}
          />
        </label>
        {isAdmin && (
          <label>
            <span className="label">Caller</span>
            <select
              className="input w-48"
              value={filters.callerId ?? ''}
              onChange={(e) => setFilters((f) => ({ ...f, callerId: e.target.value || undefined }))}
            >
              <option value="">All callers</option>
              {(profilesQuery.data ?? [])
                .filter((p) => p.role === 'caller')
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.full_name}
                  </option>
                ))}
            </select>
          </label>
        )}
        <label>
          <span className="label">Source</span>
          <select
            className="input w-52"
            value={filters.sourceId ?? ''}
            onChange={(e) => setFilters((f) => ({ ...f, sourceId: e.target.value || undefined }))}
          >
            <option value="">All sources</option>
            {(sourcesQuery.data ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>
        <button type="button" className="btn-ghost" onClick={() => setFilters({})}>
          Clear
        </button>
      </section>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label="Unique leads" value={summary?.totalLeads ?? 0} icon={<Users className="h-4 w-4" />} />
        <StatTile label="Interested" value={summary?.byStatus.interested ?? 0} tone="text-emerald-600" />
        <StatTile
          label="Callbacks due today"
          value={summary?.callbacksDueToday ?? 0}
          tone="text-amber-600"
          icon={<CalendarClock className="h-4 w-4" />}
        />
        <StatTile
          label="Overdue follow-ups"
          value={summary?.overdueFollowUps ?? 0}
          tone="text-red-600"
          icon={<AlertTriangle className="h-4 w-4" />}
        />
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ChartCard title="Calls per caller" subtitle="Logged call activities, not lead counts">
          {callerChart.length ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={callerChart} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eef1f0" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e5e9e7', fontSize: 12 }} />
                <Bar dataKey="calls" name="Calls" radius={[6, 6, 0, 0]}>
                  {callerChart.map((_, index) => (
                    <Cell key={index} fill={CALLER_COLORS[index % CALLER_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState title="No call activity in range" />
          )}
        </ChartCard>

        <ChartCard title="Interested leads per caller" subtitle="Unique leads currently marked Interested">
          {callerChart.length ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={callerChart} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eef1f0" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e5e9e7', fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="interested" name="Interested" fill="#22c55e" radius={[6, 6, 0, 0]} />
                <Bar dataKey="callbacks" name="Callbacks" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState title="No caller data" />
          )}
        </ChartCard>

        <ChartCard title="Leads added per day" subtitle="Last 14 days based on imported record dates">
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={report?.leadsPerDay ?? []} margin={{ top: 8, right: 12, left: -18, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f0" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e5e9e7', fontSize: 12 }} />
              <Line
                type="monotone"
                dataKey="count"
                name="Leads added"
                stroke="#2f6d46"
                strokeWidth={2.5}
                dot={{ r: 3, fill: '#2f6d46' }}
                activeDot={{ r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Source comparison" subtitle="Lead volume and interest by spreadsheet">
          {sourceChart.length ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={sourceChart} layout="vertical" margin={{ top: 8, right: 16, left: 8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eef1f0" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#476582' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={110}
                  tick={{ fontSize: 11, fill: '#476582' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #e5e9e7', fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="total" name="Total" fill="#12351f" radius={[0, 5, 5, 0]} />
                <Bar dataKey="interested" name="Interested" fill="#7cb18c" radius={[0, 5, 5, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState title="No sources configured" />
          )}
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <FollowUpList
          title="Callbacks due today"
          leads={report?.callbacksDueToday ?? []}
          emptyText="No callbacks scheduled for today."
        />
        <FollowUpList
          title="Overdue follow-ups"
          leads={report?.overdueFollowUps ?? []}
          emptyText="Nothing overdue — the queue is clean."
          tone="red"
        />
      </div>

      <p className="px-1 text-[11px] leading-relaxed text-navy-500">
        Reports are computed by the database (live mode) or the local sample store (demo mode) using
        your role's visibility. Export respects the selected filters and date range.
        Last updated {formatDateTime(new Date().toISOString())}.
      </p>
    </div>
  );
}

function StatTile({
  label,
  value,
  tone = 'text-navy-900',
  icon,
}: {
  label: string;
  value: number;
  tone?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="card p-3.5">
      <div className="flex items-center justify-between">
        <p className="text-[11px] font-semibold tracking-wide text-navy-500 uppercase">{label}</p>
        <span className="text-navy-400">{icon}</span>
      </div>
      <p className={`mt-1.5 text-2xl font-bold tabular-nums ${tone}`}>{value.toLocaleString()}</p>
    </div>
  );
}

function ChartCard({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section className="card p-4">
      <h2 className="text-sm font-bold text-navy-900">{title}</h2>
      <p className="mt-0.5 text-xs text-navy-500">{subtitle}</p>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function FollowUpList({
  title,
  leads,
  emptyText,
  tone = 'amber',
}: {
  title: string;
  leads: { id: string; name: string; phone: string; lead_status: Parameters<typeof StatusChip>[0]['status']; next_follow_up_at: string | null }[];
  emptyText: string;
  tone?: 'amber' | 'red';
}) {
  return (
    <section className="card overflow-hidden">
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <h2 className="text-sm font-bold text-navy-900">{title}</h2>
        <span
          className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${
            tone === 'red' ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-800'
          }`}
        >
          {leads.length}
        </span>
      </div>
      {leads.length === 0 ? (
        <EmptyState title={emptyText} />
      ) : (
        <ul className="divide-y divide-[var(--color-hairline)]">
          {leads.slice(0, 8).map((lead) => (
            <li key={lead.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-navy-900">{lead.name}</p>
                <p className="font-mono text-[11px] text-navy-500">
                  {shortLeadId(lead.id)} · {lead.phone}
                </p>
              </div>
              <div className="shrink-0 text-right">
                <StatusChip status={lead.lead_status} />
                <p className="mt-1 text-[11px] text-navy-500">
                  {lead.next_follow_up_at ? formatDate(lead.next_follow_up_at) : '—'}
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
