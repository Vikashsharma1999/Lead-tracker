import { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock3,
  CloudCog,
  FileSpreadsheet,
  Loader2,
  Play,
  RefreshCw,
  RotateCcw,
  ShieldAlert,
  Sheet,
  Wifi,
} from 'lucide-react';
import type { DataSource, SyncJob } from '@/types/domain';
import { getRepository } from '@/data';
import { formatDateTime, formatRelative } from '@/lib/format';
import { appMode } from '@/lib/env';
import { useSyncJobs, useSources } from '@/hooks/useLeads';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToasts';
import { PageHeader } from '@/components/PageHeader';
import { EmptyState } from '@/components/EmptyState';
import { ConflictPanel } from '@/components/ConflictPanel';
import { Spinner } from '@/components/Spinner';

type Busy = { id: string; action: 'test' | 'sync' | 'retry' } | null;

const STATUS_STYLES: Record<string, { label: string; className: string; icon: typeof Wifi }> = {
  connected: { label: 'Connected', className: 'bg-emerald-50 text-emerald-700 ring-emerald-200', icon: CheckCircle2 },
  not_configured: { label: 'Not configured', className: 'bg-amber-50 text-amber-800 ring-amber-200', icon: ShieldAlert },
  error: { label: 'Error', className: 'bg-red-50 text-red-700 ring-red-200', icon: AlertCircle },
  disconnected: { label: 'Disconnected', className: 'bg-slate-100 text-slate-600 ring-slate-200', icon: Wifi },
};

export function SyncCenterPage() {
  const { push } = useToast();
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const sourcesQuery = useSources();
  const jobsQuery = useSyncJobs();
  const [busy, setBusy] = useState<Busy>(null);
  const [showSetup, setShowSetup] = useState<'google' | 'microsoft' | null>('google');

  const runAction = async (source: DataSource, action: 'test' | 'sync' | 'retry') => {
    setBusy({ id: source.id, action });
    try {
      const repo = getRepository();
      const result =
        action === 'test'
          ? await repo.testSourceConnection(source.id)
          : action === 'sync'
            ? await repo.requestSync(source.id)
            : await repo.retryFailedJobs(source.id);
      push({
        variant: result.ok ? 'success' : 'warning',
        title:
          action === 'test'
            ? result.ok
              ? 'Connection verified'
              : 'Connection test did not pass'
            : action === 'sync'
              ? result.ok
                ? 'Sync requested'
                : 'Sync request rejected'
              : result.ok
                ? 'Retry queued'
                : 'Nothing retried',
        description: result.message,
      });
      await Promise.all([sourcesQuery.refetch(), jobsQuery.refetch()]);
    } catch (error) {
      push({
        variant: 'error',
        title: 'Request failed',
        description: error instanceof Error ? error.message : 'Unknown error',
      });
    } finally {
      setBusy(null);
    }
  };

  const sources = sourcesQuery.data ?? [];
  const jobs = jobsQuery.data ?? [];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Synchronization Center"
        subtitle="Every data source, its connection state and its import history"
        meta={
          <>
            <span className="inline-flex items-center gap-1.5">
              <span className={`h-1.5 w-1.5 rounded-full ${appMode === 'live' ? 'bg-emerald-400' : 'bg-amber-400'}`} aria-hidden />
              {appMode === 'live' ? 'Server integration functions available' : 'Demo mode — integrations disabled'}
            </span>
            <span>Status is reported by the server, never assumed by the UI</span>
          </>
        }
        actions={
          <button
            type="button"
            className="btn-light"
            onClick={() => void Promise.all([sourcesQuery.refetch(), jobsQuery.refetch()])}
          >
            <RefreshCw className={`h-4 w-4 ${sourcesQuery.isFetching ? 'animate-spin' : ''}`} aria-hidden />
            Refresh status
          </button>
        }
      />

      {appMode === 'demo' && (
        <div className="card flex items-start gap-3 border-amber-200 bg-amber-50/70 p-4">
          <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" aria-hidden />
          <div className="text-sm text-amber-900">
            <p className="font-semibold">Demo mode: no external connection is possible.</p>
            <p className="mt-1 text-xs leading-relaxed">
              This build has no Supabase project or OAuth credentials, so no Google Sheet or OneDrive
              workbook is linked. Buttons below are wired to the real server endpoints and will report
              an honest failure until credentials are configured. Follow the setup guides to go live.
            </p>
          </div>
        </div>
      )}

      {sourcesQuery.isLoading ? (
        <div className="card flex justify-center p-10">
          <Spinner className="h-6 w-6 text-forest-600" />
        </div>
      ) : sources.length === 0 ? (
        <div className="card">
          <EmptyState
            title="No data sources yet"
            description="Connect a Google Sheet or import an Excel workbook to start syncing leads."
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
          {sources.map((source) => {
            // A manual/local source is "available", never "connected to an
            // external service" — the wording matters more than the enum.
            const style =
              source.source_type === 'manual'
                ? { label: 'Local only', className: 'bg-slate-100 text-slate-700 ring-slate-200', icon: CloudCog }
                : (STATUS_STYLES[source.connection_status] ?? STATUS_STYLES.not_configured);
            const StatusIcon = style.icon;
            const sourceJobs = jobs.filter((j) => j.source_id === source.id);
            const lastJob = sourceJobs[0];
            return (
              <article key={source.id} className="card flex flex-col p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-50 text-navy-700">
                        {source.source_type === 'google_sheets' ? (
                          <Sheet className="h-4.5 w-4.5" aria-hidden />
                        ) : source.source_type === 'manual' ? (
                          <CloudCog className="h-4.5 w-4.5" aria-hidden />
                        ) : (
                          <FileSpreadsheet className="h-4.5 w-4.5" aria-hidden />
                        )}
                      </span>
                      <div className="min-w-0">
                        <h2 className="truncate text-sm font-bold text-navy-900">{source.name}</h2>
                        <p className="text-[11px] text-navy-500 capitalize">
                          {source.source_type.replace(/_/g, ' ')} ·{' '}
                          {source.sync_mode === 'interval'
                            ? `every ${source.sync_interval_seconds}s`
                            : source.sync_mode}
                        </p>
                      </div>
                    </div>
                  </div>
                  <span className={`chip ${style.className}`}>
                    <StatusIcon className="h-3 w-3" aria-hidden />
                    {style.label}
                  </span>
                </div>

                {source.last_error && (
                  <p className="mt-3 rounded-lg bg-red-50 px-2.5 py-2 text-[11px] text-red-800">
                    Last error: {source.last_error}
                  </p>
                )}

                <dl className="mt-3 grid grid-cols-2 gap-2 text-[11px] sm:grid-cols-4">
                  <div>
                    <dt className="text-navy-500">Last sync</dt>
                    <dd className="font-semibold text-navy-800">
                      {source.last_sync_at ? formatRelative(source.last_sync_at) : 'never'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-navy-500">Last success</dt>
                    <dd className="font-semibold text-navy-800">
                      {source.last_success_at ? formatRelative(source.last_success_at) : 'never'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-navy-500">Last job</dt>
                    <dd className="font-semibold text-navy-800">{lastJob ? lastJob.status : '—'}</dd>
                  </div>
                  <div>
                    <dt className="text-navy-500">Worksheet</dt>
                    <dd className="truncate font-semibold text-navy-800">
                      {String((source.configuration as Record<string, unknown>)?.worksheet ?? '—')}
                    </dd>
                  </div>
                </dl>

                {isAdmin && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      type="button"
                      className="btn-secondary py-1.5 text-xs"
                      disabled={busy?.id === source.id}
                      onClick={() => void runAction(source, 'test')}
                    >
                      {busy?.id === source.id && busy.action === 'test' ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                      ) : (
                        <Wifi className="h-3.5 w-3.5" aria-hidden />
                      )}
                      Test connection
                    </button>
                    <button
                      type="button"
                      className="btn-primary py-1.5 text-xs"
                      disabled={busy?.id === source.id}
                      onClick={() => void runAction(source, 'sync')}
                    >
                      {busy?.id === source.id && busy.action === 'sync' ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                      ) : (
                        <Play className="h-3.5 w-3.5" aria-hidden />
                      )}
                      Sync now
                    </button>
                    <button
                      type="button"
                      className="btn-ghost py-1.5 text-xs"
                      disabled={busy?.id === source.id}
                      onClick={() => void runAction(source, 'retry')}
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                      Retry failed
                    </button>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}

      <section className="card overflow-hidden">
        <div className="flex items-center justify-between px-4 pt-4 pb-3">
          <div>
            <h2 className="text-sm font-bold text-navy-900">Import history</h2>
            <p className="mt-0.5 text-xs text-navy-500">
              Durable sync job records — including retries, skips and error details.
            </p>
          </div>
          <Clock3 className="h-4 w-4 text-navy-400" aria-hidden />
        </div>
        {jobs.length === 0 ? (
          <EmptyState title="No sync jobs recorded yet" description="Jobs appear here after the first import or sync." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-y border-[var(--color-hairline)]">
                  {['Started', 'Type', 'Status', 'Added', 'Updated', 'Skipped', 'Attempts', 'Details'].map((h) => (
                    <th key={h} className="table-header px-3 py-2 text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--color-hairline)]">
                {jobs.map((job) => (
                  <JobRow key={job.id} job={job} sourceName={sources.find((s) => s.id === job.source_id)?.name} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {isAdmin && <ConflictPanel />}

      <section className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold text-navy-900">Guided setup</h2>
            <p className="mt-0.5 text-xs text-navy-500">
              Each integration needs server-side credentials. Nothing is marked connected until a real
              connection test passes.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              className={showSetup === 'google' ? 'btn-primary py-1.5 text-xs' : 'btn-secondary py-1.5 text-xs'}
              onClick={() => setShowSetup('google')}
            >
              <Sheet className="h-3.5 w-3.5" aria-hidden /> Google Sheets
            </button>
            <button
              type="button"
              className={showSetup === 'microsoft' ? 'btn-primary py-1.5 text-xs' : 'btn-secondary py-1.5 text-xs'}
              onClick={() => setShowSetup('microsoft')}
            >
              <FileSpreadsheet className="h-3.5 w-3.5" aria-hidden /> OneDrive / SharePoint
            </button>
          </div>
        </div>

        <div className="mt-4 rounded-xl bg-navy-50/60 p-4 text-sm text-navy-700">
          {showSetup === 'google' ? <GoogleSetup /> : <MicrosoftSetup />}
        </div>
      </section>
    </div>
  );
}

function JobRow({ job, sourceName }: { job: SyncJob; sourceName?: string }) {
  const tone =
    job.status === 'success'
      ? 'bg-emerald-50 text-emerald-700'
      : job.status === 'failed'
        ? 'bg-red-50 text-red-700'
        : job.status === 'running'
          ? 'bg-blue-50 text-blue-700'
          : 'bg-slate-100 text-slate-600';
  return (
    <tr className="hover:bg-navy-50/40">
      <td className="px-3 py-2.5 whitespace-nowrap text-[12px]">
        <span className="block text-navy-800">{formatDateTime(job.started_at)}</span>
        <span className="text-[10px] text-navy-500">{sourceName ?? job.source_id}</span>
      </td>
      <td className="px-3 py-2.5 text-[12px] capitalize text-navy-700">{job.job_type.replace(/_/g, ' ')}</td>
      <td className="px-3 py-2.5">
        <span className={`chip ${tone}`}>{job.status}</span>
      </td>
      <td className="px-3 py-2.5 text-[12px] tabular-nums">{job.records_added}</td>
      <td className="px-3 py-2.5 text-[12px] tabular-nums">{job.records_updated}</td>
      <td className="px-3 py-2.5 text-[12px] tabular-nums">{job.records_skipped}</td>
      <td className="px-3 py-2.5 text-[12px] tabular-nums">{job.attempts}</td>
      <td className="max-w-[280px] px-3 py-2.5 text-[11px] text-navy-500">
        {job.error_message ? (
          <span className="text-red-700">{job.error_message}</span>
        ) : job.finished_at ? (
          `Finished ${formatRelative(job.finished_at)}`
        ) : (
          '—'
        )}
      </td>
    </tr>
  );
}

function GoogleSetup() {
  return (
    <ol className="list-decimal space-y-2 pl-5 text-xs leading-relaxed">
      <li>
        Create an OAuth client (type: <strong>Web application</strong>) in Google Cloud Console and
        enable the <strong>Google Sheets API</strong> and <strong>Google Drive API</strong>.
      </li>
      <li>
        Add the server callback as an authorized redirect URI:
        <code className="mx-1 rounded bg-white px-1.5 py-0.5">GOOGLE_OAUTH_REDIRECT_URI</code>
        from <code>.env.example</code>.
      </li>
      <li>
        Store <code>GOOGLE_OAUTH_CLIENT_ID</code>, <code>GOOGLE_OAUTH_CLIENT_SECRET</code> and{' '}
        <code>OAUTH_STATE_SECRET</code> as Supabase Edge Function secrets. Never expose them to the client.
      </li>
      <li>Deploy the <code>google-oauth-start</code>, <code>google-oauth-callback</code> and <code>source-sync</code> functions.</li>
      <li>
        An admin clicks <em>Connect Google Sheet</em>, grants the least-privilege scopes, then maps
        columns and enables interval sync (minimum 15–60s).
      </li>
      <li>
        <strong>Status is only “Connected” after a live API call succeeds.</strong> Until then it stays
        “Not configured”.
      </li>
    </ol>
  );
}

function MicrosoftSetup() {
  return (
    <ol className="list-decimal space-y-2 pl-5 text-xs leading-relaxed">
      <li>
        Register an app in Microsoft Entra ID with delegated <code>Files.Read</code> and{' '}
        <code>Files.ReadWrite</code> (write-back only) and <code>offline_access</code>.
      </li>
      <li>
        Set <code>MS_OAUTH_TENANT_ID</code>, <code>MS_OAUTH_CLIENT_ID</code>,{' '}
        <code>MS_OAUTH_CLIENT_SECRET</code> and <code>MS_OAUTH_REDIRECT_URI</code> as server secrets.
      </li>
      <li>
        Deploy <code>ms-oauth-start</code>, <code>ms-oauth-callback</code> and <code>source-sync</code>.
      </li>
      <li>Pick a workbook on OneDrive/SharePoint, choose a worksheet and mapping, then enable interval sync.</li>
      <li>
        <strong>Local files on a laptop are never synced automatically.</strong> Use the upload importer,
        re-import on change, or run the optional local sync agent described in the README.
      </li>
    </ol>
  );
}
