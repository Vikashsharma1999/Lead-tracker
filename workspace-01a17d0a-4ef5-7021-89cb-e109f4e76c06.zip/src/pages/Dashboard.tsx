import { useCallback, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { CalendarClock, ChevronRight, AlertTriangle, RefreshCw, UserX, PhoneCall } from 'lucide-react';
import type { Lead, LeadStatus, SortSpec } from '@/types/domain';
import { DEFAULT_PAGE_SIZE } from '@/lib/constants';
import { formatDateTime, formatRelative } from '@/lib/format';
import { useAuth } from '@/hooks/useAuth';
import { useOnline } from '@/hooks/useOnline';
import { useLeads, useProfiles, useSources, useSummary } from '@/hooks/useLeads';
import { usePendingWrites } from '@/hooks/usePendingWrites';
import { PageHeader } from '@/components/PageHeader';
import { KpiCards } from '@/components/KpiCards';
import { StatusPie } from '@/components/StatusPie';
import { SyncStatusBar } from '@/components/SyncStatusBar';
import { LeadTable } from '@/components/LeadTable';
import { LeadEditor } from '@/components/LeadEditor';
import { useToast } from '@/hooks/useToasts';

export function DashboardPage() {
  const { profile } = useAuth();
  const online = useOnline();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { push } = useToast();
  const { count: pendingCount } = usePendingWrites();

  const [sort, setSort] = useState<SortSpec>({ field: 'created_at', direction: 'desc' });
  const [editing, setEditing] = useState<{ lead: Lead; mode: 'edit' | 'call' } | null>(null);
  const [refreshedAt, setRefreshedAt] = useState<Date | null>(new Date());
  const [refreshing, setRefreshing] = useState(false);

  const summaryQuery = useSummary();
  const sourcesQuery = useSources();
  const profilesQuery = useProfiles();
  const leadsQuery = useLeads(
    {},
    { page: 1, pageSize: Math.min(DEFAULT_PAGE_SIZE, 8), sort },
  );

  const lastSyncedAt = useMemo(() => {
    const times = (sourcesQuery.data ?? [])
      .map((s) => s.last_success_at)
      .filter((v): v is string => Boolean(v))
      .sort();
    return times.at(-1) ?? null;
  }, [sourcesQuery.data]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['summary'] }),
        queryClient.invalidateQueries({ queryKey: ['leads'] }),
        queryClient.invalidateQueries({ queryKey: ['sources'] }),
        queryClient.invalidateQueries({ queryKey: ['profiles'] }),
        queryClient.refetchQueries({ queryKey: ['summary'] }),
      ]);
      setRefreshedAt(new Date());
      push({ variant: 'success', title: 'Dashboard refreshed from the database' });
    } finally {
      setRefreshing(false);
    }
  }, [queryClient, push]);

  const applyStatusFilter = (key: 'total' | LeadStatus) => {
    if (key === 'total') navigate('/leads');
    else navigate(`/leads?status=${key}`);
  };

  const summary = summaryQuery.data;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Lead Tracker Dashboard"
        subtitle="Live status overview from your Google Sheet"
        meta={
          <>
            <span className="inline-flex items-center gap-1.5">
              <span
                className={`h-1.5 w-1.5 rounded-full ${online ? 'bg-emerald-400' : 'bg-amber-400'}`}
                aria-hidden
              />
              {online ? 'Connected' : 'Offline — showing last known data'}
            </span>
            <span>Last successful sync: {lastSyncedAt ? formatDateTime(lastSyncedAt) : 'never'}</span>
            <span>Dashboard refreshed {refreshedAt ? formatRelative(refreshedAt.toISOString()) : '—'}</span>
          </>
        }
        actions={
          <>
            <button
              type="button"
              onClick={() => void refresh()}
              className="btn-light"
              disabled={refreshing}
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} aria-hidden />
              {refreshing ? 'Refreshing…' : 'Refresh Data'}
            </button>
            <Link to="/sources" className="btn-light hidden sm:inline-flex">
              Sync center
              <ChevronRight className="h-4 w-4" aria-hidden />
            </Link>
          </>
        }
      />

      <KpiCards summary={summary} loading={summaryQuery.isLoading} onSelect={applyStatusFilter} />

      <SyncStatusBar
        sources={sourcesQuery.data}
        pendingCount={pendingCount}
        online={online}
        lastRefreshedAt={refreshedAt}
      />

      <div className="grid grid-cols-1 items-start gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <StatusPie
            summary={summary}
            loading={summaryQuery.isLoading}
            onSelectStatus={(label) => {
              const match = label.toLowerCase().replace(/[^a-z]+/g, '_').replace(/^_|_$/g, '');
              navigate(`/leads?status=${match}`);
            }}
          />
        </div>

        <section className="card flex flex-col p-4 sm:p-5" aria-labelledby="priorities-heading">
          <h2 id="priorities-heading" className="text-sm font-bold text-navy-900">
            Today&apos;s priorities
          </h2>
          <p className="mt-0.5 text-xs text-navy-500">Derived from follow-up dates on your visible leads.</p>

          <div className="mt-3 space-y-2">
            <PriorityRow
              icon={<CalendarClock className="h-4 w-4" aria-hidden />}
              label="Callbacks due today"
              value={summary?.callbacksDueToday ?? 0}
              tone="amber"
              onClick={() => navigate('/leads?status=call_back')}
            />
            <PriorityRow
              icon={<AlertTriangle className="h-4 w-4" aria-hidden />}
              label="Overdue follow-ups"
              value={summary?.overdueFollowUps ?? 0}
              tone="red"
              onClick={() => navigate('/reports')}
            />
            <PriorityRow
              icon={<UserX className="h-4 w-4" aria-hidden />}
              label="Unassigned leads"
              value={summary?.unassigned ?? 0}
              tone="slate"
              onClick={() => navigate('/leads?assigned=unassigned')}
            />
            <PriorityRow
              icon={<PhoneCall className="h-4 w-4" aria-hidden />}
              label="Calls logged today"
              value={summary?.callsToday ?? 0}
              tone="green"
              onClick={() => navigate('/reports')}
            />
          </div>

          <div className="mt-4 rounded-xl bg-navy-50/60 p-3">
            <p className="text-[11px] font-semibold tracking-wide text-navy-500 uppercase">Your role</p>
            <p className="mt-1 text-sm font-semibold text-navy-900">
              {profile?.role === 'admin' ? 'Administrator' : 'Caller'}
            </p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-navy-500">
              {profile?.role === 'admin'
                ? 'You can view all leads, manage callers, import sources and resolve conflicts.'
                : 'You see only leads assigned to you. Contact details are read-only.'}
            </p>
          </div>
        </section>
      </div>

      <section className="card overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 pt-4 pb-3">
          <div>
            <h2 className="text-sm font-bold text-navy-900">
              {profile?.role === 'admin' ? 'Latest leads' : 'My latest leads'}
            </h2>
            <p className="mt-0.5 text-xs text-navy-500">
              Showing the newest records visible to you. Open Leads for the full searchable table.
            </p>
          </div>
          <Link to="/leads" className="btn-secondary py-1.5 text-xs">
            View all leads
            <ChevronRight className="h-3.5 w-3.5" aria-hidden />
          </Link>
        </div>
        <LeadTable
          leads={leadsQuery.data?.rows ?? []}
          loading={leadsQuery.isLoading}
          sort={sort}
          onSort={(field) =>
            setSort((current) =>
              current.field === field
                ? { field, direction: current.direction === 'asc' ? 'desc' : 'asc' }
                : { field, direction: 'asc' },
            )
          }
          profiles={profilesQuery.data ?? []}
          sources={sourcesQuery.data ?? []}
          role={profile?.role ?? 'caller'}
          selected={new Set()}
          onToggleRow={() => undefined}
          onToggleAll={() => undefined}
          onEdit={(lead) => setEditing({ lead, mode: 'edit' })}
          onLogCall={(lead) => setEditing({ lead, mode: 'call' })}
        />
      </section>

      {editing && (
        <LeadEditor
          lead={editing.lead}
          mode={editing.mode}
          profiles={profilesQuery.data ?? []}
          role={profile?.role ?? 'caller'}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  );
}

function PriorityRow({
  icon,
  label,
  value,
  tone,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  tone: 'amber' | 'red' | 'slate' | 'green';
  onClick: () => void;
}) {
  const tones = {
    amber: 'bg-amber-50 text-amber-700',
    red: 'bg-red-50 text-red-600',
    slate: 'bg-slate-100 text-slate-600',
    green: 'bg-emerald-50 text-emerald-700',
  } as const;
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl border border-[var(--color-hairline)] px-3 py-2.5 text-left transition hover:bg-navy-50/60"
    >
      <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${tones[tone]}`}>{icon}</span>
      <span className="flex-1 text-sm font-medium text-navy-800">{label}</span>
      <span className="text-lg font-bold text-navy-900 tabular-nums">{value}</span>
    </button>
  );
}
