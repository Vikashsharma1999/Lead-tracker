import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';

export function NotFoundPage() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-forest-50 text-forest-700">
        <Compass className="h-7 w-7" aria-hidden />
      </span>
      <h1 className="text-xl font-bold text-navy-900">Page not found</h1>
      <p className="max-w-sm text-sm text-navy-500">
        The page you requested does not exist, or you do not have permission to view it.
      </p>
      <Link to="/" className="btn-primary mt-2">Back to dashboard</Link>
    </div>
  );
}
