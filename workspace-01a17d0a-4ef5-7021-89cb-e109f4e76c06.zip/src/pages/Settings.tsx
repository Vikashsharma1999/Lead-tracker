import { Database, HardDrive, ListChecks, ShieldCheck, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { LEAD_STATUSES } from '@/lib/constants';
import { appMode, isDemoMode } from '@/lib/env';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToasts';
import { PageHeader } from '@/components/PageHeader';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { StatusChip } from '@/components/StatusChip';

export function SettingsPage() {
  const { push } = useToast();
  const { profile } = useAuth();
  const qc = useQueryClient();
  const [confirmReset, setConfirmReset] = useState(false);

  const resetDemoData = () => {
    localStorage.removeItem('ltd.demo.dataset.v1');
    qc.clear();
    push({
      variant: 'success',
      title: 'Demo dataset reset',
      description: 'Reload the page to regenerate the synthetic sample data.',
    });
    setConfirmReset(false);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Settings"
        subtitle="Status vocabulary, duplicate handling and environment configuration"
        meta={
          <>
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
              {appMode === 'live' ? 'Live Supabase environment' : 'Local demo environment'}
            </span>
            <span>Signed in as {profile?.email}</span>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <section className="card p-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-navy-900">
            <ListChecks className="h-4 w-4 text-forest-600" aria-hidden /> Lead statuses
          </h2>
          <p className="mt-0.5 text-xs text-navy-500">
            Seeded as the <code>lead_statuses</code> table. Statuses drive KPI buckets and the pie chart.
          </p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {LEAD_STATUSES.map((status) => (
              <li key={status.value}>
                <StatusChip status={status.value} />
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] leading-relaxed text-navy-500">
            Adding or relabelling a status is a database change (admin-gated by RLS). The dashboard never
            hardcodes counts: tiles read the aggregated status buckets returned by the server.
          </p>
        </section>

        <section className="card p-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-navy-900">
            <Database className="h-4 w-4 text-forest-600" aria-hidden /> Duplicate handling
          </h2>
          <p className="mt-0.5 text-xs text-navy-500">
            Configured per source in <code>data_sources.configuration.duplicate_policy</code>.
          </p>
          <dl className="mt-3 space-y-2 text-xs">
            <div className="rounded-lg border border-[var(--color-hairline)] p-2.5">
              <dt className="font-semibold text-navy-800">skip</dt>
              <dd className="text-navy-500">Keep the existing lead; the incoming row is counted as skipped.</dd>
            </div>
            <div className="rounded-lg border border-[var(--color-hairline)] p-2.5">
              <dt className="font-semibold text-navy-800">update (default)</dt>
              <dd className="text-navy-500">Merge into the existing lead and record what changed.</dd>
            </div>
            <div className="rounded-lg border border-[var(--color-hairline)] p-2.5">
              <dt className="font-semibold text-navy-800">create</dt>
              <dd className="text-navy-500">Allow a deliberate second lead (requires admin opt-in).</dd>
            </div>
          </dl>
          <p className="mt-2 text-[11px] text-navy-500">
            Duplicate matching uses normalised phone (last 10 digits) and lower-cased email.
          </p>
        </section>

        <section className="card p-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-navy-900">
            <HardDrive className="h-4 w-4 text-forest-600" aria-hidden /> Environment
          </h2>
          <dl className="mt-3 space-y-2 text-xs">
            <Row label="Mode" value={appMode === 'live' ? 'Live (Supabase)' : 'Demo (local sample data)'} />
            <Row label="Supabase URL" value={isDemoMode ? 'not configured' : 'configured (client env)'} />
            <Row label="Realtime" value={appMode === 'live' ? 'Supabase postgres_changes' : 'local event bus'} />
            <Row label="Integrations" value="server-side only — see Data Sources" />
            <Row label="Offline queue" value="IndexedDB, per-user, cleared on sign-out" />
          </dl>
          <p className="mt-3 text-[11px] leading-relaxed text-navy-500">
            Secrets (service role key, Google/Microsoft client secrets, refresh tokens) live only in
            server-side environment variables. They are never bundled into the client.
          </p>
        </section>

        <section className="card p-4">
          <h2 className="text-sm font-bold text-navy-900">Local data</h2>
          <p className="mt-0.5 text-xs text-navy-500">
            The demo dataset is synthetic and stored only in this browser. Reset it to regenerate.
          </p>
          <button
            type="button"
            className="btn-secondary mt-3 text-xs"
            onClick={() => setConfirmReset(true)}
            disabled={!isDemoMode}
          >
            <Trash2 className="h-3.5 w-3.5" aria-hidden />
            Reset demo dataset
          </button>
          {!isDemoMode && (
            <p className="mt-2 text-[11px] text-navy-500">Disabled in live mode — destructive resets belong to the database.</p>
          )}
        </section>
      </div>

      <ConfirmDialog
        open={confirmReset}
        title="Reset the local demo dataset?"
        message="All local edits made in demo mode will be discarded and the synthetic sample data regenerated on reload."
        confirmLabel="Reset dataset"
        onCancel={() => setConfirmReset(false)}
        onConfirm={resetDemoData}
      />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-[var(--color-hairline)] pb-1.5 last:border-0">
      <dt className="text-navy-500">{label}</dt>
      <dd className="text-right font-semibold text-navy-800">{value}</dd>
    </div>
  );
}
