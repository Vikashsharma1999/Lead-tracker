import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader2, ShieldCheck, UserPlus, UserX } from 'lucide-react';
import type { Profile, Role } from '@/types/domain';
import { getRepository } from '@/data';
import { ROLE_LABELS } from '@/lib/constants';
import { formatDate, initials } from '@/lib/format';
import { useProfiles } from '@/hooks/useLeads';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToasts';
import { PageHeader } from '@/components/PageHeader';
import { Modal } from '@/components/Modal';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { Spinner } from '@/components/Spinner';

interface PendingChange {
  profile: Profile;
  patch: { role?: Role; active?: boolean };
  title: string;
  message: string;
}

export function UsersPage() {
  const { profile: me } = useAuth();
  const { push } = useToast();
  const qc = useQueryClient();
  const profilesQuery = useProfiles();
  const [addOpen, setAddOpen] = useState(false);
  const [pending, setPending] = useState<PendingChange | null>(null);
  const [form, setForm] = useState({ full_name: '', email: '', role: 'caller' as Role });

  const createUser = useMutation({
    mutationFn: (input: { full_name: string; email: string; role: Role }) =>
      getRepository().createProfile(input),
    onSuccess: (created) => {
      push({
        variant: 'success',
        title: 'Account created',
        description: `${created.full_name} can now sign in. A temporary password is emailed in live mode.`,
      });
      setAddOpen(false);
      setForm({ full_name: '', email: '', role: 'caller' });
      void qc.invalidateQueries({ queryKey: ['profiles'] });
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Could not create the account', description: error.message }),
  });

  const updateUser = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: { role?: Role; active?: boolean } }) =>
      getRepository().updateProfile(id, patch),
    onSuccess: () => {
      push({ variant: 'success', title: 'Account updated' });
      setPending(null);
      void qc.invalidateQueries({ queryKey: ['profiles'] });
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Update failed', description: error.message }),
  });

  const profiles = profilesQuery.data ?? [];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Callers & Access"
        subtitle="Provision caller accounts and control who can administer the workspace"
        meta={
          <>
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
              Role changes are enforced by the database
            </span>
            <span>Only admins can grant admin — nobody can elevate themselves</span>
          </>
        }
        actions={
          <button type="button" className="btn-light" onClick={() => setAddOpen(true)}>
            <UserPlus className="h-4 w-4" aria-hidden />
            Add caller
          </button>
        }
      />

      <section className="card overflow-hidden">
        {profilesQuery.isLoading ? (
          <div className="flex justify-center p-10">
            <Spinner className="h-6 w-6 text-forest-600" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-[var(--color-hairline)]">
                  {['User', 'Email', 'Role', 'Status', 'Created', 'Actions'].map((h) => (
                    <th key={h} className="table-header px-3 py-2.5 text-left">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--color-hairline)]">
                {profiles.map((profile) => {
                  const isSelf = profile.id === me?.id;
                  return (
                    <tr key={profile.id} className="hover:bg-navy-50/40">
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2.5">
                          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-forest-100 text-[11px] font-bold text-forest-800">
                            {initials(profile.full_name)}
                          </span>
                          <div>
                            <p className="font-semibold text-navy-900">
                              {profile.full_name}
                              {isSelf && <span className="ml-2 text-[10px] text-navy-500">(you)</span>}
                            </p>
                            <p className="text-[11px] text-navy-500">{profile.id.slice(0, 14)}…</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-navy-700">{profile.email}</td>
                      <td className="px-3 py-2.5">
                        <select
                          className="rounded-lg border border-[var(--color-hairline)] bg-white px-2 py-1 text-xs font-semibold capitalize"
                          value={profile.role}
                          disabled={isSelf}
                          onChange={(event) => {
                            const role = event.target.value as Role;
                            setPending({
                              profile,
                              patch: { role },
                              title: `Change ${profile.full_name}'s role?`,
                              message: role === 'admin'
                                ? 'This user will gain full administrative access: all leads, imports, user management and integration settings.'
                                : 'This user will lose administrative access and only see leads assigned to them.',
                            });
                          }}
                        >
                          {(['caller', 'admin'] as Role[]).map((role) => (
                            <option key={role} value={role}>
                              {ROLE_LABELS[role]}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-3 py-2.5">
                        <span
                          className={`chip ${
                            profile.active
                              ? 'bg-emerald-50 text-emerald-700 ring-emerald-200'
                              : 'bg-slate-100 text-slate-600 ring-slate-200'
                          }`}
                        >
                          {profile.active ? 'Active' : 'Deactivated'}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-navy-500">{formatDate(profile.created_at)}</td>
                      <td className="px-3 py-2.5">
                        <button
                          type="button"
                          disabled={isSelf}
                          onClick={() =>
                            setPending({
                              profile,
                              patch: { active: !profile.active },
                              title: profile.active
                                ? `Deactivate ${profile.full_name}?`
                                : `Reactivate ${profile.full_name}?`,
                              message: profile.active
                                ? 'The account cannot sign in and their assigned leads stay assigned until you reassign them. Data is preserved.'
                                : 'The account will be able to sign in again with their existing role.',
                            })
                          }
                          className={`btn-ghost py-1 text-xs ${profile.active ? 'text-red-600' : 'text-emerald-700'} disabled:opacity-40`}
                        >
                          <UserX className="h-3.5 w-3.5" aria-hidden />
                          {profile.active ? 'Deactivate' : 'Reactivate'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <p className="px-1 text-[11px] leading-relaxed text-navy-500">
        In live mode, account creation runs inside the <code>admin-users</code> Edge Function, which
        re-verifies the caller's admin role server-side before using the service role key. The browser
        never holds that key.
      </p>

      <Modal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        title="Add a caller account"
        description="The account is created server-side. Passwords are never handled by the dashboard."
        size="sm"
        footer={
          <>
            <button type="button" className="btn-secondary" onClick={() => setAddOpen(false)}>
              Cancel
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={createUser.isPending || !form.email || !form.full_name}
              onClick={() => createUser.mutate(form)}
            >
              {createUser.isPending && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
              Create account
            </button>
          </>
        }
      >
        <div className="space-y-3">
          <label className="block">
            <span className="label">Full name</span>
            <input
              className="input"
              value={form.full_name}
              onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))}
              placeholder="Jane Doe"
            />
          </label>
          <label className="block">
            <span className="label">Work email</span>
            <input
              className="input"
              type="email"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              placeholder="jane@company.com"
            />
          </label>
          <label className="block">
            <span className="label">Role</span>
            <select
              className="input"
              value={form.role}
              onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as Role }))}
            >
              <option value="caller">Caller</option>
              <option value="admin">Administrator</option>
            </select>
          </label>
          <p className="rounded-lg bg-amber-50 px-3 py-2 text-[11px] leading-relaxed text-amber-900">
            Demo mode stores the account locally and cannot create real logins. In live mode an invite
            email with an activation link is sent through Supabase Auth.
          </p>
        </div>
      </Modal>

      <ConfirmDialog
        open={pending !== null}
        title={pending?.title ?? ''}
        message={pending?.message ?? ''}
        confirmLabel="Apply change"
        destructive={pending?.patch.active === false || pending?.patch.role === 'caller'}
        busy={updateUser.isPending}
        onCancel={() => setPending(null)}
        onConfirm={() => {
          if (!pending) return;
          updateUser.mutate({ id: pending.profile.id, patch: pending.patch });
        }}
      />
    </div>
  );
}
