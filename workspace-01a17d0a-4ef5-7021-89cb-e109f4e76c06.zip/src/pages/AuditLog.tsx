import { useState } from 'react';
import { FileClock, Search } from 'lucide-react';
import { formatDateTime } from '@/lib/format';
import { useAuditLogs } from '@/hooks/useLeads';
import { PageHeader } from '@/components/PageHeader';
import { EmptyState } from '@/components/EmptyState';
import { Spinner } from '@/components/Spinner';

export function AuditLogPage() {
  const { data, isLoading, isError, error } = useAuditLogs();
  const [search, setSearch] = useState('');

  const logs = (data ?? []).filter((log) => {
    const q = search.toLowerCase();
    if (!q) return true;
    return (
      log.action.toLowerCase().includes(q) ||
      log.entity_type.toLowerCase().includes(q) ||
      (log.user_name ?? '').toLowerCase().includes(q) ||
      (log.entity_id ?? '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-4">
      <PageHeader
        title="Audit History"
        subtitle="Every privileged action, recorded server-side and readable by admins only"
        meta={<span>{data?.length ?? 0} recent entries</span>}
        actions={
          <div className="relative">
            <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-forest-200/70" aria-hidden />
            <input
              className="w-56 rounded-xl border border-white/20 bg-white/10 py-2 pr-3 pl-9 text-sm text-white placeholder:text-forest-100/60 focus:bg-white/15 focus:outline-none"
              placeholder="Filter audit entries…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        }
      />

      <section className="card overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center p-10">
            <Spinner className="h-6 w-6 text-forest-600" />
          </div>
        ) : isError ? (
          <EmptyState
            title="Could not load audit history"
            description={error instanceof Error ? error.message : 'Unknown error'}
          />
        ) : logs.length === 0 ? (
          <EmptyState title="No audit entries" description="Actions such as edits, assignments and sync runs will appear here." />
        ) : (
          <ul className="divide-y divide-[var(--color-hairline)]">
            {logs.map((log) => (
              <li key={log.id} className="flex items-start gap-3 px-4 py-3">
                <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-navy-50 text-navy-600">
                  <FileClock className="h-4 w-4" aria-hidden />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-baseline gap-x-2">
                    <p className="font-mono text-[12px] font-semibold text-forest-800">{log.action}</p>
                    <span className="text-[11px] text-navy-500">
                      {log.entity_type}
                      {log.entity_id ? ` · ${log.entity_id.slice(0, 12)}` : ''}
                    </span>
                  </div>
                  <p className="mt-0.5 text-[11px] text-navy-500">
                    {log.user_name ?? 'System'} · {formatDateTime(log.created_at)}
                  </p>
                  {log.metadata && (
                    <pre className="mt-1 max-h-24 overflow-auto rounded-lg bg-navy-50/70 p-2 text-[10px] text-navy-600">
                      {JSON.stringify(log.metadata, null, 2)}
                    </pre>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
