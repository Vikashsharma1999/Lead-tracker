import { useMemo, useRef, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  ArrowRight,
  CheckCircle2,
  FileSpreadsheet,
  Loader2,
  TriangleAlert,
  Upload,
} from 'lucide-react';
import type { DataSource } from '@/types/domain';
import { getRepository } from '@/data';
import type { ImportRow, ImportResult } from '@/data/repository';
import {
  INTERNAL_FIELDS,
  autoMapColumns,
  mapRows,
  parseSpreadsheetFile,
  type InternalField,
  type ParsedWorkbook,
} from '@/lib/excel';
import { buildDuplicateIndex, findDuplicate } from '@/lib/duplicates';
import { useProfiles, useSources } from '@/hooks/useLeads';
import { useToast } from '@/hooks/useToasts';
import { PageHeader } from '@/components/PageHeader';
import { ExportMenu } from '@/components/ExportMenu';
import { exportLeadsToCsv, exportLeadsToExcel } from '@/lib/excel';
import { EmptyState } from '@/components/EmptyState';

type Mapping = Partial<Record<InternalField, string>>;
type DuplicatePolicy = 'skip' | 'update' | 'create';

export function ImportPage() {
  const { push } = useToast();
  const qc = useQueryClient();
  const sourcesQuery = useSources();
  const profilesQuery = useProfiles();
  const fileInput = useRef<HTMLInputElement>(null);

  const [workbooks, setWorkbooks] = useState<ParsedWorkbook[]>([]);
  const [activeWorkbook, setActiveWorkbook] = useState(0);
  const [activeSheet, setActiveSheet] = useState(0);
  const [mapping, setMapping] = useState<Mapping>({});
  const [policy, setPolicy] = useState<DuplicatePolicy>('update');
  const [sourceId, setSourceId] = useState('');
  const [newSourceName, setNewSourceName] = useState('');
  const [parsing, setParsing] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);

  const sheet = workbooks[activeWorkbook]?.sheets[activeSheet];

  const mapped = useMemo(() => (sheet ? mapRows(sheet.rows, mapping) : []), [sheet, mapping]);
  const validRows = mapped.filter((row) => row.errors.length === 0);
  const invalidRows = mapped.filter((row) => row.errors.length > 0);

  const importMutation = useMutation({
    mutationFn: async () => {
      let targetId = sourceId;
      if (!targetId) {
        const created = await getRepository().createSource({
          name: newSourceName.trim() || `${workbooks[activeWorkbook]?.fileName ?? 'Excel import'}`,
          source_type: 'excel_upload',
          configuration: { file_name: workbooks[activeWorkbook]?.fileName, upload: true },
        });
        targetId = created.id;
      }
      const rows: ImportRow[] = validRows.map((row) => ({
        name: row.name,
        phone: row.phone,
        email: row.email,
        lead_status: row.lead_status,
        lead_outcome: row.lead_outcome as ImportRow['lead_outcome'],
        next_follow_up_at: row.next_follow_up_at,
        notes: row.notes,
        source_sheet_name: sheet?.name ?? null,
        source_record_id: row.source_record_id,
        source_external_id: workbooks[activeWorkbook]?.fileName ?? null,
      }));
      return getRepository().importLeads(targetId, rows, policy);
    },
    onSuccess: (data) => {
      setResult(data);
      push({
        variant: 'success',
        title: 'Import complete',
        description: `${data.added} added · ${data.updated} updated · ${data.skipped} skipped`,
      });
      void qc.invalidateQueries({ queryKey: ['leads'] });
      void qc.invalidateQueries({ queryKey: ['summary'] });
      void qc.invalidateQueries({ queryKey: ['sources'] });
      void qc.invalidateQueries({ queryKey: ['sync-jobs'] });
      void qc.invalidateQueries({ queryKey: ['report'] });
    },
    onError: (error: Error) =>
      push({ variant: 'error', title: 'Import failed', description: error.message }),
  });

  const handleFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setParsing(true);
    setResult(null);
    try {
      const parsed: ParsedWorkbook[] = [];
      for (const file of Array.from(files)) {
        if (!/\.(xlsx|xls|csv)$/i.test(file.name)) {
          push({ variant: 'warning', title: 'Unsupported file skipped', description: file.name });
          continue;
        }
        parsed.push(await parseSpreadsheetFile(file));
      }
      if (!parsed.length) return;
      setWorkbooks(parsed);
      setActiveWorkbook(0);
      setActiveSheet(0);
      const firstSheet = parsed[0].sheets[0];
      setMapping(firstSheet ? autoMapColumns(firstSheet.headers) : {});
      setNewSourceName(parsed[0].fileName.replace(/\.(xlsx|xls|csv)$/i, ''));
    } catch (error) {
      push({
        variant: 'error',
        title: 'Could not read that file',
        description: error instanceof Error ? error.message : 'Unknown parsing error',
      });
    } finally {
      setParsing(false);
    }
  };

  const selectSheet = (workbookIndex: number, sheetIndex: number) => {
    setActiveWorkbook(workbookIndex);
    setActiveSheet(sheetIndex);
    const next = workbooks[workbookIndex]?.sheets[sheetIndex];
    setMapping(next ? autoMapColumns(next.headers) : {});
    setResult(null);
  };

  const duplicatePreview = useMemo(() => {
    // Client-side preview only; the server re-checks with its own index.
    const index = buildDuplicateIndex([]);
    return validRows.map((row) => ({
      row,
      duplicate:
        (row.phone && index.byPhone.has(row.phone)) || (row.email && index.byEmail.has(row.email))
          ? true
          : Boolean(findDuplicate(index, row)),
    }));
  }, [validRows]);

  const canImport = Boolean(sheet) && validRows.length > 0 && (sourceId || newSourceName.trim());
  const targetSources = (sourcesQuery.data ?? []).filter((s) => s.source_type !== 'google_sheets');

  return (
    <div className="space-y-4">
      <PageHeader
        title="Import Spreadsheet Data"
        subtitle="Excel (.xlsx, .xls) and CSV — preview, map columns and import with duplicate control"
        meta={
          <>
            <span>Files are parsed in your browser, then validated and written server-side</span>
            <span>Uploaded files are not auto-synced after import</span>
          </>
        }
        actions={
          <button type="button" className="btn-light" onClick={() => fileInput.current?.click()}>
            <Upload className="h-4 w-4" aria-hidden />
            Choose files
          </button>
        }
      />

      <input
        ref={fileInput}
        type="file"
        accept=".xlsx,.xls,.csv"
        multiple
        className="hidden"
        onChange={(event) => void handleFiles(event.target.files)}
      />

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1.6fr_1fr]">
        <section className="card overflow-hidden">
          <div className="border-b border-[var(--color-hairline)] px-4 py-3">
            <h2 className="text-sm font-bold text-navy-900">1 · Select data</h2>
            <p className="mt-0.5 text-xs text-navy-500">
              Supported: Excel .xlsx, legacy .xls and .csv. Multiple files can be queued.
            </p>
          </div>

          {!workbooks.length ? (
            <div
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => {
                event.preventDefault();
                void handleFiles(event.dataTransfer.files);
              }}
            >
              <EmptyState
                icon={parsing ? <Loader2 className="h-6 w-6 animate-spin" /> : <FileSpreadsheet className="h-6 w-6" />}
                title={parsing ? 'Reading workbook…' : 'Drop a spreadsheet here'}
                description="Nothing is uploaded until you press Import. Your file never leaves this browser during preview."
                action={
                  <button type="button" className="btn-primary" onClick={() => fileInput.current?.click()}>
                    <Upload className="h-4 w-4" aria-hidden /> Select files
                  </button>
                }
              />
            </div>
          ) : (
            <div className="p-4">
              <div className="flex flex-wrap gap-2">
                {workbooks.map((book, index) => (
                  <button
                    key={`${book.fileName}-${index}`}
                    type="button"
                    onClick={() => selectSheet(index, 0)}
                    className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold ${
                      index === activeWorkbook
                        ? 'bg-forest-700 text-white'
                        : 'bg-navy-50 text-navy-700 hover:bg-navy-100'
                    }`}
                  >
                    {book.fileName}
                  </button>
                ))}
                <button type="button" className="btn-ghost py-1 text-xs" onClick={() => fileInput.current?.click()}>
                  Add another file
                </button>
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {(workbooks[activeWorkbook]?.sheets ?? []).map((s, index) => (
                  <button
                    key={s.name}
                    type="button"
                    onClick={() => selectSheet(activeWorkbook, index)}
                    className={`rounded-lg border px-2.5 py-1.5 text-xs font-semibold ${
                      index === activeSheet
                        ? 'border-forest-500 bg-forest-50 text-forest-800'
                        : 'border-[var(--color-hairline)] text-navy-600 hover:bg-navy-50'
                    }`}
                  >
                    {s.name}
                    <span className="ml-1.5 text-[10px] font-medium text-navy-500">{s.rowCount}</span>
                  </button>
                ))}
              </div>

              {sheet && (
                <div className="mt-4 overflow-x-auto rounded-xl border border-[var(--color-hairline)]">
                  <table className="w-full text-[11px]">
                    <thead className="table-header">
                      <tr>
                        {sheet.headers.slice(0, 8).map((header) => (
                          <th key={header} className="px-2.5 py-2 text-left whitespace-nowrap">
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--color-hairline)]">
                      {sheet.rows.slice(0, 5).map((row, index) => (
                        <tr key={index}>
                          {sheet.headers.slice(0, 8).map((header) => (
                            <td key={header} className="max-w-[160px] truncate px-2.5 py-1.5 text-navy-700">
                              {String(row[header] ?? '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </section>

        <section className="card flex flex-col p-4">
          <h2 className="text-sm font-bold text-navy-900">2 · Destination & rules</h2>
          <p className="mt-0.5 text-xs text-navy-500">
            Pick an existing source or create a new upload source.
          </p>

          <label className="mt-3 block">
            <span className="label">Data source</span>
            <select className="input" value={sourceId} onChange={(event) => setSourceId(event.target.value)}>
              <option value="">＋ Create a new upload source</option>
              {targetSources.map((source: DataSource) => (
                <option key={source.id} value={source.id}>
                  {source.name}
                </option>
              ))}
            </select>
          </label>

          {!sourceId && (
            <label className="mt-2 block">
              <span className="label">New source name</span>
              <input
                className="input"
                value={newSourceName}
                onChange={(event) => setNewSourceName(event.target.value)}
                placeholder="e.g. October Meta Ads export"
              />
            </label>
          )}

          <fieldset className="mt-3">
            <legend className="label">Duplicate handling</legend>
            <div className="space-y-1.5">
              {(
                [
                  ['update', 'Update existing lead', 'Merge into the matched lead (phone or email).'],
                  ['skip', 'Skip duplicates', 'Keep the existing record untouched.'],
                  ['create', 'Always create new', 'Allow a deliberate second lead for the same phone.'],
                ] as [DuplicatePolicy, string, string][]
              ).map(([value, label, description]) => (
                <label
                  key={value}
                  className={`flex cursor-pointer gap-2.5 rounded-xl border p-2.5 ${
                    policy === value ? 'border-forest-500 bg-forest-50/60' : 'border-[var(--color-hairline)]'
                  }`}
                >
                  <input
                    type="radio"
                    name="duplicate-policy"
                    className="mt-0.5 h-3.5 w-3.5 accent-forest-600"
                    checked={policy === value}
                    onChange={() => setPolicy(value)}
                  />
                  <span>
                    <span className="block text-xs font-semibold text-navy-900">{label}</span>
                    <span className="block text-[11px] text-navy-500">{description}</span>
                  </span>
                </label>
              ))}
            </div>
          </fieldset>

          <div className="mt-4 rounded-xl bg-navy-50/60 p-3 text-[11px] text-navy-600">
            <p className="font-semibold text-navy-800">Local files vs. cloud sync</p>
            <p className="mt-1 leading-relaxed">
              Importing a file copies its rows into the central database. The original file on your
              computer is <strong>not</strong> linked and will not sync later — re-import a changed file,
              or connect a OneDrive/SharePoint workbook (Data Sources → guided setup) for continuous sync.
            </p>
          </div>
        </section>
      </div>

      {sheet && (
        <section className="card overflow-hidden">
          <div className="border-b border-[var(--color-hairline)] px-4 py-3">
            <h2 className="text-sm font-bold text-navy-900">3 · Map columns</h2>
            <p className="mt-0.5 text-xs text-navy-500">
              Headers are matched automatically. Adjust anything that looks wrong.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-2.5 p-4 sm:grid-cols-2 lg:grid-cols-3">
            {INTERNAL_FIELDS.map((field) => (
              <label key={field.key}>
                <span className="label">
                  {field.label}
                  {field.required && <span className="ml-1 text-red-500">*</span>}
                </span>
                <select
                  className="input"
                  value={mapping[field.key] ?? ''}
                  onChange={(event) =>
                    setMapping((current) => ({
                      ...current,
                      [field.key]: event.target.value || undefined,
                    }))
                  }
                >
                  <option value="">— not mapped —</option>
                  {sheet.headers.map((header) => (
                    <option key={header} value={header}>
                      {header}
                    </option>
                  ))}
                </select>
              </label>
            ))}
          </div>
        </section>
      )}

      {sheet && (
        <section className="card overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--color-hairline)] px-4 py-3">
            <div>
              <h2 className="text-sm font-bold text-navy-900">4 · Preview & import</h2>
              <p className="mt-0.5 text-xs text-navy-500">
                {validRows.length} ready · {invalidRows.length} with errors · {sheet.rowCount} total rows
              </p>
            </div>
            <button
              type="button"
              className="btn-primary"
              disabled={!canImport || importMutation.isPending}
              onClick={() => importMutation.mutate()}
            >
              {importMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                <ArrowRight className="h-4 w-4" aria-hidden />
              )}
              {importMutation.isPending ? 'Importing…' : `Import ${validRows.length} rows`}
            </button>
          </div>

          <div className="max-h-96 overflow-auto">
            <table className="w-full min-w-[860px] text-xs">
              <thead>
                <tr className="border-b border-[var(--color-hairline)]">
                  {['Row', 'Name', 'Mobile', 'Email', 'Status', 'Follow-up', 'Validation'].map((header) => (
                    <th key={header} className="table-header px-3 py-2 text-left">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--color-hairline)]">
                {mapped.slice(0, 100).map((row) => (
                  <tr key={row.rowNumber} className={row.errors.length ? 'bg-red-50/40' : undefined}>
                    <td className="px-3 py-1.5 text-navy-500">{row.rowNumber}</td>
                    <td className="px-3 py-1.5 font-medium text-navy-900">{row.name || '—'}</td>
                    <td className="px-3 py-1.5 text-navy-700">{row.phone || '—'}</td>
                    <td className="max-w-[200px] truncate px-3 py-1.5 text-navy-700">{row.email ?? '—'}</td>
                    <td className="px-3 py-1.5 text-navy-700">{row.lead_status.replace(/_/g, ' ')}</td>
                    <td className="px-3 py-1.5 text-navy-700">
                      {row.next_follow_up_at ? new Date(row.next_follow_up_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-3 py-1.5">
                      {row.errors.length ? (
                        <span className="flex items-center gap-1 text-red-700">
                          <TriangleAlert className="h-3 w-3" aria-hidden /> {row.errors.join('; ')}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-emerald-700">
                          <CheckCircle2 className="h-3 w-3" aria-hidden /> Valid
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="border-t border-[var(--color-hairline)] px-4 py-2 text-[11px] text-navy-500">
            {duplicatePreview.length} rows will be checked against the database for duplicates using
            normalised phone and email. Rows with validation errors are excluded and reported.
          </p>
        </section>
      )}

      {result && (
        <section className="card border-emerald-200 p-4">
          <h2 className="flex items-center gap-2 text-sm font-bold text-emerald-800">
            <CheckCircle2 className="h-4 w-4" aria-hidden /> Import finished
          </h2>
          <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Added" value={result.added} />
            <Stat label="Updated" value={result.updated} />
            <Stat label="Skipped" value={result.skipped} />
            <Stat label="Policy" value={result.policy} />
          </div>
          {Boolean(result.errors?.length) && (
            <div className="mt-3">
              <p className="text-xs font-semibold text-navy-800">{result.errors?.length} row(s) reported errors</p>
              <ul className="mt-1 max-h-32 space-y-0.5 overflow-auto text-[11px] text-navy-600">
                {result.errors?.map((error) => (
                  <li key={`${error.row}-${error.message}`}>
                    Row {error.row}: {error.message}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="mt-3">
            <ExportMenu
              label="Download error report"
              onExportExcel={() => {
                const rows = invalidRows;
                if (!rows.length) {
                  push({ variant: 'info', title: 'No row errors to export' });
                  return;
                }
                // Reuse the lead exporter shape for a simple, consistent report.
                exportLeadsToExcel(
                  rows.map((row, index) => ({
                    id: `row-${row.rowNumber}`,
                    source_id: null,
                    source_external_id: null,
                    source_sheet_name: sheet?.name ?? null,
                    source_record_id: String(row.rowNumber),
                    name: row.name || '(missing)',
                    phone: row.phone || '(missing)',
                    email: row.email,
                    lead_status: row.lead_status,
                    lead_outcome: 'pending' as const,
                    assigned_to: null,
                    last_call_at: null,
                    next_follow_up_at: null,
                    notes: row.errors.join('; '),
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                    version: index + 1,
                  })),
                  { profiles: profilesQuery.data ?? [], sources: sourcesQuery.data ?? [] },
                  'import-errors',
                );
              }}
              onExportCsv={() => {
                const rows = invalidRows;
                if (!rows.length) {
                  push({ variant: 'info', title: 'No row errors to export' });
                  return;
                }
                exportLeadsToCsv(
                  rows.map((row, index) => ({
                    id: `row-${row.rowNumber}`,
                    source_id: null,
                    source_external_id: null,
                    source_sheet_name: sheet?.name ?? null,
                    source_record_id: String(row.rowNumber),
                    name: row.name || '(missing)',
                    phone: row.phone || '(missing)',
                    email: row.email,
                    lead_status: row.lead_status,
                    lead_outcome: 'pending' as const,
                    assigned_to: null,
                    last_call_at: null,
                    next_follow_up_at: null,
                    notes: row.errors.join('; '),
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                    version: index + 1,
                  })),
                  { profiles: profilesQuery.data ?? [], sources: sourcesQuery.data ?? [] },
                  'import-errors',
                );
              }}
            />
          </div>
        </section>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-xl border border-[var(--color-hairline)] p-2.5">
      <p className="text-[10px] font-semibold tracking-wide text-navy-500 uppercase">{label}</p>
      <p className="mt-0.5 text-lg font-bold text-navy-900">{value}</p>
    </div>
  );
}
