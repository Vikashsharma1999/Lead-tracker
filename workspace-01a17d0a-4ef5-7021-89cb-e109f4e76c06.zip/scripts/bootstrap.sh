#!/usr/bin/env bash
# Bootstrap the Lead Tracker Dashboard in a fresh sandbox / clone.
#
# node_modules, dist and the Playwright browser cache are deliberately excluded
# from workspace snapshots, so after a sandbox restart they must be rebuilt.
#
# Usage:
#   ./scripts/bootstrap.sh              # install deps + typecheck
#   ./scripts/bootstrap.sh --e2e        # also install Playwright browsers
#   ./scripts/bootstrap.sh --no-check   # skip the typecheck step
set -euo pipefail

cd "$(dirname "$0")/.."

WITH_E2E=0
RUN_CHECK=1
for arg in "$@"; do
  case "$arg" in
    --e2e) WITH_E2E=1 ;;
    --no-check) RUN_CHECK=0 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

echo "==> Node $(node -v) / npm $(npm -v)"

# --legacy-peer-deps is required: vite-plugin-pwa's peer ranges make npm's
# strict resolver bail with "Cannot read properties of null (reading 'edgesOut')".
if [ -f package-lock.json ]; then
  echo "==> Installing dependencies from package-lock.json"
  npm ci --legacy-peer-deps --no-audit --no-fund
else
  echo "==> Installing dependencies (no lockfile found)"
  npm install --legacy-peer-deps --no-audit --no-fund
fi

# Sanity check the packages that are easiest to lose: the SheetJS CDN tarball
# and the PWA plugin.
node -e "require('xlsx'); require('vite'); require('react'); console.log('==> core deps resolve OK')"

if [ "$RUN_CHECK" = "1" ]; then
  echo "==> Typechecking"
  npm run typecheck
fi

if [ "$WITH_E2E" = "1" ]; then
  echo "==> Installing Playwright Chromium"
  npx playwright install chromium
  echo "    If Chromium fails to launch with 'libnspr4.so: cannot open shared object",
  echo "    file', install the OS libs (root): npx playwright install --with-deps chromium"
  echo "    or see docs/DEPLOYMENT.md section 6 for a no-root workaround."
fi

cat <<'EOF'

==> Ready. Start the app with:
      npm run dev:host        # binds 0.0.0.0:5173 (needed for the preview proxy)
      npm run dev             # localhost only

    Demo sign-in: admin@demo.leadtracker.app / AdminDemo123!
    Tests:        npm test        (unit, 88)
                  npm run test:e2e (Playwright, needs --e2e above)
EOF
