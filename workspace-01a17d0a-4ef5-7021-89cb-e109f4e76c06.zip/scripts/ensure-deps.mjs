// Preflight guard: makes `npm run dev` / `npm run build` self-healing after a
// sandbox restart, which wipes node_modules (excluded from workspace snapshots).
//
// Runs synchronously as an npm "predev"/"prebuild" hook. If the toolchain is
// missing it installs from the lockfile, otherwise it exits immediately (~30 ms).
import { existsSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const stamp = join(root, 'node_modules', '.bin', 'vite');

if (existsSync(stamp)) process.exit(0);

console.log('[preflight] node_modules missing or incomplete — installing from package-lock.json');

try {
  execSync('npm ci --legacy-peer-deps --no-audit --no-fund', {
    cwd: root,
    stdio: 'inherit',
    // --legacy-peer-deps is required: vite-plugin-pwa's peer ranges break npm 10's
    // strict resolver with "Cannot read properties of null (reading 'edgesOut')".
  });
} catch {
  console.error(
    '[preflight] npm ci failed. Run `npm install --legacy-peer-deps` manually, or bootstrap.sh.',
  );
  process.exit(1);
}

if (!existsSync(stamp)) {
  console.error('[preflight] install finished but node_modules/.bin/vite is still missing');
  process.exit(1);
}
